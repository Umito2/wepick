# WePick implementation contract

Package `com.wepick.app`; Android minSdk 26, compile/target 36. Kotlin 2.2.21, Compose Material3, Hilt, Navigation serializable routes. Domain is Kotlin-only.

## Domain (domain/model)

`Category { FOOD, OUTINGS, MOVIES, ACTIVITIES }`, `BudgetTier { LOW, MEDIUM, HIGH }`, `Mood { CHILL, ENERGETIC, COZY }`, `Vote { LIKE, PASS }`, `SessionStatus { ACTIVE, MATCHED }`, `MatchSource { MUTUAL, TIE_BREAKER }`.

`User(uid: String, name: String, partnerId: String?, coupleRoomId: String?, vetoTokensRemaining: Int = 2, lastTokenResetTimestamp: Long = 0)`; timestamps are epoch millis in domain, Firestore Timestamp on wire.

`CoupleRoom(roomId: String, inviteCode: String, user1Id: String, user2Id: String?, activeSessionId: String?, createdAt: Long)`.

`SwipeSession(sessionId: String, roomId: String, category: Category, budgetFilter: BudgetTier, moodTag: Mood, status: SessionStatus, matchedItemId: String?, itemIds: List<String>, matchSource: MatchSource?, matchRevision: Long = 0)`.

`DeckItem(id: String, title: String, category: Category, priceTier: BudgetTier, vibeTags: Set<Mood>, description: String, emoji: String)`.

`VoteState(itemId: String, user1Vote: Vote?, user2Vote: Vote?, vetoedBy: String?)`.

`SessionFilter(category: Category, budget: BudgetTier, mood: Mood)`.

## Domain repositories

`AuthRepository`: `val userId: String?`; `observeAuth(): Flow<String?>`; `suspend signInAnonymously(name: String)`; `suspend signInWithGoogle(idToken: String)` (link anonymous identity, reject credential collisions rather than discard room); `suspend signOut()`.

`CoupleRepository`: `observeUser(uid: String): Flow<User?>`; `observeRoom(roomId: String): Flow<CoupleRoom?>`; `suspend createInvite(): CoupleRoom`; `suspend joinRoom(code: String): CoupleRoom`; `suspend refreshTokens()`.

`SwipeSessionRepository`: `observeSession(sessionId: String): Flow<SwipeSession?>`; `observeVotes(sessionId: String): Flow<List<VoteState>>`; `suspend createSession(roomId: String, filter: SessionFilter): String`; `suspend castVote(sessionId: String, itemId: String, vote: Vote)`; `suspend vetoMatch(sessionId: String, expectedRevision: Long)`; `suspend spinTieBreaker(sessionId: String): String?`.

`DeckRepository`: `allItems(): List<DeckItem>`; `itemsFor(filter: SessionFilter): List<DeckItem>`; `find(id: String): DeckItem?`. Implement `data/local/LocalDeckDataSource` as this interface, inject singleton.

## Wire / server

Firestore enum fields use enum names. budgetFilter wire is LOW/MEDIUM/HIGH; UI displays $/$$/$$$. Callable region `us-central1`. Every callable requires auth and App Check outside emulator. Names / request / response:

- `ensureUser` `{name?}` -> `{uid}` (upsert own profile; lazy weekly rolling reset).
- `createInvite` `{}` -> `{roomId}` (unique six uppercase alphanumeric code via private `invite_codes/{code}`, idempotent existing room).
- `joinRoom` `{code}` -> `{roomId}` (atomic membership/partner linkage and invite consumption; bounded join attempts).
- `refreshTokens` `{}` -> `{}` (refresh both room members' balances from server clock).
- `createSession` `{roomId, category, budgetFilter, moodTag}` -> `{sessionId}` (immutable server-selected itemIds; reuse unfinished ACTIVE sessions; an explicit new-round action replaces MATCHED sessions or exhausted ACTIVE sessions with an empty likes union).
- `vetoMatch` `{sessionId, expectedRevision}` -> `{}` (atomic token debit + swipe veto + ACTIVE session + null match; revision guards duplicate/racing requests; increment revision).
- `spinTieBreaker` `{sessionId}` -> `{itemId: String|null}` (both have completed all nonvetoed cards, server random from union of likes excluding vetoed; persist MATCHED with TIE_BREAKER; null for empty union, concurrent/retried calls return current result).

All swipes initialized by createSession: itemId, user1Vote:null, user2Vote:null, vetoedBy:null. Cast vote Kotlin transaction reads session, room, swipe (all reads before writes), checks room membership, ACTIVE, unvetoed, own vote null; writes only own vote once. If partner LIKE and this LIKE, also updates session status MATCHED, matchedItemId, matchSource MUTUAL, matchRevision+1 atomically. Security rules enforce same transition using getAfter; no client writes any other docs or fields. ActiveSessionId must equal session being mutated. No query for matching required. Observe document and swipes with callbackFlow + awaitClose cleanup and surface errors.

The shared catalogue source is `catalog/deck.json`, packaged as an Android asset and copied into the functions build. Exactly 20 items, 5 per category. Budget is a maximum (LOW includes LOW, MEDIUM includes LOW/MEDIUM, HIGH includes all), mood strict; each category includes a LOW item for each mood. The Android data layer parses the asset with org.json.

The tie breaker is a shared random choice from eligible likes; no LLM is called.
