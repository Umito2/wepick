# WePick implementation contract

Package `com.wepick.app`; Android minSdk 26, compile/target 36. Kotlin 2.2.21, Compose Material3, Hilt, Navigation serializable routes. Domain is Kotlin-only.

## Domain (domain/model)

`Category { FOOD, OUTINGS, MOVIES, ACTIVITIES }`, `BudgetTier { LOW, MEDIUM, HIGH }`, `Mood { CHILL, ENERGETIC, COZY }`, `Vote { LIKE, PASS }`, `SessionStatus { ACTIVE, MATCHED }`, `MatchSource { MUTUAL, TIE_BREAKER }`.

`User(uid: String, name: String, partnerId: String?, coupleRoomId: String?, vetoTokensRemaining: Int = 2, lastTokenResetTimestamp: Long = 0)`; timestamps are epoch millis in domain, Firestore Timestamp on wire.

`CoupleRoom(roomId: String, inviteCode: String, user1Id: String, user2Id: String?, activeSessionId: String?, createdAt: Long)`.

`SwipeSession(sessionId: String, roomId: String, category: Category, budgetFilter: BudgetTier, moodTag: Mood, status: SessionStatus, matchedItemId: String?, itemIds: List<String>, matchSource: MatchSource?, matchRevision: Long = 0)`.

`DeckItem(id: String, title: String, category: Category, priceTier: BudgetTier, vibeTags: Set<Mood>, description: String, emoji: String)`.

`VoteState(itemId: String, user1Vote: Vote?, user2Vote: Vote?, vetoedBy: String?)`.

`SessionFilter(category: Category, budget: BudgetTier, mood: Mood)`.

## Domain repositories

`AuthRepository`: `val userId: String?`; `observeAuth(): Flow<String?>`; `suspend signInAnonymously(name: String)`; `suspend signInWithGoogle(idToken: String)` (link anonymous identity, reject credential collisions rather than discard room); `suspend signOut()`.

`CoupleRepository`: `observeUser(uid: String): Flow<User?>`; `observeRoom(roomId: String): Flow<CoupleRoom?>`; `suspend createInvite(): CoupleRoom`; `suspend joinRoom(code: String): CoupleRoom`; `suspend refreshTokens()`.

`SwipeSessionRepository`: `observeSession(sessionId: String): Flow<SwipeSession?>`; `observeVotes(sessionId: String): Flow<List<VoteState>>`; `suspend createSession(roomId: String, filter: SessionFilter): String`; `suspend castVote(sessionId: String, itemId: String, vote: Vote)`; `suspend vetoMatch(sessionId: String, expectedRevision: Long)`; `suspend spinTieBreaker(sessionId: String): String?`.

`DeckRepository`: `allItems(): List<DeckItem>`; `itemsFor(filter: SessionFilter): List<DeckItem>`; `find(id: String): DeckItem?`. Implement `data/local/LocalDeckDataSource` as this interface, inject singleton.

## Spark wire and transactions

The authoritative write and rule details are in [`SPARK-CONTRACT.md`](SPARK-CONTRACT.md). The 1.1.1 runtime uses Firebase Authentication and direct Firestore client transactions on the no-cost Spark plan. No callable endpoint, deployed Node runtime, billing account, or Blaze upgrade is required. The `functions/` directory now contains local Firebase tooling and tests rather than a deployable service.

Firestore enum fields use enum names. budgetFilter wire remains LOW/MEDIUM/HIGH. `BudgetTier.label` shows illustrative Egyptian-pound guides for two: `Up to EGP 300`, `EGP 301–700`, `Over EGP 700`. `filterLabel` shows maximum choices: `Up to EGP 300`, `Up to EGP 700`, `Any budget`. These guides are not verified menu/venue quotes or currency conversions.

Repository interfaces above remain stable. The direct operations must preserve these behaviors:

- Profile initialization creates only the authenticated user's exact-schema profile, unpaired with two tokens and a server timestamp. Name changes preserve pairing/token fields.
- `createInvite` reserves a unique six-character uppercase alphanumeric code and creates the room/profile link atomically. An existing own room is reused.
- `joinRoom` charges an own-account code attempt, then atomically joins the room, links both profiles, and consumes the invitation. Rules validate the blind host-profile update through reciprocal `getAfter` links. Switching from an unused own invite removes that empty room and consumes its code in the same commit.
- `refreshTokens` refreshes either or both reciprocal partners only when a seven-day reset is due. A `request_times/{uid}` server timestamp may guide client branching; rules use `request.time` independently.
- `createSession` uses the exact immutable list from administrator-seeded `deck_filters/{CATEGORY_BUDGET_MOOD}`. It reuses unfinished ACTIVE sessions; replacement is allowed for MATCHED sessions or exhausted ACTIVE sessions with no eligible likes.
- `vetoMatch` atomically debits/refills-and-debits the caller, vetoes the matched item, resumes ACTIVE with null match/source, and increments revision. A stale expectedRevision performs no writes.
- `spinTieBreaker` requires both partners to finish all nonvetoed cards. It persists one random eligible union choice as MATCHED/TIE_BREAKER with revision +1. Empty unions return null; concurrent/retried calls return the committed winner.

All swipes are initialized atomically with the session and active room pointer: itemId, user1Vote:null, user2Vote:null, vetoedBy:null. The Kotlin vote transaction reads session, room, and swipe before writes; checks membership, ACTIVE state, unvetoed status and own null vote; and saves only the caller's first vote. A second LIKE also publishes MATCHED, the item ID, MUTUAL source, and revision +1 in that commit. Rules enforce the complete transition using `getAfter`; activeSessionId must equal the mutated session. No matching query is required. Document/swipe listeners use cancellable flows and surface errors.

The catalogue source is `catalog/deck.json`, packaged as an Android asset and used to generate `catalog/deck-filters.json` for administrator seeding. Exactly 20 items, five per category. Budget is a maximum (LOW includes LOW, MEDIUM includes LOW/MEDIUM, HIGH includes all), mood strict; every category has a LOW item for each mood. The Android data layer parses the asset with org.json. Clients can get catalogue filters but cannot list or write them.

Invite collection listing is denied. `join_attempts/{uid}` gates partner-code reads through the current lastCode and limits recorded attempts to eight per fifteen-minute window. Repeated reads of that code and anonymous-account churn remain abuse limitations. Firestore quotas apply; Spark does not provide unlimited reads, writes, storage, or uptime.

Tie-breaker rules validate exhaustion and candidate eligibility, not randomness quality. The stock app selects randomly; a modified client could prefer an eligible item. Do not describe this as server-secure or provably fair randomness. The UI only animates the persisted winner; no AI/LLM or paid API is called.

Presentation retains the twelve-second soft initial-load watchdog, retry controls, and browser-demo escape path. A valid late snapshot can recover after the watchdog; an invite waiting for its partner remains observed. One-shot data deadlines remain eight seconds for emulator builds and thirty seconds for production, with the thirty-five-second pairing-action fallback.
