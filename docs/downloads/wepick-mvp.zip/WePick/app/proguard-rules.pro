# Domain objects use explicit Firestore mapping; no reflection keep rules are required.
# Firebase, Hilt, and kotlinx.serialization ship their own consumer rules.
-keepattributes Signature,InnerClasses,EnclosingMethod

