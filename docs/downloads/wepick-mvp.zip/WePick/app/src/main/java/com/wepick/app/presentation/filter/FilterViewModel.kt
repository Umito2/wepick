package com.wepick.app.presentation.filter

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.domain.repository.DeckRepository
import com.wepick.app.domain.repository.SwipeSessionRepository
import com.wepick.app.presentation.common.presentationMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class FilterUiState(
    val category: Category = Category.FOOD,
    val budget: BudgetTier = BudgetTier.MEDIUM,
    val mood: Mood = Mood.CHILL,
    val availableItems: Int = 0,
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val readySessionId: String? = null,
    val previousSessionId: String? = null,
    val error: String? = null,
)

@HiltViewModel
class FilterViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val couples: CoupleRepository,
    private val sessions: SwipeSessionRepository,
    private val deck: DeckRepository,
) : ViewModel() {
    private val roomId = checkNotNull(savedStateHandle.get<String>("roomId"))
    private val mutableState = MutableStateFlow(FilterUiState())
    val uiState = mutableState.asStateFlow()
    private var observation: Job? = null

    init { updateCount(); observe() }

    private fun observe() {
        observation?.cancel()
        // Navigation observes this state immediately, before the new listener can emit.
        mutableState.update { it.copy(isLoading = true, readySessionId = null, previousSessionId = null) }
        observation = viewModelScope.launch {
            try {
                couples.observeRoom(roomId).collectLatest { room ->
                    if (room == null || !room.isPaired) {
                        mutableState.update { it.copy(isLoading = false, readySessionId = null, previousSessionId = null, error = "Your shared room isn't available. Reopen WePick to reconnect.") }
                        return@collectLatest
                    }
                    val sessionId = room.activeSessionId
                    if (sessionId == null) {
                        mutableState.update { it.copy(isLoading = false, readySessionId = null, previousSessionId = null) }
                    } else {
                        mutableState.update { it.copy(isLoading = true, readySessionId = null, previousSessionId = null) }
                        sessions.observeSession(sessionId).collectLatest { session ->
                            if (session == null || session.status == SessionStatus.MATCHED) {
                                mutableState.update { it.copy(isLoading = false, readySessionId = null, previousSessionId = session?.sessionId) }
                            } else {
                                sessions.observeVotes(sessionId).collectLatest { votes ->
                                    val byId = votes.associateBy { it.itemId }
                                    val remaining = session.itemIds.mapNotNull(byId::get).filter { it.vetoedBy == null }
                                    val hasVotes = session.itemIds.all(byId::containsKey)
                                    val emptyFinishedRound = hasVotes && remaining.all { it.user1Vote != null && it.user2Vote != null } &&
                                        remaining.none { it.user1Vote == Vote.LIKE || it.user2Vote == Vote.LIKE }
                                    mutableState.update {
                                        it.copy(
                                            isLoading = false,
                                            // An exhausted all-pass round may be replaced with new filters.
                                            readySessionId = session.sessionId.takeUnless { emptyFinishedRound },
                                            previousSessionId = session.sessionId.takeIf { emptyFinishedRound },
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            } catch (error: Exception) {
                mutableState.update { it.copy(isLoading = false, readySessionId = null, previousSessionId = null, error = error.presentationMessage("We couldn't load your shared room. Please retry.")) }
            }
        }
    }

    fun selectCategory(value: Category) { mutableState.update { it.copy(category = value) }; updateCount() }
    fun selectBudget(value: BudgetTier) { mutableState.update { it.copy(budget = value) }; updateCount() }
    fun selectMood(value: Mood) { mutableState.update { it.copy(mood = value) }; updateCount() }

    private fun updateCount() {
        mutableState.update { it.copy(availableItems = deck.itemsFor(SessionFilter(it.category, it.budget, it.mood)).size) }
    }

    fun startSession() {
        val state = mutableState.value
        if (state.isBusy || state.isLoading || state.availableItems == 0) return
        mutableState.update { it.copy(isBusy = true, readySessionId = null, error = null) }
        viewModelScope.launch {
            try {
                val id = sessions.createSession(roomId, SessionFilter(state.category, state.budget, state.mood))
                mutableState.update { it.copy(readySessionId = id) }
            } catch (error: Exception) {
                mutableState.update { it.copy(readySessionId = null, error = error.presentationMessage("We couldn't start your round. Please retry.")) }
            } finally {
                mutableState.update { it.copy(isBusy = false) }
            }
        }
    }

    fun clearError() { mutableState.update { it.copy(error = null) } }
    fun retry() { clearError(); observe() }
}
