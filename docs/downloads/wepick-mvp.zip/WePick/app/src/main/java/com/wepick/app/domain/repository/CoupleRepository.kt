package com.wepick.app.domain.repository

import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import kotlinx.coroutines.flow.Flow

interface CoupleRepository {
    fun observeUser(uid: String): Flow<User?>
    fun observeRoom(roomId: String): Flow<CoupleRoom?>
    suspend fun createInvite(): CoupleRoom
    suspend fun joinRoom(code: String): CoupleRoom
    suspend fun refreshTokens()
}
