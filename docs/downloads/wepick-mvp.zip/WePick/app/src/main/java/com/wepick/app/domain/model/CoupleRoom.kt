package com.wepick.app.domain.model

data class CoupleRoom(
    val roomId: String,
    val inviteCode: String,
    val user1Id: String,
    val user2Id: String? = null,
    val activeSessionId: String? = null,
    val createdAt: Long,
) {
    val isPaired: Boolean get() = user2Id != null

    fun contains(uid: String): Boolean = uid == user1Id || uid == user2Id

    fun partnerOf(uid: String): String? = when (uid) {
        user1Id -> user2Id
        user2Id -> user1Id
        else -> null
    }
}
