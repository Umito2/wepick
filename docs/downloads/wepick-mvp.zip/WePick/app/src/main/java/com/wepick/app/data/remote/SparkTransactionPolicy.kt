package com.wepick.app.data.remote

import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException

internal const val TOKEN_WINDOW_MILLIS = 7L * 24 * 60 * 60 * 1_000
internal const val JOIN_WINDOW_MILLIS = 15L * 60 * 1_000
internal const val MAX_JOIN_ATTEMPTS = 8L

internal data class WeeklyTokenBalance(val available: Int, val resetDue: Boolean)

/** The caller obtains now from a committed Firestore server timestamp, never the handset clock. */
internal fun weeklyTokenBalance(user: User, serverNowMillis: Long): WeeklyTokenBalance {
    val due = serverNowMillis >= user.lastTokenResetTimestamp &&
        serverNowMillis - user.lastTokenResetTimestamp >= TOKEN_WINDOW_MILLIS
    return WeeklyTokenBalance(if (due) 2 else user.vetoTokensRemaining, due)
}

/** A competing reset may satisfy the requested work before stale write rules are evaluated. */
internal fun canAcknowledgeTokenRefresh(
    attemptedOwn: User,
    currentOwn: User,
    currentPartner: User?,
    includePartner: Boolean,
    serverNowMillis: Long,
): Boolean {
    if (currentOwn.uid != attemptedOwn.uid || currentOwn.partnerId != attemptedOwn.partnerId ||
        currentOwn.coupleRoomId != attemptedOwn.coupleRoomId || weeklyTokenBalance(currentOwn, serverNowMillis).resetDue) {
        return false
    }
    if (!includePartner || attemptedOwn.partnerId == null) return currentPartner == null
    val partner = currentPartner ?: return false
    return partner.uid == attemptedOwn.partnerId && partner.partnerId == currentOwn.uid &&
        currentOwn.coupleRoomId != null && partner.coupleRoomId == currentOwn.coupleRoomId &&
        !weeklyTokenBalance(partner, serverNowMillis).resetDue
}

internal data class JoinAttemptDecision(val count: Long, val startsNewWindow: Boolean)

internal fun nextJoinAttempt(previousCount: Long?, windowStartMillis: Long?, serverNowMillis: Long): JoinAttemptDecision {
    val newWindow = windowStartMillis == null ||
        (serverNowMillis >= windowStartMillis && serverNowMillis - windowStartMillis >= JOIN_WINDOW_MILLIS)
    val count = if (newWindow) 0L else previousCount
        ?: throw WePickException("Your invite attempt could not be verified. Please retry.")
    if (count !in 0 until MAX_JOIN_ATTEMPTS) {
        throw WePickException("Too many invite attempts. Try again in 15 minutes.")
    }
    return JoinAttemptDecision(count + 1, newWindow)
}

internal data class CompletedDeck(val bothFinished: Boolean, val candidateIds: List<String>)

/** A missing swipe is never a completed card; vetoes remove cards from both progress and the union. */
internal fun completedDeck(itemIds: List<String>, votes: List<VoteState>): CompletedDeck {
    val byId = votes.associateBy(VoteState::itemId)
    val complete = itemIds.isNotEmpty() && itemIds.all { id ->
        byId[id]?.let { it.vetoedBy != null || (it.user1Vote != null && it.user2Vote != null) } == true
    }
    val candidates = itemIds.filter { id ->
        byId[id]?.let { it.vetoedBy == null && (it.user1Vote == Vote.LIKE || it.user2Vote == Vote.LIKE) } == true
    }
    return CompletedDeck(complete, candidates)
}
