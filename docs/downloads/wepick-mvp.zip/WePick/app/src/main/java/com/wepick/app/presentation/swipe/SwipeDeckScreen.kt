package com.wepick.app.presentation.swipe

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.Vote
import com.wepick.app.presentation.common.ErrorNotice
import kotlin.math.abs
import kotlinx.coroutines.launch

@Composable
fun SwipeDeckScreen(
    state: SwipeUiState,
    onVote: (Vote) -> Unit,
    onVeto: () -> Unit,
    onSpin: () -> Unit,
    onNewSession: () -> Unit,
    onRetry: () -> Unit,
    onDismissError: () -> Unit,
) {
    val colors = MaterialTheme.colorScheme
    val fontScale = LocalDensity.current.fontScale
    val matched = state.session?.status == SessionStatus.MATCHED && state.matchedItem != null && !state.isSuperseded

    Scaffold(
        bottomBar = {
            if (state.queue.isNotEmpty() && !matched && !state.isSuperseded) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 16.dp, top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(52.dp), verticalAlignment = Alignment.CenterVertically) {
                        FilledTonalIconButton(
                            onClick = { onVote(Vote.PASS) },
                            enabled = state.canVote,
                            modifier = Modifier.size(64.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = colors.surfaceContainerHighest, contentColor = colors.onSurfaceVariant),
                        ) { Icon(Icons.Rounded.Close, "Pass on ${state.queue.first().title}", Modifier.size(32.dp)) }
                        FilledTonalIconButton(
                            onClick = { onVote(Vote.LIKE) },
                            enabled = state.canVote,
                            modifier = Modifier.size(72.dp),
                            colors = IconButtonDefaults.filledTonalIconButtonColors(containerColor = colors.primary, contentColor = colors.onPrimary),
                        ) { Icon(Icons.Rounded.Favorite, "Like ${state.queue.first().title}", Modifier.size(34.dp)) }
                    }
                    Text(if (state.isBusy) "Saving your choice…" else "Left to pass · Right to like", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                }
            }
        },
    ) { padding ->
        BoxWithConstraints(Modifier.fillMaxSize().padding(padding)) {
        // Keep text and actions reachable in landscape, with large fonts, and while an error is shown.
        val scrollContent = maxHeight < 560.dp || fontScale > 1.2f || state.error != null
        val scrollModifier = if (scrollContent) Modifier.verticalScroll(rememberScrollState()) else Modifier
        Column(Modifier.fillMaxSize().then(scrollModifier).padding(horizontal = 24.dp, vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.widthIn(max = 560.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("WePick", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.ExtraBold)
                    Text(state.session?.category?.label ?: "Your shared round", style = MaterialTheme.typography.bodySmall, color = colors.onSurfaceVariant)
                }
                Spacer(Modifier.weight(1f))
                Surface(color = colors.secondaryContainer, shape = CircleShape) {
                    Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(6.dp).background(colors.secondary, CircleShape))
                        Text("TOGETHER", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Row(Modifier.widthIn(max = 560.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                TokenChip("You", state.currentUser?.vetoTokensRemaining, Modifier.weight(1f))
                TokenChip(state.partner?.name ?: "Partner", state.partner?.vetoTokensRemaining, Modifier.weight(1f))
            }
            if (!state.isLoading && state.totalCount > 0) {
                Column(Modifier.widthIn(max = 560.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Your picks ${state.myCompletedCount}/${state.totalCount}", style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                        Text("Partner ${state.partnerCompletedCount}/${state.totalCount}", style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                    }
                    LinearProgressIndicator(progress = { state.myCompletedCount.toFloat() / state.totalCount }, modifier = Modifier.fillMaxWidth().clip(CircleShape))
                }
            }
            if (!matched) state.error?.let { ErrorNotice(it, onRetry, onDismissError, Modifier.widthIn(max = 560.dp)) }

            val deckHeight = if (scrollContent) Modifier.height(420.dp * maxOf(1f, fontScale)) else Modifier.weight(1f)
            Box(Modifier.widthIn(max = 440.dp).fillMaxWidth().then(deckHeight), contentAlignment = Alignment.Center) {
                when {
                    state.isLoading -> CircularProgressIndicator()
                    state.isSuperseded -> EmptyDeckMessage("✨", "Your next round is ready", "Your partner started something new. Let's join them.", "Join new round", onNewSession, !state.isBusy)
                    state.queue.isNotEmpty() && !matched -> {
                        // Reverse drawing order places the first durable, unvoted card on top.
                        state.queue.take(3).asReversed().forEach { item ->
                            val depth = state.queue.indexOf(item)
                            key(item.id) {
                                SwipeableDeckCard(
                                    item = item,
                                    enabled = state.canVote && depth == 0,
                                    depth = depth,
                                    onVote = onVote,
                                    modifier = Modifier.fillMaxSize().padding(bottom = 18.dp),
                                )
                            }
                        }
                    }
                    state.canSpin || (state.bothFinished && state.tieBreakerCandidates.isNotEmpty()) -> EmptyDeckMessage(
                        "🎡", "Let a little luck decide", "No shared yes yet. Spin from the ${state.tieBreakerCandidates.size} ideas at least one of you liked.",
                        if (state.isBusy) "Finding your pick…" else "Tie-breaker spin", onSpin, state.canSpin,
                    )
                    state.isEmptyResult -> EmptyDeckMessage("🌱", "A fresh start sounds good", "Neither of you has a remaining liked idea. Try a new mood or a different adventure.", "Start another round", onNewSession, !state.isBusy)
                    matched -> Text("Your shared yes is here.", style = MaterialTheme.typography.titleLarge)
                    state.session == null -> EmptyDeckMessage("☁️", "Let's reconnect", "Your shared round couldn't load.", "Retry", onRetry, !state.isBusy)
                    else -> EmptyDeckMessage("💌", "Your picks are in", "${state.partner?.name ?: "Your partner"} is still choosing. Your shared yes will appear here automatically.")
                }
            }
        }
        }
    }
    val session = state.session
    val item = state.matchedItem
    if (matched) {
        MatchCelebrationDialog(
            sessionId = session.sessionId,
            matchRevision = session.matchRevision,
            item = item,
            source = session.matchSource,
            candidates = state.tieBreakerCandidates,
            remainingTokens = state.currentUser?.vetoTokensRemaining ?: 0,
            isBusy = state.isBusy,
            error = state.error,
            onVeto = onVeto,
            onNewSession = onNewSession,
            onRetry = onRetry,
            onDismissError = onDismissError,
        )
    }
}

@Composable
private fun TokenChip(name: String, remaining: Int?, modifier: Modifier = Modifier) {
    Surface(modifier = modifier, shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Outlined.Shield, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Text(name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.labelMedium)
            Text("${remaining ?: "–"}/2", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun EmptyDeckMessage(emoji: String, title: String, description: String, actionLabel: String? = null, onAction: () -> Unit = {}, enabled: Boolean = true) {
    Column(Modifier.padding(20.dp).semantics { liveRegion = LiveRegionMode.Polite }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text(emoji, fontSize = 64.sp)
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text(description, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        if (actionLabel != null) Button(onClick = onAction, enabled = enabled, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text(actionLabel) }
    }
}

/** Horizontal gestures use raw pixel motion; release and cancellation settle with spring physics. */
@Composable
fun SwipeableDeckCard(item: DeckItem, enabled: Boolean, depth: Int, onVote: (Vote) -> Unit, modifier: Modifier = Modifier) {
    val scope = rememberCoroutineScope()
    val offset = remember(item.id) { Animatable(0f) }
    var rawOffset by remember(item.id) { mutableFloatStateOf(0f) }
    var dragging by remember(item.id) { mutableStateOf(false) }
    var animating by remember(item.id) { mutableStateOf(false) }
    val currentOnVote by rememberUpdatedState(onVote)

    // A rejected write leaves the same card in the queue; bring it back for a deliberate retry.
    LaunchedEffect(enabled, animating, dragging) {
        if (enabled && !animating && !dragging) offset.animateTo(0f, spring(dampingRatio = .72f, stiffness = 400f))
    }

    BoxWithConstraints(modifier) {
        val widthPx = with(LocalDensity.current) { maxWidth.toPx() }.coerceAtLeast(1f)
        val threshold = widthPx * .28f
        val x = if (dragging) rawOffset else offset.value
        val gesture = if (depth == 0) Modifier.pointerInput(item.id, enabled, animating, widthPx) {
            if (!enabled || animating) return@pointerInput
            detectHorizontalDragGestures(
                onDragStart = { rawOffset = offset.value; dragging = true },
                onHorizontalDrag = { change, dragAmount -> change.consume(); rawOffset += dragAmount },
                onDragCancel = {
                    scope.launch {
                        animating = true
                        offset.snapTo(rawOffset)
                        dragging = false
                        offset.animateTo(0f, spring(dampingRatio = .72f, stiffness = 400f))
                        animating = false
                    }
                },
                onDragEnd = {
                    scope.launch {
                        animating = true
                        val released = rawOffset
                        offset.snapTo(released)
                        dragging = false
                        if (abs(released) >= threshold) {
                            offset.animateTo(if (released > 0) widthPx * 1.6f else -widthPx * 1.6f, spring(dampingRatio = .88f, stiffness = 280f))
                            currentOnVote(if (released > 0) Vote.LIKE else Vote.PASS)
                        } else {
                            offset.animateTo(0f, spring(dampingRatio = .65f, stiffness = 380f))
                        }
                        animating = false
                    }
                },
            )
        } else Modifier.clearAndSetSemantics { }

        Card(
            modifier = Modifier.fillMaxSize().graphicsLayer {
                translationX = x
                translationY = depth * 12.dp.toPx()
                rotationZ = (x / widthPx * 17f).coerceIn(-24f, 24f)
                scaleX = 1f - depth * .045f
                scaleY = 1f - depth * .045f
                alpha = (1f - abs(x) / (widthPx * 2f)).coerceIn(0f, 1f)
            }.then(gesture),
            shape = RoundedCornerShape(28.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            elevation = CardDefaults.cardElevation(defaultElevation = if (depth == 0) 8.dp else 2.dp),
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.fillMaxWidth().weight(1f).background(illustrationBrush(item.category)), contentAlignment = Alignment.Center) {
                    Box(Modifier.size(176.dp).background(Color.White.copy(alpha = .13f), CircleShape))
                    Box(Modifier.size(128.dp).border(1.dp, Color.White.copy(alpha = .22f), CircleShape))
                    Text(item.emoji, fontSize = 82.sp, modifier = Modifier.semantics { contentDescription = "Illustration for ${item.title}" })
                    Surface(Modifier.align(Alignment.TopStart).padding(16.dp), color = Color.Black.copy(alpha = .22f), shape = CircleShape) {
                        Text(item.category.label, Modifier.padding(horizontal = 12.dp, vertical = 7.dp), color = Color.White, style = MaterialTheme.typography.labelMedium)
                    }
                    if (depth == 0 && abs(x) > 1f) {
                        val like = x > 0
                        Text(
                            if (like) "LIKE" else "NOPE",
                            modifier = Modifier.align(if (like) Alignment.TopEnd else Alignment.TopStart).padding(top = 72.dp, start = 24.dp, end = 24.dp)
                                .graphicsLayer { rotationZ = if (like) 12f else -12f }
                                .alpha((abs(x) / threshold).coerceIn(0f, 1f))
                                .border(3.dp, Color.White, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 6.dp),
                            color = Color.White,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                        )
                    }
                }
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(item.title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                            Text(item.priceTier.label, Modifier.padding(horizontal = 10.dp, vertical = 5.dp), style = MaterialTheme.typography.labelMedium)
                        }
                        Text(item.vibeTags.joinToString(" · ") { it.label }, Modifier.padding(top = 4.dp), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(item.description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

private fun illustrationBrush(category: Category): Brush = Brush.linearGradient(
    when (category) {
        Category.FOOD -> listOf(Color(0xFFB75C46), Color(0xFF663C4B))
        Category.OUTINGS -> listOf(Color(0xFF588A80), Color(0xFF244C54))
        Category.MOVIES -> listOf(Color(0xFF856FA5), Color(0xFF3F355F))
        Category.ACTIVITIES -> listOf(Color(0xFFB48A45), Color(0xFF70504B))
    },
)
