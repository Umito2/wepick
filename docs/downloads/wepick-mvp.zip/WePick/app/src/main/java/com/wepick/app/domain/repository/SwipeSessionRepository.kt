package com.wepick.app.domain.repository

import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import kotlinx.coroutines.flow.Flow

interface SwipeSessionRepository {
    fun observeSession(sessionId: String): Flow<SwipeSession?>
    fun observeVotes(sessionId: String): Flow<List<VoteState>>
    suspend fun createSession(roomId: String, filter: SessionFilter): String
    suspend fun castVote(sessionId: String, itemId: String, vote: Vote)
    suspend fun vetoMatch(sessionId: String, expectedRevision: Long)
    /** Returns the persisted shared winner, or null when neither partner liked any item. */
    suspend fun spinTieBreaker(sessionId: String): String?
}
