package com.wepick.app.domain.model

data class SessionFilter(
    val category: Category,
    val budget: BudgetTier,
    val mood: Mood,
) {
    fun accepts(item: DeckItem): Boolean =
        item.category == category && budget.includes(item.priceTier) && mood in item.vibeTags
}
