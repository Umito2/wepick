package com.wepick.app.presentation.filter

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.Mood
import com.wepick.app.presentation.common.ErrorNotice

@Composable
fun CategoryFilterScreen(
    state: FilterUiState,
    onCategory: (Category) -> Unit,
    onBudget: (BudgetTier) -> Unit,
    onMood: (Mood) -> Unit,
    onStart: () -> Unit,
    onResume: () -> Unit,
    onRetry: () -> Unit,
    onDismissError: () -> Unit,
) {
    val enabled = !state.isBusy && !state.isLoading
    Scaffold(
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Column(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 24.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Button(onClick = onStart, enabled = enabled && state.availableItems > 0, modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth().height(56.dp)) {
                        if (state.isBusy || state.isLoading) CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp)
                        else Text("Find our yes", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("${state.availableItems} possibilities · One shared deck", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding), horizontalAlignment = Alignment.CenterHorizontally) {
            Column(Modifier.widthIn(max = 560.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(22.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(22.dp))
                    Text("WePick", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.weight(1f))
                    Text("YOUR NEXT LITTLE PLAN", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("What are we\nin the mood for?", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text("Set the vibe, then let your swipes do the talking.", style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                state.error?.let { ErrorNotice(it, onRetry, onDismissError) }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionLabel("01", "Pick a little adventure")
                    Category.entries.chunked(2).forEach { categories ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            categories.forEach { category ->
                                CategoryCard(category, category == state.category, enabled, { onCategory(category) }, Modifier.weight(1f))
                            }
                        }
                    }
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionLabel("02", "Budget for two (EGP)")
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        BudgetTier.entries.forEach { budget ->
                            FilterChip(
                                selected = budget == state.budget,
                                onClick = { onBudget(budget) },
                                enabled = enabled,
                                modifier = Modifier.weight(1f).heightIn(min = 56.dp),
                                label = {
                                    Text(
                                        budget.filterLabel,
                                        Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                                        style = MaterialTheme.typography.labelLarge,
                                    )
                                },
                            )
                        }
                    }
                    Text("Illustrative budget guides; confirm menu/venue prices. Lower tiers are included.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionLabel("03", "Match the energy")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Mood.entries.forEach { mood ->
                            FilterChip(
                                selected = mood == state.mood,
                                onClick = { onMood(mood) },
                                enabled = enabled,
                                modifier = Modifier.weight(1f),
                                label = { Text(mood.label, maxLines = 1) },
                            )
                        }
                    }
                }
                if (state.previousSessionId != null) {
                    TextButton(onClick = onResume, modifier = Modifier.align(Alignment.CenterHorizontally), enabled = enabled) { Text("Open our last round") }
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(number: String, title: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(number, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun CategoryCard(category: Category, selected: Boolean, enabled: Boolean, onClick: () -> Unit, modifier: Modifier) {
    val colors = MaterialTheme.colorScheme
    Card(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) colors.primaryContainer else colors.surfaceContainer),
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) colors.primary else colors.outlineVariant),
    ) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(category.emoji, fontSize = 30.sp)
                Spacer(Modifier.weight(1f))
                if (selected) Icon(Icons.Rounded.CheckCircle, "Selected", tint = colors.primary, modifier = Modifier.size(20.dp))
            }
            Text(category.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}
