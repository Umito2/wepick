package com.wepick.app.data.remote

import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.functions.FirebaseFunctionsException
import com.wepick.app.domain.model.WePickException
import kotlinx.coroutines.CancellationException

/** Bound single requests while preserving cancellation from a screen or parent coroutine. */
internal suspend fun <T> firebaseOperation(block: suspend () -> T): T = try {
    withFirebaseDeadline(block = block)
} catch (cancelled: CancellationException) {
    throw cancelled
} catch (error: Exception) {
    throw error.asWePickException()
}

internal fun Throwable.asWePickException(): WePickException {
    if (this is WePickException) return this
    val message = when (this) {
        is FirebaseNetworkException -> "You appear to be offline. Reconnect and try again."
        is FirebaseAuthException -> "Your sign-in has expired. Please sign in again."
        is FirebaseFirestoreException -> when (code) {
            FirebaseFirestoreException.Code.UNAVAILABLE,
            FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ->
                "We couldn't reach your partner's session. Reconnect and try again."
            FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "This session is no longer available to your account. Return to your room."
            FirebaseFirestoreException.Code.UNAUTHENTICATED -> "Please sign in again to continue."
            FirebaseFirestoreException.Code.ABORTED ->
                "Your partner updated the session at the same time. Please try again."
            else -> "We couldn't sync this change. Please try again."
        }
        is FirebaseFunctionsException -> when (code) {
            FirebaseFunctionsException.Code.UNAVAILABLE,
            FirebaseFunctionsException.Code.DEADLINE_EXCEEDED ->
                "We couldn't reach WePick. Check your connection and try again."
            FirebaseFunctionsException.Code.UNAUTHENTICATED -> "Please sign in again to continue."
            FirebaseFunctionsException.Code.INVALID_ARGUMENT,
            FirebaseFunctionsException.Code.FAILED_PRECONDITION,
            FirebaseFunctionsException.Code.ALREADY_EXISTS,
            FirebaseFunctionsException.Code.NOT_FOUND,
            FirebaseFunctionsException.Code.RESOURCE_EXHAUSTED ->
                this.message?.takeIf(String::isNotBlank) ?: "This action is unavailable. Please try again."
            FirebaseFunctionsException.Code.PERMISSION_DENIED ->
                "This action is not available to your account. Return to your room."
            else -> "We couldn't finish this action. Please try again."
        }
        else -> "Something interrupted the update. Please try again."
    }
    return WePickException(message, this)
}

internal fun requireDocumentId(value: String) {
    if (!value.matches(Regex("[A-Za-z0-9_-]{1,128}"))) {
        throw WePickException("This session link is invalid. Return to your room.")
    }
}
