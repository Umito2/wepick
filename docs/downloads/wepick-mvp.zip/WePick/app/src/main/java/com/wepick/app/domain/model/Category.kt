package com.wepick.app.domain.model

enum class Category(val label: String, val emoji: String) {
    FOOD("Food delivery", "🍜"),
    OUTINGS("Cafe outing", "☕"),
    MOVIES("Cinema / movie", "🎬"),
    ACTIVITIES("Weekend activity", "🎨"),
}
