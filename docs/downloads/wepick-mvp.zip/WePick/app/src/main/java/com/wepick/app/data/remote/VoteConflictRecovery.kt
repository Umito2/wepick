package com.wepick.app.data.remote

import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState

internal enum class VoteRaceResolution { ALREADY_COMMITTED, RETRY, REJECT }

/** Decide whether fresh server state proves a recoverable concurrent first-LIKE race. */
internal fun resolveVoteRace(
    session: SwipeSession,
    room: CoupleRoom,
    swipe: VoteState,
    sessionId: String,
    itemId: String,
    uid: String,
    vote: Vote,
): VoteRaceResolution {
    if (!room.contains(uid) || !room.isPaired || room.roomId != session.roomId ||
        room.activeSessionId != sessionId || session.sessionId != sessionId ||
        itemId !in session.itemIds || swipe.itemId != itemId
    ) return VoteRaceResolution.REJECT
    val isUser1 = uid == room.user1Id
    val ownVote = swipe.voteFor(isUser1)
    if (ownVote == vote) return VoteRaceResolution.ALREADY_COMMITTED
    return if (session.status == SessionStatus.ACTIVE && swipe.vetoedBy == null && ownVote == null &&
        vote == Vote.LIKE && swipe.voteFor(!isUser1) == Vote.LIKE
    ) VoteRaceResolution.RETRY else VoteRaceResolution.REJECT
}
