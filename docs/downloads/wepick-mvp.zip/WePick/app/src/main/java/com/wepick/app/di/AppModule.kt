package com.wepick.app.di

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.wepick.app.BuildConfig
import com.wepick.app.data.local.LocalDeckDataSource
import com.wepick.app.data.remote.FirebaseAuthRepository
import com.wepick.app.data.remote.FirebaseCoupleRepository
import com.wepick.app.data.remote.FirebaseSwipeSessionRepository
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.domain.repository.DeckRepository
import com.wepick.app.domain.repository.SwipeSessionRepository
import dagger.Binds
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {
    @Binds @Singleton abstract fun auth(impl: FirebaseAuthRepository): AuthRepository
    @Binds @Singleton abstract fun couples(impl: FirebaseCoupleRepository): CoupleRepository
    @Binds @Singleton abstract fun sessions(impl: FirebaseSwipeSessionRepository): SwipeSessionRepository
    @Binds @Singleton abstract fun deck(impl: LocalDeckDataSource): DeckRepository
}

@Module
@InstallIn(SingletonComponent::class)
object FirebaseModule {
    @Provides @Singleton
    fun auth(): FirebaseAuth = FirebaseAuth.getInstance().apply {
        if (BuildConfig.USE_FIREBASE_EMULATORS) useEmulator(BuildConfig.EMULATOR_HOST, 9099)
    }

    @Provides @Singleton
    fun firestore(): FirebaseFirestore = FirebaseFirestore.getInstance().apply {
        firestoreSettings = FirebaseFirestoreSettings.Builder()
            // Pairing data is private. Avoid leaving another account's cached documents on disk.
            .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
            .build()
        if (BuildConfig.USE_FIREBASE_EMULATORS) useEmulator(BuildConfig.EMULATOR_HOST, 8080)
    }

}

