package com.wepick.app.data.remote

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.GoogleAuthProvider
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.AuthRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseAuthRepository @Inject constructor(
    private val auth: FirebaseAuth,
    private val api: FirebaseCallableApi,
) : AuthRepository {
    private val signInMutex = Mutex()
    override val userId: String? get() = auth.currentUser?.uid

    override fun observeAuth(): Flow<String?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { trySend(it.currentUser?.uid) }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }.distinctUntilChanged().onEach { uid ->
        // Covers process restart and a previous sign-in interrupted before profile creation.
        if (uid != null) ensureProfile()
    }

    override suspend fun signInAnonymously(name: String): Unit = signInMutex.withLock {
        firebaseOperation {
            val cleanName = name.trim()
            if (cleanName.length !in 1..40) throw WePickException("Please enter a name between 1 and 40 characters.")
            if (auth.currentUser == null) auth.signInAnonymously().await()
            ensureProfile(cleanName)
        }
    }

    override suspend fun signInWithGoogle(idToken: String): Unit = signInMutex.withLock {
        firebaseOperation {
            if (idToken.isBlank()) throw WePickException("Google did not return an identity token. Please try again.")
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val current = auth.currentUser
            try {
                if (current?.isAnonymous == true) {
                    // Linking preserves the UID, room membership, votes, and token balance.
                    current.linkWithCredential(credential).await()
                } else {
                    auth.signInWithCredential(credential).await()
                }
            } catch (collision: FirebaseAuthUserCollisionException) {
                throw WePickException(
                    "That Google account already has a WePick profile. Your current couple is still safe. " +
                        "Use a different Google account to save this profile.",
                    collision,
                )
            }
            ensureProfile(auth.currentUser?.displayName?.take(40))
        }
    }

    override suspend fun signOut() = signInMutex.withLock { auth.signOut() }

    private suspend fun ensureProfile(name: String? = null) {
        val payload = name?.takeIf(String::isNotBlank)?.let { mapOf("name" to it) } ?: emptyMap()
        api.call("ensureUser", payload)
    }
}

