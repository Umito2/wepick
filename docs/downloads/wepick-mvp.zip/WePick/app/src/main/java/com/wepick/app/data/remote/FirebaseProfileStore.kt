package com.wepick.app.data.remote

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.WePickException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.tasks.await

/** Spark-compatible profile writes. Firestore rules independently validate every invariant. */
@Singleton
class FirebaseProfileStore @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
) {
    private val ensureMutex = Mutex()
    internal fun requireUserId(): String = auth.currentUser?.uid
        ?: throw WePickException("Please sign in before continuing.")

    suspend fun ensureUser(name: String? = null): Unit = firebaseOperation {
        ensureMutex.withLock {
            val uid = requireUserId()
            val cleanName = name?.trim()?.also {
                if (it.length !in 1..40) throw WePickException("Please enter a name between 1 and 40 characters.")
            }
            val ref = firestore.collection("users").document(uid)
            val fallbackName = auth.currentUser?.displayName?.trim()?.take(40)?.takeIf(String::isNotBlank) ?: "Partner"
            try {
                firestore.runTransaction { tx ->
                    val snapshot = tx.get(ref)
                    if (!snapshot.exists()) {
                        tx.set(ref, mapOf(
                            "uid" to uid,
                            "name" to (cleanName ?: fallbackName),
                            "partnerId" to null,
                            "coupleRoomId" to null,
                            "vetoTokensRemaining" to 2,
                            "lastTokenResetTimestamp" to FieldValue.serverTimestamp(),
                        ))
                    } else if (cleanName != null && snapshot.toUser().name != cleanName) {
                        // Keep name changes separate from reset, pairing and veto transitions.
                        tx.update(ref, "name", cleanName)
                    }
                    Unit
                }.await()
            } catch (failure: FirebaseFirestoreException) {
                if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
                // Another device or a late acknowledgement may have created this same UID's
                // profile. Never repeat the initial token grant against an existing profile.
                val current = ref.get(Source.SERVER).await()
                if (!current.exists()) throw failure
                val existing = current.toUser()
                if (cleanName != null && existing.name != cleanName) ref.update("name", cleanName).await()
            }
            refreshTokens(includePartner = false)
        }
    }

    /** Refreshing a partner is allowed only for reciprocal, already-paired profiles. */
    suspend fun refreshTokens(includePartner: Boolean = true): Unit = firebaseOperation {
        val uid = requireUserId()
        val now = serverNow(uid)
        val ownRef = firestore.collection("users").document(uid)
        var attemptedOwn: User? = null
        try {
            firestore.runTransaction { tx ->
                val ownSnapshot = tx.get(ownRef)
                val own = ownSnapshot.requireUser()
                attemptedOwn = own
                val partnerSnapshot = if (includePartner && own.partnerId != null) {
                    tx.get(firestore.collection("users").document(own.partnerId)).also { partner ->
                        if (partner.requireUser().partnerId != uid || partner.toUser().coupleRoomId != own.coupleRoomId) {
                            throw WePickException("Your partner link has changed. Return to pairing.")
                        }
                    }
                } else null
                // Finish every read before writing either balance.
                resetIfDue(tx, ownSnapshot, now)
                if (partnerSnapshot != null) resetIfDue(tx, partnerSnapshot, now)
                Unit
            }.await()
        } catch (failure: FirebaseFirestoreException) {
            if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
            val attempted = attemptedOwn ?: throw failure
            val currentOwn = ownRef.get(Source.SERVER).await().requireUser()
            val currentPartner = if (includePartner && attempted.partnerId != null && currentOwn.partnerId == attempted.partnerId) {
                firestore.collection("users").document(attempted.partnerId).get(Source.SERVER).await().requireUser()
            } else null
            // Acknowledge only an already-satisfied reset for the same reciprocal identities.
            // A still-due balance or changed relationship surfaces the original denial.
            if (!canAcknowledgeTokenRefresh(attempted, currentOwn, currentPartner, includePartner, now.toDate().time)) {
                throw failure
            }
        }
    }

    /** A private timestamp probe avoids trusting a fast or slow device clock for weekly budgets. */
    internal suspend fun serverNow(uid: String = requireUserId()): Timestamp {
        val ref = firestore.collection("request_times").document(uid)
        ref.set(mapOf("now" to FieldValue.serverTimestamp())).await()
        return ref.get(Source.SERVER).await().getTimestamp("now")
            ?: throw WePickException("We couldn't verify the server time. Reconnect and try again.")
    }

    private fun resetIfDue(tx: Transaction, snapshot: DocumentSnapshot, now: Timestamp) {
        if (weeklyTokenBalance(snapshot.requireUser(), now.toDate().time).resetDue) {
            tx.update(snapshot.reference, mapOf(
                "vetoTokensRemaining" to 2,
                "lastTokenResetTimestamp" to FieldValue.serverTimestamp(),
            ))
        }
    }
}

internal fun DocumentSnapshot.requireUser(): User {
    if (!exists()) throw WePickException("Your profile is not ready. Return to sign-in and retry.")
    return toUser()
}
