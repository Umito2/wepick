package com.wepick.app.presentation.preview

import android.content.res.Configuration
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.User
import com.wepick.app.presentation.filter.CategoryFilterScreen
import com.wepick.app.presentation.filter.FilterUiState
import com.wepick.app.presentation.pairing.PairingScreen
import com.wepick.app.presentation.pairing.PairingUiState
import com.wepick.app.presentation.swipe.SwipeDeckScreen
import com.wepick.app.presentation.swipe.SwipeUiState
import com.wepick.app.presentation.theme.WePickTheme

@Preview(name = "Pairing · light", widthDp = 390, heightDp = 844, showBackground = true)
@Preview(name = "Pairing · dark", widthDp = 390, heightDp = 844, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun PairingPreview() {
    WePickTheme {
        PairingScreen(PairingUiState(isLoading = false), {}, {}, {}, {}, {}, {})
    }
}

@Preview(name = "Filters · light", widthDp = 390, heightDp = 844, showBackground = true)
@Preview(name = "Filters · dark", widthDp = 390, heightDp = 844, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
private fun FiltersPreview() {
    WePickTheme {
        CategoryFilterScreen(FilterUiState(isLoading = false, availableItems = 4), {}, {}, {}, {}, {}, {}, {})
    }
}

@Preview(name = "Swipe · light", widthDp = 390, heightDp = 844, showBackground = true)
@Preview(name = "Swipe · dark", widthDp = 390, heightDp = 844, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Preview(name = "Swipe · landscape", widthDp = 844, heightDp = 390)
@Preview(name = "Swipe · large text", widthDp = 390, heightDp = 844, fontScale = 1.5f)
@Composable
private fun SwipePreview() {
    val items = listOf(
        DeckItem("a", "Coffee & a slow morning", Category.OUTINGS, BudgetTier.LOW, setOf(Mood.CHILL, Mood.COZY), "Find a sunny corner, order your favorite drinks, and stay a little longer.", "☕"),
        DeckItem("b", "A bookstore café date", Category.OUTINGS, BudgetTier.LOW, setOf(Mood.COZY), "Choose a book for each other over a warm cup.", "📚"),
        DeckItem("c", "Tea for two", Category.OUTINGS, BudgetTier.LOW, setOf(Mood.CHILL), "A pot of tea and nowhere else you need to be.", "🫖"),
    )
    WePickTheme {
        SwipeDeckScreen(
            SwipeUiState(
                isLoading = false,
                session = SwipeSession("preview", "room", Category.OUTINGS, BudgetTier.MEDIUM, Mood.CHILL, itemIds = items.map { it.id }),
                room = CoupleRoom("room", "ABC123", "alex", "sam", "preview", 0),
                currentUser = User("alex", "Alex"),
                partner = User("sam", "Sam", vetoTokensRemaining = 1),
                queue = items,
                totalCount = 3,
            ),
            {}, {}, {}, {}, {}, {},
        )
    }
}
