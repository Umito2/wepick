package com.wepick.app.data.remote

import com.google.android.gms.tasks.Task
import kotlinx.coroutines.tasks.await

/**
 * Retain an SDK request after its caller stops waiting. The owner must serialize calls with
 * its mutex. In particular, an auth retry must not create a second anonymous identity while
 * the first sign-in is still completing inside Firebase.
 */
internal class InFlightFirebaseTask<T> {
    private var pending: Task<T>? = null

    suspend fun awaitOrStart(start: () -> Task<T>): T {
        val task = pending ?: start().also { pending = it }
        return awaitTracked(task)
    }

    suspend fun awaitPending() {
        pending?.let { awaitTracked(it) }
    }

    private suspend fun awaitTracked(task: Task<T>): T = try {
        task.await()
    } finally {
        // Coroutine cancellation alone does not finish a Firebase Task: keep it for the retry.
        if (task.isComplete && pending === task) pending = null
    }
}
