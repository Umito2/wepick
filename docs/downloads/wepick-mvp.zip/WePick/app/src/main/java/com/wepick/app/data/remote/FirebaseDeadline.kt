package com.wepick.app.data.remote

import com.wepick.app.BuildConfig
import com.wepick.app.domain.model.WePickException
import kotlinx.coroutines.withTimeoutOrNull

internal val firebaseRequestTimeoutMillis: Long
    get() = if (BuildConfig.USE_FIREBASE_EMULATORS) 8_000L else 30_000L

internal val firebaseTimeoutMessage: String
    get() = if (BuildConfig.USE_FIREBASE_EMULATORS) {
        "The developer-preview backend didn't respond. Tap Try browser demo, or check the Firebase setup before retrying."
    } else {
        "WePick didn't respond in time. Check your connection and try again."
    }

private class CompletedFirebaseCall<T>(val value: T)

/**
 * Bound one awaited operation, not the lifetime of a real-time listener.
 *
 * withTimeoutOrNull recognizes only its own timeout. Parent cancellation and nested timeouts
 * still propagate, while boxing distinguishes a successful null result from deadline expiry.
 * Cancelling an await does not claim to cancel the underlying Firebase SDK request.
 */
internal suspend fun <T> withFirebaseDeadline(
    timeoutMillis: Long = firebaseRequestTimeoutMillis,
    timeoutMessage: String = firebaseTimeoutMessage,
    block: suspend () -> T,
): T {
    val completed = withTimeoutOrNull(timeoutMillis) { CompletedFirebaseCall(block()) }
        ?: throw WePickException(timeoutMessage)
    return completed.value
}
