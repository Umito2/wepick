package com.wepick.app.domain.repository

import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    val userId: String?
    fun observeAuth(): Flow<String?>
    suspend fun signInAnonymously(name: String)
    suspend fun signInWithGoogle(idToken: String)
    suspend fun signOut()
}
