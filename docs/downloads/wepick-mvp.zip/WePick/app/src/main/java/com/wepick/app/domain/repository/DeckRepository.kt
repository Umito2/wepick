package com.wepick.app.domain.repository

import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.SessionFilter

interface DeckRepository {
    fun allItems(): List<DeckItem>
    fun itemsFor(filter: SessionFilter): List<DeckItem>
    fun find(id: String): DeckItem?
}
