package com.wepick.app.data.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.Source
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.CoupleRepository
import java.util.Locale
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseCoupleRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val profiles: FirebaseProfileStore,
) : CoupleRepository {
    private val random = SecureRandom()
    override fun observeUser(uid: String): Flow<User?> {
        requireDocumentId(uid)
        return firestore.collection("users").document(uid).observeDocument { it.toUser() }
    }

    override fun observeRoom(roomId: String): Flow<CoupleRoom?> {
        requireDocumentId(roomId)
        return firestore.collection("couple_rooms").document(roomId).observeDocument { it.toRoom() }
    }

    override suspend fun createInvite(): CoupleRoom = firebaseOperation {
        val uid = profiles.requireUserId()
        val ownRef = firestore.collection("users").document(uid)
        repeat(8) {
            val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
            val code = CharArray(6) { alphabet[random.nextInt(alphabet.length)] }.concatToString()
            val roomRef = firestore.collection("couple_rooms").document()
            val inviteRef = firestore.collection("invite_codes").document(code)
            try {
                val roomId = firestore.runTransaction { tx ->
                    val own = tx.get(ownRef).requireUser()
                    if (own.coupleRoomId != null) {
                        val existing = tx.get(firestore.collection("couple_rooms").document(own.coupleRoomId))
                        if (!existing.exists() || !existing.toRoom().contains(uid)) {
                            throw WePickException("Your room link needs refreshing. Return to pairing and retry.")
                        }
                        return@runTransaction own.coupleRoomId
                    }
                    if (own.partnerId != null) throw WePickException("You are already paired with a partner.")
                    // Blind create: rules reject an existing code. Reading uncharged codes is forbidden.
                    tx.set(roomRef, mapOf(
                        "roomId" to roomRef.id, "inviteCode" to code,
                        "user1Id" to uid, "user2Id" to null, "activeSessionId" to null,
                        "createdAt" to FieldValue.serverTimestamp(),
                    ))
                    tx.set(inviteRef, mapOf(
                        "roomId" to roomRef.id, "consumed" to false,
                        "createdAt" to FieldValue.serverTimestamp(),
                    ))
                    tx.update(ownRef, "coupleRoomId", roomRef.id)
                    roomRef.id
                }.await()
                return@firebaseOperation readRoom(roomId)
            } catch (failure: FirebaseFirestoreException) {
                if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
                // A denied reservation can be a code collision. Limit allocation attempts and
                // confirm this account is still eligible; never enumerate candidate code documents.
                val own = ownRef.get(Source.SERVER).await().requireUser()
                if (own.coupleRoomId != null) return@firebaseOperation readRoom(own.coupleRoomId)
                if (own.partnerId != null) throw failure
            }
        }
        throw WePickException("We couldn't reserve an invite code. Please retry.")
    }

    override suspend fun joinRoom(code: String): CoupleRoom = firebaseOperation {
        val normalized = code.trim().uppercase(Locale.ROOT)
        if (!normalized.matches(Regex("[A-Z0-9]{6}"))) {
            throw WePickException("Enter your partner's six-character invite code.")
        }
        val uid = profiles.requireUserId()
        val ownRef = firestore.collection("users").document(uid)
        val initial = ownRef.get(Source.SERVER).await().requireUser()
        if (initial.coupleRoomId != null) {
            val existing = readRoom(initial.coupleRoomId)
            if (existing.inviteCode == normalized) {
                if (existing.user2Id == uid) return@firebaseOperation existing
                throw WePickException("Share this code with your partner; it belongs to you.")
            }
            if (initial.partnerId != null || existing.isPaired) {
                throw WePickException("You are already paired with a partner.")
            }
        }
        chargeJoinAttempt(uid, normalized)
        try {
            val roomId = firestore.runTransaction { tx ->
                val own = tx.get(ownRef).requireUser()
                val inviteRef = firestore.collection("invite_codes").document(normalized)
                val invite = tx.get(inviteRef)
                if (!invite.exists()) throw WePickException("This invite is invalid or unavailable.")
                val targetId = (invite.get("roomId") as? String)?.also(::requireDocumentId)
                    ?: throw WePickException("This invite is no longer available.")
                val targetRef = firestore.collection("couple_rooms").document(targetId)
                val targetSnapshot = tx.get(targetRef)
                if (!targetSnapshot.exists()) throw WePickException("This invite is no longer available.")
                val target = targetSnapshot.toRoom()
                if (target.user1Id == uid) throw WePickException("Share this code with your partner; it belongs to you.")
                if (target.user2Id == uid && own.coupleRoomId == targetId) return@runTransaction targetId
                if (invite.get("consumed") != false || target.user2Id != null || own.partnerId != null) {
                    throw WePickException("This invite is already in use.")
                }
                val abandoned = own.coupleRoomId?.let { previousId ->
                    val snapshot = tx.get(firestore.collection("couple_rooms").document(previousId))
                    if (!snapshot.exists()) throw WePickException("Your previous invite is no longer available.")
                    snapshot.toRoom().also { room ->
                        if (room.user1Id != uid || room.user2Id != null || room.activeSessionId != null) {
                            throw WePickException("You are already paired with a partner.")
                        }
                    }
                }
                // No host-profile read before pairing. Rules validate this narrow blind update
                // against the room and both reciprocal profile links in the same atomic write.
                tx.update(targetRef, "user2Id", uid)
                tx.update(ownRef, mapOf("partnerId" to target.user1Id, "coupleRoomId" to targetId))
                tx.update(firestore.collection("users").document(target.user1Id), "partnerId", uid)
                tx.update(inviteRef, "consumed", true)
                if (abandoned != null) {
                    tx.delete(firestore.collection("couple_rooms").document(abandoned.roomId))
                    tx.update(firestore.collection("invite_codes").document(abandoned.inviteCode), "consumed", true)
                }
                targetId
            }.await()
            readRoom(roomId)
        } catch (failure: FirebaseFirestoreException) {
            if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
            // A competing join can consume the code before a stale transaction retries.
            val own = ownRef.get(Source.SERVER).await().requireUser()
            if (own.coupleRoomId != null && own.partnerId != null) {
                val joined = readRoom(own.coupleRoomId)
                if (joined.inviteCode == normalized && joined.user2Id == uid) return@firebaseOperation joined
            }
            throw WePickException("This invite is already in use or no longer available. Ask your partner for a new code.", failure)
        }
    }

    override suspend fun refreshTokens() {
        profiles.refreshTokens()
    }

    private suspend fun chargeJoinAttempt(uid: String, code: String) {
        val now = profiles.serverNow(uid)
        val ref = firestore.collection("join_attempts").document(uid)
        firestore.runTransaction { tx ->
            val previous = tx.get(ref)
            val windowStart = previous.getTimestamp("windowStart")
            val decision = nextJoinAttempt(previous.getLong("count"), windowStart?.toDate()?.time, now.toDate().time)
            tx.set(ref, mapOf(
                "count" to decision.count,
                "windowStart" to if (decision.startsNewWindow) FieldValue.serverTimestamp() else windowStart,
                "lastCode" to code,
            ))
            Unit
        }.await()
    }

    /** Read the server-confirmed room after the atomic pairing transaction, never a stale cached room. */
    private suspend fun readRoom(roomId: String): CoupleRoom {
        val document = firestore.collection("couple_rooms").document(roomId).get(Source.SERVER).await()
        if (!document.exists()) throw WePickException("This invite is no longer available. Please create another.")
        return document.toRoom()
    }
}
