package com.wepick.app.data.remote

import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Source
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.CoupleRepository
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseCoupleRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val api: FirebaseCallableApi,
) : CoupleRepository {
    override fun observeUser(uid: String): Flow<User?> {
        requireDocumentId(uid)
        return firestore.collection("users").document(uid).observeDocument { it.toUser() }
    }

    override fun observeRoom(roomId: String): Flow<CoupleRoom?> {
        requireDocumentId(roomId)
        return firestore.collection("couple_rooms").document(roomId).observeDocument { it.toRoom() }
    }

    override suspend fun createInvite(): CoupleRoom = firebaseOperation {
        val roomId = api.call("createInvite").requiredId("roomId")
        readRoom(roomId)
    }

    override suspend fun joinRoom(code: String): CoupleRoom = firebaseOperation {
        val normalized = code.trim().uppercase(Locale.ROOT)
        if (!normalized.matches(Regex("[A-Z0-9]{6}"))) {
            throw WePickException("Enter your partner's six-character invite code.")
        }
        val roomId = api.call("joinRoom", mapOf("code" to normalized)).requiredId("roomId")
        readRoom(roomId)
    }

    override suspend fun refreshTokens() {
        api.call("refreshTokens")
    }

    /** Read the server-confirmed room after the atomic pairing transaction, never a stale cached room. */
    private suspend fun readRoom(roomId: String): CoupleRoom {
        val document = firestore.collection("couple_rooms").document(roomId).get(Source.SERVER).await()
        if (!document.exists()) throw WePickException("This invite is no longer available. Please create another.")
        return document.toRoom()
    }
}
