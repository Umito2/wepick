package com.wepick.app.presentation.common

import com.wepick.app.domain.model.WePickException
import kotlinx.coroutines.CancellationException

/** Keep cancellation cooperative and only display messages intentionally exposed by the domain. */
internal fun Throwable.presentationMessage(fallback: String): String {
    if (this is CancellationException) throw this
    return if (this is WePickException) message ?: fallback else fallback
}
