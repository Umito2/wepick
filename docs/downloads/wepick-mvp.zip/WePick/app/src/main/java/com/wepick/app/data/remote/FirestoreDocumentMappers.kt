package com.wepick.app.data.remote

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException

private fun invalidDocument(): Nothing =
    throw WePickException("This room needs an updated version of WePick. Please update the app and retry.")

private fun DocumentSnapshot.text(field: String): String =
    (get(field) as? String)?.takeIf(String::isNotBlank) ?: invalidDocument()

private fun DocumentSnapshot.optionalText(field: String): String? = when (val value = get(field)) {
    null -> null
    is String -> value.takeIf(String::isNotBlank) ?: invalidDocument()
    else -> invalidDocument()
}

private fun DocumentSnapshot.identity(field: String): String =
    text(field).also { if (it != id) invalidDocument() }

private inline fun <reified T : Enum<T>> DocumentSnapshot.enum(field: String): T =
    enumValues<T>().firstOrNull { it.name == text(field) } ?: invalidDocument()

private inline fun <reified T : Enum<T>> DocumentSnapshot.optionalEnum(field: String): T? =
    optionalText(field)?.let { value -> enumValues<T>().firstOrNull { it.name == value } ?: invalidDocument() }

private fun DocumentSnapshot.millis(field: String): Long =
    (get(field) as? Timestamp)?.toDate()?.time ?: invalidDocument()

internal fun DocumentSnapshot.toUser(): User = User(
    uid = identity("uid"),
    name = text("name"),
    partnerId = optionalText("partnerId"),
    coupleRoomId = optionalText("coupleRoomId"),
    vetoTokensRemaining = (get("vetoTokensRemaining") as? Long)?.takeIf { it in 0L..2L }?.toInt()
        ?: invalidDocument(),
    lastTokenResetTimestamp = millis("lastTokenResetTimestamp"),
)

internal fun DocumentSnapshot.toRoom(): CoupleRoom = CoupleRoom(
    roomId = identity("roomId"),
    inviteCode = text("inviteCode").also { if (!it.matches(Regex("[A-Z0-9]{6}"))) invalidDocument() },
    user1Id = text("user1Id"),
    user2Id = optionalText("user2Id"),
    activeSessionId = optionalText("activeSessionId"),
    createdAt = millis("createdAt"),
).also { if (it.user1Id == it.user2Id) invalidDocument() }

internal fun DocumentSnapshot.toSession(): SwipeSession {
    val ids = (get("itemIds") as? List<*>)?.map { value ->
        (value as? String)?.takeIf(String::isNotBlank) ?: invalidDocument()
    } ?: invalidDocument()
    if (ids.isEmpty() || ids.size > 20 || ids.distinct().size != ids.size) invalidDocument()
    return SwipeSession(
        sessionId = identity("sessionId"),
        roomId = text("roomId"),
        category = enum<Category>("category"),
        budgetFilter = enum<BudgetTier>("budgetFilter"),
        moodTag = enum<Mood>("moodTag"),
        status = enum<SessionStatus>("status"),
        matchedItemId = optionalText("matchedItemId"),
        itemIds = ids,
        matchSource = optionalEnum<MatchSource>("matchSource"),
        matchRevision = (get("matchRevision") as? Long)?.takeIf { it >= 0 } ?: invalidDocument(),
    ).also { session ->
        when (session.status) {
            SessionStatus.ACTIVE -> if (session.matchedItemId != null || session.matchSource != null) invalidDocument()
            SessionStatus.MATCHED -> if (session.matchedItemId !in ids || session.matchSource == null) invalidDocument()
        }
    }
}

internal fun DocumentSnapshot.toVoteState(): VoteState = VoteState(
    itemId = identity("itemId"),
    user1Vote = optionalEnum<Vote>("user1Vote"),
    user2Vote = optionalEnum<Vote>("user2Vote"),
    vetoedBy = optionalText("vetoedBy"),
)
