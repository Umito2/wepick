package com.wepick.app.domain.model

/** Illustrative Egyptian-pound guides for two; wire values and maximum-tier filtering stay stable. */
enum class BudgetTier(val label: String, val filterLabel: String) {
    LOW("Up to EGP 300", "Up to EGP 300"),
    MEDIUM("EGP 301–700", "Up to EGP 700"),
    HIGH("Over EGP 700", "Any budget");

    fun includes(other: BudgetTier): Boolean = other.ordinal <= ordinal
}
