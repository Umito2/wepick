package com.wepick.app.domain.model

/** A maximum spend tier; MEDIUM includes both LOW and MEDIUM options. */
enum class BudgetTier(val label: String) {
    LOW("$"), MEDIUM("$$"), HIGH("$$$");

    fun includes(other: BudgetTier): Boolean = other.ordinal <= ordinal
}
