package com.wepick.app.presentation.swipe

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.domain.repository.DeckRepository
import com.wepick.app.domain.repository.SwipeSessionRepository
import com.wepick.app.presentation.common.presentationMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@HiltViewModel
class SwipeViewModel @Inject constructor(
    savedStateHandle: SavedStateHandle,
    private val auth: AuthRepository,
    private val couples: CoupleRepository,
    private val sessions: SwipeSessionRepository,
    deck: DeckRepository,
) : ViewModel() {
    private val sessionId = checkNotNull(savedStateHandle.get<String>("sessionId"))
    private val items = deck.allItems().associateBy { it.id }
    private val mutableState = MutableStateFlow(SwipeUiState())
    val uiState = mutableState.asStateFlow()
    private var observation: Job? = null

    init {
        observe()
        // Device time only schedules a refresh; the server alone decides refill eligibility.
        viewModelScope.launch {
            refreshTokensQuietly()
            mutableState.map { state ->
                listOfNotNull(state.currentUser?.lastTokenResetTimestamp, state.partner?.lastTokenResetTimestamp)
                    .filter { it > 0 }
                    .minOrNull()?.plus(7L * 24 * 60 * 60 * 1_000)
            }.filterNotNull().distinctUntilChanged().collectLatest { nextReset ->
                while (currentCoroutineContext().isActive) {
                    // Usually sleeps to the next weekly window; bounds also handle clock skew/offline retries.
                    delay((nextReset - System.currentTimeMillis() + 1_000).coerceIn(60_000, 86_400_000))
                    refreshTokensQuietly()
                }
            }
        }
    }

    private suspend fun refreshTokensQuietly() {
        try { couples.refreshTokens() } catch (error: Exception) {
            error.presentationMessage("Couldn't refresh veto tokens.")
            // Keep swiping available; spending a token also refreshes it transactionally.
        }
    }

    private fun observe() {
        observation?.cancel()
        observation = viewModelScope.launch {
            mutableState.update { it.copy(isLoading = true) }
            try {
                val uid = auth.userId ?: error("Not authenticated")
                sessions.observeSession(sessionId).collectLatest sessionLoop@ { session ->
                    if (session == null) {
                        mutableState.update { it.copy(isLoading = false, error = "This round is no longer available. Start a new round.") }
                        return@sessionLoop
                    }
                    couples.observeRoom(session.roomId).collectLatest roomLoop@ { room ->
                        val partnerId = room?.partnerOf(uid)
                        if (room == null || partnerId == null) {
                            mutableState.update { it.copy(isLoading = false, error = "Your partner connection isn't available. Reopen WePick to reconnect.") }
                            return@roomLoop
                        }
                        combine(
                            sessions.observeVotes(sessionId),
                            couples.observeUser(uid),
                            couples.observeUser(partnerId),
                        ) { votes, me, partner -> Triple(votes, me, partner) }.collect { (votes, me, partner) ->
                            mutableState.update { it.withSnapshot(session, room, me, partner, votes, items) }
                        }
                    }
                }
            } catch (error: Exception) {
                mutableState.update { it.copy(isLoading = false, error = error.presentationMessage("We lost the connection to this round. Retry when you're online.")) }
            }
        }
    }

    fun vote(vote: Vote) {
        val state = mutableState.value
        val item = state.queue.firstOrNull() ?: return
        if (!state.canVote) return
        perform("Your vote wasn't saved. Please try again.") { sessions.castVote(sessionId, item.id, vote) }
    }

    fun veto() {
        val state = mutableState.value
        val session = state.session ?: return
        if (state.isBusy || state.isSuperseded || session.status != SessionStatus.MATCHED) return
        perform("We couldn't use your veto. Please try again.") {
            // expectedRevision makes double taps, request retries, and competing vetoes safe.
            sessions.vetoMatch(sessionId, session.matchRevision)
        }
    }

    fun spin() {
        if (!mutableState.value.canSpin) return
        perform("The spin couldn't finish. Please try again.") { sessions.spinTieBreaker(sessionId) }
    }

    private fun perform(fallback: String, action: suspend () -> Unit) {
        if (mutableState.value.isBusy) return
        mutableState.update { it.copy(isBusy = true, error = null) }
        viewModelScope.launch {
            try { action() } catch (error: Exception) {
                mutableState.update { it.copy(error = error.presentationMessage(fallback)) }
            } finally {
                mutableState.update { it.copy(isBusy = false) }
            }
        }
    }

    fun clearError() { mutableState.update { it.copy(error = null) } }
    fun retry() { clearError(); observe() }
}
