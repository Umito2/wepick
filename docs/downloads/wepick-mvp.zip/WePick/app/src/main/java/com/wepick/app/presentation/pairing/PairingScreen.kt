package com.wepick.app.presentation.pairing

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.wepick.app.presentation.common.ErrorNotice
import java.util.Locale

@Composable
fun PairingScreen(
    state: PairingUiState,
    onAnonymousSignIn: (String) -> Unit,
    onGoogleSignIn: () -> Unit,
    onCreateInvite: () -> Unit,
    onJoinRoom: (String) -> Unit,
    onRetry: () -> Unit,
    onDismissError: () -> Unit,
    allowGoogleSignIn: Boolean = true,
) {
    var name by rememberSaveable { mutableStateOf("") }
    var code by rememberSaveable { mutableStateOf("") }
    val colors = MaterialTheme.colorScheme

    Scaffold(containerColor = colors.background) { padding ->
        Box(
            Modifier.fillMaxSize().padding(padding).background(
                Brush.verticalGradient(listOf(colors.primaryContainer.copy(alpha = .48f), colors.background, colors.background)),
            ),
            contentAlignment = Alignment.TopCenter,
        ) {
            Column(
                Modifier.widthIn(max = 480.dp).fillMaxWidth().verticalScroll(rememberScrollState()).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(18.dp),
            ) {
                Spacer(Modifier.height(16.dp))
                Surface(shape = RoundedCornerShape(28.dp), color = colors.primary, shadowElevation = 10.dp) {
                    Icon(Icons.Rounded.Favorite, null, Modifier.padding(22.dp).size(38.dp), tint = colors.onPrimary)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("WePick", style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(8.dp))
                    Text("LESS DEBATE. MORE DATE.", style = MaterialTheme.typography.labelMedium, letterSpacing = 2.sp, color = colors.primary)
                }
                Text(
                    "Two people. One happy yes.",
                    style = MaterialTheme.typography.headlineSmall,
                    textAlign = TextAlign.Center,
                )
                Text(
                    "Swipe on little plans you'll both love.\nWe'll take care of the “what should we do?”",
                    color = colors.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyLarge,
                    textAlign = TextAlign.Center,
                )
                state.error?.let { ErrorNotice(it, onRetry, onDismissError) }

                when {
                    state.isLoading -> CircularProgressIndicator(Modifier.padding(24.dp))
                    !state.isAuthenticated -> {
                        Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 2.dp) {
                            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Text("Start with you", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                OutlinedTextField(
                                    value = name,
                                    onValueChange = { name = it.take(32) },
                                    modifier = Modifier.fillMaxWidth(),
                                    label = { Text("Your first name") },
                                    singleLine = true,
                                    enabled = !state.isBusy,
                                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Done),
                                )
                                Button(
                                    onClick = { onAnonymousSignIn(name) },
                                    enabled = name.isNotBlank() && !state.isBusy,
                                    modifier = Modifier.fillMaxWidth().height(52.dp),
                                ) {
                                    if (state.isBusy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                                    else Text("Continue anonymously", fontWeight = FontWeight.Bold)
                                }
                                if (allowGoogleSignIn) {
                                    OutlinedButton(onClick = onGoogleSignIn, enabled = !state.isBusy, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                                        Text("G", fontWeight = FontWeight.ExtraBold)
                                        Spacer(Modifier.width(12.dp))
                                        Text("Continue with Google")
                                    }
                                }
                                Text(
                                    if (allowGoogleSignIn) {
                                        "Continue anonymously on this device, or use Google to keep access after reinstalling."
                                    } else {
                                        "Continue anonymously. No Google account or password is needed for this preview."
                                    },
                                    color = colors.onSurfaceVariant,
                                    style = MaterialTheme.typography.bodySmall,
                                )
                            }
                        }
                    }
                    state.room != null -> {
                        InviteCodeCard(state.room.inviteCode)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                            Text("Waiting for your partner…", color = colors.onSurfaceVariant)
                        }
                        Text("Send them your code. You'll connect here automatically.", textAlign = TextAlign.Center, style = MaterialTheme.typography.bodyMedium)
                    }
                    else -> {
                        Text("Hey ${state.user?.name ?: "there"}, let's make it two.", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Button(onClick = onCreateInvite, enabled = !state.isBusy, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                            Text("Create our invite code", fontWeight = FontWeight.Bold)
                        }
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            HorizontalDivider(Modifier.weight(1f))
                            Text("OR JOIN YOUR PARTNER", style = MaterialTheme.typography.labelSmall, color = colors.onSurfaceVariant)
                            HorizontalDivider(Modifier.weight(1f))
                        }
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it.uppercase(Locale.ROOT).filter { char -> char in 'A'..'Z' || char in '0'..'9' }.take(6) },
                            label = { Text("6-character invite code") },
                            placeholder = { Text("ABC123") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            enabled = !state.isBusy,
                            textStyle = MaterialTheme.typography.headlineSmall.copy(letterSpacing = 5.sp, textAlign = TextAlign.Center),
                            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters, keyboardType = KeyboardType.Ascii, imeAction = ImeAction.Done),
                        )
                        OutlinedButton(onClick = { onJoinRoom(code) }, enabled = code.length == 6 && !state.isBusy, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                            Text("Join my partner")
                        }
                        if (state.isBusy) CircularProgressIndicator(Modifier.size(24.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                Surface(color = colors.secondaryContainer.copy(alpha = .6f), shape = CircleShape) {
                    Text("Just the two of you. Always.", Modifier.padding(horizontal = 18.dp, vertical = 9.dp), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
    }
}

@Suppress("DEPRECATION")
@Composable
private fun InviteCodeCard(code: String) {
    val clipboard = LocalClipboardManager.current
    var copied by rememberSaveable(code) { mutableStateOf(false) }
    Surface(shape = RoundedCornerShape(24.dp), tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("YOUR LITTLE CONNECTION CODE", style = MaterialTheme.typography.labelMedium, letterSpacing = 1.sp)
            Row(Modifier.fillMaxWidth().semantics { contentDescription = "Invite code ${code.toCharArray().joinToString(" ")}" }, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                code.forEach { character ->
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                        Text(character.toString(), Modifier.padding(vertical = 14.dp), textAlign = TextAlign.Center, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
            TextButton(onClick = { clipboard.setText(AnnotatedString(code)); copied = true }) {
                Icon(Icons.Outlined.ContentCopy, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (copied) "Code copied" else "Copy code")
            }
        }
    }
}
