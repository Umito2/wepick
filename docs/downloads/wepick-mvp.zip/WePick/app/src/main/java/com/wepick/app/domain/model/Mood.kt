package com.wepick.app.domain.model

enum class Mood(val label: String) {
    CHILL("Chill"), ENERGETIC("Energetic"), COZY("Cozy"),
}
