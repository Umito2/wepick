package com.wepick.app.presentation.swipe

import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.usecase.CalculateSwipeProgress

data class SwipeUiState(
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val session: SwipeSession? = null,
    val room: CoupleRoom? = null,
    val currentUser: User? = null,
    val partner: User? = null,
    val queue: List<DeckItem> = emptyList(),
    val matchedItem: DeckItem? = null,
    val tieBreakerCandidates: List<DeckItem> = emptyList(),
    val myCompletedCount: Int = 0,
    val partnerCompletedCount: Int = 0,
    val totalCount: Int = 0,
    val bothFinished: Boolean = false,
    val isSuperseded: Boolean = false,
    val error: String? = null,
) {
    val canVote: Boolean get() = !isLoading && !isBusy && !isSuperseded &&
        session?.status == SessionStatus.ACTIVE && queue.isNotEmpty()
    val canSpin: Boolean get() = !isLoading && !isBusy && !isSuperseded &&
        session?.status == SessionStatus.ACTIVE && bothFinished && tieBreakerCandidates.isNotEmpty()
    val isEmptyResult: Boolean get() = !isLoading && bothFinished &&
        session?.status == SessionStatus.ACTIVE && tieBreakerCandidates.isEmpty()
}

/** Derive progress from acknowledged votes, never from a locally advanced card index. */
internal fun SwipeUiState.withSnapshot(
    session: SwipeSession,
    room: CoupleRoom,
    currentUser: User?,
    partner: User?,
    votes: List<VoteState>,
    items: Map<String, DeckItem>,
): SwipeUiState {
    val progress = CalculateSwipeProgress()(session, room, currentUser?.uid ?: room.user1Id, votes)
    val byId = votes.associateBy(VoteState::itemId)
    // Snapshot listeners can arrive in either order; missing documents must never mean exhausted.
    val hydrated = currentUser != null && partner != null && session.itemIds.all { it in byId }
    val unknownItems = session.itemIds.any { it !in items }
    return copy(
        isLoading = !hydrated && !unknownItems,
        session = session,
        room = room,
        currentUser = currentUser,
        partner = partner,
        queue = if (unknownItems) emptyList() else progress.remainingItemIds.mapNotNull(items::get),
        matchedItem = session.matchedItemId?.let(items::get),
        tieBreakerCandidates = progress.tieBreakerCandidateIds.mapNotNull(items::get),
        myCompletedCount = progress.ownVotedCount,
        partnerCompletedCount = progress.partnerVotedCount,
        totalCount = progress.totalItemCount,
        bothFinished = hydrated && !unknownItems && progress.bothFinished,
        isSuperseded = room.activeSessionId != session.sessionId,
        error = if (unknownItems) "This round uses newer ideas. Update WePick to continue." else error,
    )
}
