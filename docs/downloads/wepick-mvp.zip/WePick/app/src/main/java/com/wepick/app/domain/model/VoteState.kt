package com.wepick.app.domain.model

enum class Vote { LIKE, PASS }

data class VoteState(
    val itemId: String,
    val user1Vote: Vote? = null,
    val user2Vote: Vote? = null,
    val vetoedBy: String? = null,
) {
    val isMutualLike: Boolean
        get() = vetoedBy == null && user1Vote == Vote.LIKE && user2Vote == Vote.LIKE

    fun voteFor(isUser1: Boolean): Vote? = if (isUser1) user1Vote else user2Vote
}
