package com.wepick.app.domain.model

data class User(
    val uid: String,
    val name: String,
    val partnerId: String? = null,
    val coupleRoomId: String? = null,
    val vetoTokensRemaining: Int = 2,
    /** Server-managed start of the current seven-day token window, in epoch millis. */
    val lastTokenResetTimestamp: Long = 0,
)
