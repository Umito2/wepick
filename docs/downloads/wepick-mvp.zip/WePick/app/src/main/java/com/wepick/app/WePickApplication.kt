package com.wepick.app

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.appcheck.FirebaseAppCheck
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class WePickApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.USE_FIREBASE_EMULATORS) {
            // The emulator manifest disables FirebaseInitProvider. Resolve the default app explicitly
            // rather than accepting an unrelated named app or production resources from another build.
            val emulatorApp = FirebaseApp.getApps(this).firstOrNull { it.name == FirebaseApp.DEFAULT_APP_NAME }
                ?: FirebaseApp.initializeApp(
                    this,
                    FirebaseOptions.Builder()
                        .setProjectId("demo-wepick")
                        .setApplicationId("1:1234567890:android:wepickemulator")
                        .setApiKey("emulator-only-api-key")
                        .build(),
                )
            check(emulatorApp.options.projectId == "demo-wepick") { "An emulator build must use demo-wepick." }
        } else {
            checkNotNull(FirebaseApp.initializeApp(this)) { "Firebase configuration is missing." }
            FirebaseAppCheck.getInstance().installAppCheckProviderFactory(AppCheckProvider.factory())
        }
    }
}

