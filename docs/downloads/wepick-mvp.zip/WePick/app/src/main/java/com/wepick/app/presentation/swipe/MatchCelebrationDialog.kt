package com.wepick.app.presentation.swipe

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.presentation.common.ErrorNotice
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun MatchCelebrationDialog(
    sessionId: String,
    matchRevision: Long,
    item: DeckItem,
    source: MatchSource?,
    candidates: List<DeckItem>,
    remainingTokens: Int,
    isBusy: Boolean,
    error: String?,
    onVeto: () -> Unit,
    onNewSession: () -> Unit,
    onRetry: () -> Unit,
    onDismissError: () -> Unit,
) {
    val isTieBreaker = source == MatchSource.TIE_BREAKER
    var revealed by rememberSaveable(sessionId, matchRevision) { mutableStateOf(!isTieBreaker) }
    var rouletteIndex by remember(sessionId, matchRevision) { mutableIntStateOf(0) }
    val scale = remember(sessionId, matchRevision) { Animatable(.76f) }
    val confetti = remember(sessionId, matchRevision) { Animatable(0f) }
    val rouletteItems = candidates.ifEmpty { listOf(item) }

    LaunchedEffect(sessionId, matchRevision) {
        scale.animateTo(1f, spring(dampingRatio = .58f, stiffness = 230f))
        if (!revealed) {
            // The animation presents the persisted shared result; it never selects another winner.
            repeat(19) { step ->
                rouletteIndex = (rouletteIndex + 1) % rouletteItems.size
                delay(45L + step * 7L)
            }
            revealed = true
        }
        launch { confetti.animateTo(1f, tween(2_800)) }
    }

    Dialog(onDismissRequest = {}, properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.scrim.copy(alpha = .38f)).padding(24.dp), contentAlignment = Alignment.Center) {
            if (revealed) CelebrationConfetti(confetti.value, Modifier.fillMaxSize())
            Surface(
                modifier = Modifier.widthIn(max = 440.dp).fillMaxWidth().graphicsLayer { scaleX = scale.value; scaleY = scale.value },
                shape = RoundedCornerShape(32.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
            ) {
                Column(
                    Modifier.verticalScroll(rememberScrollState()).padding(26.dp).semantics { liveRegion = LiveRegionMode.Polite },
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = CircleShape) {
                        Icon(Icons.Rounded.Favorite, null, Modifier.padding(16.dp).size(32.dp), tint = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        if (!revealed) "A little luck…" else if (isTieBreaker) "Your lucky pick!" else "It's a Match!",
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.ExtraBold,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        if (!revealed) "Spinning through your liked ideas" else if (isTieBreaker) "One of your likes. One shared plan." else "Two right swipes. One very good plan.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                    )
                    Surface(shape = RoundedCornerShape(22.dp), color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.fillMaxWidth()) {
                        AnimatedContent(targetState = if (revealed) item else rouletteItems[rouletteIndex % rouletteItems.size], label = "Shared roulette reveal") { displayed ->
                            Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text(displayed.emoji, fontSize = 64.sp)
                                Text(displayed.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                                Text("${displayed.priceTier.label} for two", style = MaterialTheme.typography.labelLarge, textAlign = TextAlign.Center)
                                Text(displayed.category.label, style = MaterialTheme.typography.labelMedium, textAlign = TextAlign.Center)
                                Text("Illustrative guide; confirm menu/venue prices.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                            }
                        }
                    }
                    if (revealed) {
                        Text(item.description, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        error?.let { ErrorNotice(it, onRetry, onDismissError) }
                        Button(onClick = onNewSession, enabled = !isBusy, modifier = Modifier.fillMaxWidth().height(54.dp)) { Text("Plan another round") }
                        OutlinedButton(onClick = onVeto, enabled = !isBusy && remainingTokens > 0, modifier = Modifier.fillMaxWidth().height(54.dp)) {
                            if (isBusy) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            else Text(if (remainingTokens > 0) "Use a veto · 1 token" else "No veto tokens left this week")
                        }
                        Text("$remainingTokens of 2 weekly vetoes remaining", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Spacer(Modifier.height(8.dp))
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        Text("The same pick is coming to both of you.", style = MaterialTheme.typography.bodySmall, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
private fun CelebrationConfetti(progress: Float, modifier: Modifier = Modifier) {
    val colors = listOf(MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.tertiary, Color(0xFFE9BB68), Color(0xFF8BC6A8))
    Canvas(modifier) {
        if (progress > 0f && progress < 1f) repeat(54) { index ->
            val x = ((index * .6180339f) % 1f) * size.width
            val phase = (index % 9) / 9f
            val y = ((progress * 1.5f + phase) % 1f) * size.height
            val wobble = sin(progress * 14f + index) * 20.dp.toPx()
            drawCircle(colors[index % colors.size].copy(alpha = (1f - progress).coerceIn(0f, 1f)), radius = (3 + index % 4).dp.toPx(), center = Offset(x + wobble, y))
        }
    }
}
