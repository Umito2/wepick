package com.wepick.app.domain.model

enum class SessionStatus { ACTIVE, MATCHED }
enum class MatchSource { MUTUAL, TIE_BREAKER }

data class SwipeSession(
    val sessionId: String,
    val roomId: String,
    val category: Category,
    val budgetFilter: BudgetTier,
    val moodTag: Mood,
    val status: SessionStatus = SessionStatus.ACTIVE,
    val matchedItemId: String? = null,
    /** Immutable shared ordering: both partners see the exact same catalogue version. */
    val itemIds: List<String>,
    val matchSource: MatchSource? = null,
    val matchRevision: Long = 0,
)
