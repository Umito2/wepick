package com.wepick.app.domain.usecase

import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState

data class SwipeProgress(
    val remainingItemIds: List<String>,
    val ownVotedCount: Int,
    val partnerVotedCount: Int,
    val totalItemCount: Int,
    val bothFinished: Boolean,
    val tieBreakerCandidateIds: List<String>,
)

/** Pure session projection, suitable for restoring a deck after rotation or process death. */
class CalculateSwipeProgress {
    operator fun invoke(
        session: SwipeSession,
        room: CoupleRoom,
        userId: String,
        votes: List<VoteState>,
    ): SwipeProgress {
        require(room.roomId == session.roomId && room.contains(userId)) { "The session belongs to another room." }
        val isUser1 = room.user1Id == userId
        val votesById = votes.associateBy(VoteState::itemId)
        val eligibleIds = session.itemIds.filter { votesById[it]?.vetoedBy == null }
        val remaining = eligibleIds.filter { votesById[it]?.voteFor(isUser1) == null }
        val partnerRemaining = eligibleIds.count { votesById[it]?.voteFor(!isUser1) == null }
        // An empty first snapshot must never be interpreted as a completed deck.
        val allDocumentsPresent = session.itemIds.all(votesById::containsKey)
        val union = eligibleIds.filter { id ->
            votesById[id]?.let { it.user1Vote == Vote.LIKE || it.user2Vote == Vote.LIKE } == true
        }
        return SwipeProgress(
            remainingItemIds = remaining,
            ownVotedCount = eligibleIds.size - remaining.size,
            partnerVotedCount = eligibleIds.size - partnerRemaining,
            totalItemCount = eligibleIds.size,
            bothFinished = allDocumentsPresent && remaining.isEmpty() && partnerRemaining == 0,
            tieBreakerCandidateIds = union,
        )
    }
}
