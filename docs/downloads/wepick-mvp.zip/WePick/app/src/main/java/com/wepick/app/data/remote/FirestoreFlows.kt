package com.wepick.app.data.remote

import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.Query
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Listener ownership follows collection; cancelling a ViewModel collector removes the listener. */
internal fun <T> DocumentReference.observeDocument(map: (DocumentSnapshot) -> T): Flow<T?> =
    callbackFlow {
        val registration = addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error.asWePickException())
            } else {
                try {
                    trySend(snapshot?.takeIf(DocumentSnapshot::exists)?.let(map))
                } catch (failure: Exception) {
                    close(failure.asWePickException())
                }
            }
        }
        awaitClose { registration.remove() }
    }.distinctUntilChanged()

internal fun <T> Query.observeDocuments(map: (DocumentSnapshot) -> T): Flow<List<T>> =
    callbackFlow {
        val registration = addSnapshotListener { snapshot, error ->
            if (error != null) {
                close(error.asWePickException())
            } else {
                try {
                    trySend(snapshot?.documents?.map(map).orEmpty())
                } catch (failure: Exception) {
                    close(failure.asWePickException())
                }
            }
        }
        awaitClose { registration.remove() }
    }.distinctUntilChanged()
