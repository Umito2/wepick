package com.wepick.app.data.local

import android.content.Context
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.repository.DeckRepository
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import org.json.JSONArray

/** The same catalogue file is packaged into Android and the trusted Firebase functions. */
@Singleton
class LocalDeckDataSource @Inject constructor(
    @param:ApplicationContext private val context: Context,
) : DeckRepository {
    private val items: List<DeckItem> by lazy(LazyThreadSafetyMode.SYNCHRONIZED) {
        val source = context.assets.open("deck.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = JSONArray(source)
        List(json.length()) { index ->
            val item = json.getJSONObject(index)
            val moods = item.getJSONArray("vibeTags")
            DeckItem(
                id = item.getString("id"),
                title = item.getString("title"),
                category = Category.valueOf(item.getString("category")),
                priceTier = BudgetTier.valueOf(item.getString("priceTier")),
                vibeTags = (0 until moods.length()).map { Mood.valueOf(moods.getString(it)) }.toSet(),
                description = item.getString("description"),
                emoji = item.getString("emoji"),
            )
        }.also { parsed ->
            check(parsed.size == 20 && parsed.map(DeckItem::id).distinct().size == parsed.size) {
                "The bundled catalogue must contain 20 uniquely identified items."
            }
            for (category in Category.entries) {
                check(parsed.count { it.category == category } == 5)
                for (mood in Mood.entries) {
                    check(parsed.any { SessionFilter(category, BudgetTier.LOW, mood).accepts(it) }) {
                        "Every category and mood must offer an affordable option."
                    }
                }
            }
        }
    }

    override fun allItems(): List<DeckItem> = items.toList()
    override fun itemsFor(filter: SessionFilter): List<DeckItem> = items.filter(filter::accepts)
    override fun find(id: String): DeckItem? = items.firstOrNull { it.id == id }
}
