package com.wepick.app.data.remote

import com.google.firebase.functions.FirebaseFunctions
import com.wepick.app.domain.model.WePickException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.tasks.await

/** Privileged writes are implemented by authenticated, App Check protected server transactions. */
@Singleton
class FirebaseCallableApi @Inject constructor(private val functions: FirebaseFunctions) {
    suspend fun call(name: String, data: Map<String, Any?> = emptyMap()): Map<String, Any?> =
        firebaseOperation {
            val payload = functions.getHttpsCallable(name).call(data).await().data as? Map<*, *>
                ?: throw WePickException("WePick returned an unreadable response. Please try again.")
            payload.entries.associate { (key, value) ->
                val field = key as? String
                    ?: throw WePickException("WePick returned an unreadable response. Please try again.")
                field to value
            }
        }
}

internal fun Map<String, Any?>.requiredId(field: String): String =
    (this[field] as? String)?.also(::requireDocumentId)
        ?: throw WePickException("WePick returned an incomplete response. Please try again.")
