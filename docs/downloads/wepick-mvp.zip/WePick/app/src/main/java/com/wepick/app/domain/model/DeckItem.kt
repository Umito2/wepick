package com.wepick.app.domain.model

data class DeckItem(
    val id: String,
    val title: String,
    val category: Category,
    val priceTier: BudgetTier,
    val vibeTags: Set<Mood>,
    val description: String,
    /** Offline illustration used by the card's image placeholder. */
    val emoji: String,
)
