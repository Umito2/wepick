package com.wepick.app.presentation.navigation

import kotlinx.serialization.Serializable

@Serializable data object PairingRoute
@Serializable data class FilterRoute(val roomId: String, val previousSessionId: String? = null)
@Serializable data class SwipeRoute(val sessionId: String)

