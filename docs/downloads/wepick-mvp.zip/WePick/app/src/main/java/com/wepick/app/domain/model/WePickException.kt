package com.wepick.app.domain.model

/** An actionable message that presentation may safely show without exposing server details. */
class WePickException(message: String, cause: Throwable? = null) : RuntimeException(message, cause)
