package com.wepick.app.presentation.pairing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.presentation.common.presentationMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PairingUiState(
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val isAuthenticated: Boolean = false,
    val user: User? = null,
    val room: CoupleRoom? = null,
    val error: String? = null,
)

@HiltViewModel
class PairingViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val couples: CoupleRepository,
) : ViewModel() {
    private val mutableState = MutableStateFlow(PairingUiState())
    val uiState = mutableState.asStateFlow()
    private var observation: Job? = null

    init { observe() }

    private fun observe() {
        observation?.cancel()
        observation = viewModelScope.launch {
            mutableState.update { it.copy(isLoading = true) }
            // A membership transition can revoke the old room before the user snapshot arrives.
            // Track only errors from that room so a later snapshot doesn't clear an action error.
            var roomFailure: Pair<String, String>? = null
            try {
                auth.observeAuth().distinctUntilChanged().collectLatest { uid ->
                    mutableState.update {
                        it.copy(isAuthenticated = uid != null, user = null, room = null)
                    }
                    if (uid == null) {
                        mutableState.update { it.copy(isLoading = false) }
                    } else {
                        couples.observeUser(uid).collectLatest { user ->
                            val roomId = user?.coupleRoomId
                            mutableState.update { state ->
                                val staleRoomError = roomFailure?.let { (failedRoomId, message) ->
                                    failedRoomId != roomId && state.error == message
                                } == true
                                state.copy(
                                    user = user,
                                    isLoading = false,
                                    room = state.room?.takeIf { it.roomId == roomId },
                                    error = if (staleRoomError) null else state.error,
                                )
                            }
                            if (roomFailure?.first != roomId) roomFailure = null
                            if (roomId == null) {
                                mutableState.update { it.copy(room = null) }
                            } else {
                                couples.observeRoom(roomId).catch { failure ->
                                    // presentationMessage rethrows CancellationException. A terminated
                                    // room listener must not terminate the parent profile/auth listener.
                                    val message = failure.presentationMessage("We couldn't load this connection. Please retry.")
                                    if (mutableState.value.user?.coupleRoomId == roomId) {
                                        roomFailure = roomId to message
                                        mutableState.update { state ->
                                            if (state.user?.coupleRoomId == roomId) state.copy(room = null, error = message)
                                            else state
                                        }
                                    }
                                }.collectLatest { room ->
                                    mutableState.update { state ->
                                        if (state.user?.coupleRoomId != roomId) state
                                        else state.copy(
                                            room = room,
                                            error = if (roomFailure?.first == roomId && state.error == roomFailure?.second) null else state.error,
                                        )
                                    }
                                    if (roomFailure?.first == roomId) roomFailure = null
                                }
                            }
                        }
                    }
                }
            } catch (error: Exception) {
                mutableState.update {
                    it.copy(isLoading = false, error = error.presentationMessage("We couldn't load your connection. Please retry."))
                }
            }
        }
    }

    fun signInAnonymously(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            reportError("Add your first name so your partner knows it's you.")
            return
        }
        perform("We couldn't sign you in. Please retry.") { auth.signInAnonymously(trimmed.take(32)) }
    }

    fun signInWithGoogle(idToken: String) = perform("Google sign-in couldn't finish. Please retry.") {
        auth.signInWithGoogle(idToken)
    }

    fun createInvite() = perform("We couldn't create your code. Please retry.") { couples.createInvite() }

    fun joinRoom(code: String) {
        val normalized = code.trim().uppercase(java.util.Locale.ROOT)
        if (!normalized.matches(Regex("[A-Z0-9]{6}"))) {
            reportError("Enter the six letters or numbers from your partner's code.")
            return
        }
        perform("We couldn't join your partner. Please retry.") { couples.joinRoom(normalized) }
    }

    private fun perform(fallback: String, action: suspend () -> Unit) {
        if (mutableState.value.isBusy) return
        mutableState.update { it.copy(isBusy = true, error = null) }
        viewModelScope.launch {
            try { action() } catch (error: Exception) {
                mutableState.update { it.copy(error = error.presentationMessage(fallback)) }
            } finally {
                mutableState.update { it.copy(isBusy = false) }
            }
        }
    }

    fun reportError(message: String) { mutableState.update { it.copy(error = message) } }
    fun clearError() { mutableState.update { it.copy(error = null) } }
    fun retry() { clearError(); observe() }
}
