package com.wepick.app.presentation.pairing

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.presentation.common.presentationMessage
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

data class PairingUiState(
    val isLoading: Boolean = true,
    val isBusy: Boolean = false,
    val isAuthenticated: Boolean = false,
    val user: User? = null,
    val room: CoupleRoom? = null,
    val error: String? = null,
)

@HiltViewModel
class PairingViewModel @Inject constructor(
    private val auth: AuthRepository,
    private val couples: CoupleRepository,
) : ViewModel() {
    private val mutableState = MutableStateFlow(PairingUiState())
    val uiState = mutableState.asStateFlow()
    private var observation: Job? = null
    private var startupWatchdog: Job? = null
    private var actionJob: Job? = null
    private var observationGeneration = 0L
    private var actionGeneration = 0L
    private var loadingGeneration = 0L
    private var awaitingInitialState = false
    private var errorRevision = 0L
    private var watchdogErrorRevision: Long? = null

    init { observe() }

    private fun observe() {
        val attempt = ++observationGeneration
        observation?.cancel()
        startupWatchdog?.cancel()
        awaitingInitialState = false
        watchdogErrorRevision = null
        beginLoading(attempt)
        observation = viewModelScope.launch {
            // A membership transition can revoke the old room before the user snapshot arrives.
            // Track only errors from that room so a later snapshot doesn't clear an action error.
            var roomFailure: Pair<String, Long>? = null
            try {
                auth.observeAuth().distinctUntilChanged().collectLatest { uid ->
                    if (attempt != observationGeneration) return@collectLatest
                    beginLoading(attempt)
                    mutableState.update {
                        it.copy(isAuthenticated = uid != null, user = null, room = null)
                    }
                    if (uid == null) {
                        finishLoading(attempt)
                    } else {
                        couples.observeUser(uid).collectLatest profile@ { user ->
                            if (attempt != observationGeneration) return@profile
                            val roomId = user?.coupleRoomId
                            val previousRoomId = mutableState.value.user?.coupleRoomId
                            if (user == null || roomId != previousRoomId) beginLoading(attempt)
                            if (roomFailure?.first != roomId && roomFailure?.second == errorRevision) clearError()
                            mutableState.update { state ->
                                state.copy(
                                    user = user,
                                    room = state.room?.takeIf { it.roomId == roomId },
                                )
                            }
                            if (roomFailure?.first != roomId) roomFailure = null
                            // Firestore may first return a cache snapshot without this profile.
                            // Keep the listener, but let the watchdog bound the initial spinner.
                            if (user == null) return@profile
                            if (roomId == null) {
                                mutableState.update { it.copy(room = null) }
                                finishLoading(attempt)
                            } else {
                                couples.observeRoom(roomId).catch { failure ->
                                    // presentationMessage rethrows CancellationException. A terminated
                                    // room listener must not terminate the parent profile/auth listener.
                                    val message = failure.presentationMessage("We couldn't load this connection. Please retry.")
                                    if (attempt == observationGeneration && mutableState.value.user?.coupleRoomId == roomId) {
                                        finishLoading(attempt, clearWatchdogError = false)
                                        roomFailure = roomId to showError(message)
                                        mutableState.update { state ->
                                            if (state.user?.coupleRoomId == roomId) state.copy(room = null)
                                            else state
                                        }
                                    }
                                }.collectLatest roomSnapshot@ { room ->
                                    if (attempt != observationGeneration || mutableState.value.user?.coupleRoomId != roomId) return@roomSnapshot
                                    mutableState.update { it.copy(room = room) }
                                    if (room == null) {
                                        beginLoading(attempt)
                                        return@roomSnapshot
                                    }
                                    if (roomFailure?.first == roomId && roomFailure?.second == errorRevision) clearError()
                                    if (roomFailure?.first == roomId) roomFailure = null
                                    // An unpaired but valid room is healthy: waiting for a partner
                                    // must not be treated as a network timeout twelve seconds later.
                                    finishLoading(attempt)
                                }
                            }
                        }
                    }
                }
            } catch (error: Exception) {
                val message = error.presentationMessage("We couldn't load your connection. Please retry.")
                if (attempt == observationGeneration) {
                    finishLoading(attempt, clearWatchdogError = false)
                    showError(message)
                }
            }
        }
    }

    private fun beginLoading(attempt: Long) {
        if (attempt != observationGeneration || awaitingInitialState) return
        awaitingInitialState = true
        val loadingAttempt = ++loadingGeneration
        mutableState.update { it.copy(isLoading = true) }
        startupWatchdog?.cancel()
        startupWatchdog = viewModelScope.launch {
            delay(INITIAL_LOAD_TIMEOUT_MILLIS)
            if (attempt == observationGeneration && loadingAttempt == loadingGeneration && awaitingInitialState) {
                mutableState.update { it.copy(isLoading = false) }
                if (mutableState.value.error == null) watchdogErrorRevision = showError(INITIAL_LOAD_TIMEOUT_MESSAGE)
                // This is a UI deadline, not a listener deadline. A late valid snapshot can
                // still reconnect, and only this watchdog's own error is cleared on success.
            }
        }
    }

    private fun finishLoading(attempt: Long, clearWatchdogError: Boolean = true) {
        if (attempt != observationGeneration) return
        awaitingInitialState = false
        startupWatchdog?.cancel()
        startupWatchdog = null
        if (clearWatchdogError && watchdogErrorRevision == errorRevision) clearError()
        watchdogErrorRevision = null
        mutableState.update { it.copy(isLoading = false) }
    }

    fun signInAnonymously(name: String) {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            reportError("Add your first name so your partner knows it's you.")
            return
        }
        perform("We couldn't sign you in. Please retry.") { auth.signInAnonymously(trimmed.take(32)) }
    }

    fun signInWithGoogle(idToken: String) = perform("Google sign-in couldn't finish. Please retry.") {
        auth.signInWithGoogle(idToken)
    }

    fun createInvite() = perform("We couldn't create your code. Please retry.") { couples.createInvite() }

    fun joinRoom(code: String) {
        val normalized = code.trim().uppercase(java.util.Locale.ROOT)
        if (!normalized.matches(Regex("[A-Z0-9]{6}"))) {
            reportError("Enter the six letters or numbers from your partner's code.")
            return
        }
        perform("We couldn't join your partner. Please retry.") { couples.joinRoom(normalized) }
    }

    private fun perform(fallback: String, action: suspend () -> Unit) {
        if (mutableState.value.isBusy) return
        val attempt = ++actionGeneration
        clearError()
        mutableState.update { it.copy(isBusy = true) }
        actionJob = viewModelScope.launch {
            try {
                // Data operations normally fail sooner (8s emulator / 30s production).
                // A separate fallback also bounds a repository that never returns.
                val completed = withTimeoutOrNull(ACTION_TIMEOUT_MILLIS) { action(); true } == true
                if (attempt == actionGeneration) {
                    if (!completed) {
                        finishLoading(observationGeneration, clearWatchdogError = false)
                        showError(ACTION_TIMEOUT_MESSAGE)
                    } else if (observation?.isActive != true) {
                        observe()
                    }
                }
            } catch (error: Exception) {
                val message = error.presentationMessage(fallback)
                if (attempt == actionGeneration) {
                    finishLoading(observationGeneration, clearWatchdogError = false)
                    showError(message)
                }
            } finally {
                if (attempt == actionGeneration) mutableState.update { it.copy(isBusy = false) }
            }
        }
    }

    private fun showError(message: String): Long {
        val revision = ++errorRevision
        mutableState.update { it.copy(error = message) }
        return revision
    }

    fun reportError(message: String) { showError(message) }
    fun clearError() { errorRevision++; mutableState.update { it.copy(error = null) } }
    fun retry() {
        // Invalidating first prevents an old action's finally block from unlocking a new one.
        actionGeneration++
        actionJob?.cancel()
        mutableState.update { it.copy(isBusy = false) }
        clearError()
        observe()
    }

    internal companion object {
        const val INITIAL_LOAD_TIMEOUT_MILLIS = 12_000L
        const val ACTION_TIMEOUT_MILLIS = 35_000L
        const val INITIAL_LOAD_TIMEOUT_MESSAGE = "We couldn't finish connecting. Check your connection or preview setup, then try again."
        const val ACTION_TIMEOUT_MESSAGE = "This request is taking too long. Check your connection or preview setup, then try again."
    }
}
