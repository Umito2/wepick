package com.wepick.app.presentation.navigation

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.hilt.lifecycle.viewmodel.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.wepick.app.BuildConfig
import com.wepick.app.auth.isGoogleSignInAvailable
import com.wepick.app.auth.requestGoogleIdToken
import com.wepick.app.presentation.filter.CategoryFilterScreen
import com.wepick.app.presentation.filter.FilterViewModel
import com.wepick.app.presentation.pairing.PairingScreen
import com.wepick.app.presentation.pairing.PairingViewModel
import com.wepick.app.presentation.swipe.SwipeDeckScreen
import com.wepick.app.presentation.swipe.SwipeViewModel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

@Composable
fun WePickNavHost() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = PairingRoute) {
        composable<PairingRoute> {
            val viewModel: PairingViewModel = hiltViewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            val context = LocalContext.current
            val allowGoogleSignIn = remember(context) { isGoogleSignInAvailable(context) }
            val scope = rememberCoroutineScope()
            var googleInProgress by remember { mutableStateOf(false) }
            val pairedRoomId = state.room?.takeIf { room -> room.isPaired }?.roomId
            LaunchedEffect(pairedRoomId) {
                pairedRoomId?.let { roomId ->
                    navController.navigate(FilterRoute(roomId)) {
                        popUpTo<PairingRoute> { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
            PairingScreen(
                state = state.copy(isBusy = state.isBusy || googleInProgress),
                allowGoogleSignIn = allowGoogleSignIn,
                showEmulatorSetupHelp = BuildConfig.USE_FIREBASE_EMULATORS,
                onOpenBrowserDemo = {
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://umito2.github.io/wepick/#demo")))
                    } catch (_: ActivityNotFoundException) {
                        viewModel.reportError("No browser is available. Open umito2.github.io/wepick on another device to try the demo.")
                    }
                },
                onAnonymousSignIn = viewModel::signInAnonymously,
                onGoogleSignIn = {
                    if (allowGoogleSignIn && !googleInProgress) scope.launch {
                        googleInProgress = true
                        try {
                            viewModel.signInWithGoogle(requestGoogleIdToken(context))
                        } catch (_: GetCredentialCancellationException) {
                            // Closing Google's sheet is a normal navigation action.
                        } catch (cancelled: CancellationException) {
                            throw cancelled
                        } catch (error: Exception) {
                            viewModel.reportError(error.message ?: "Google sign-in couldn't start. Please try again.")
                        } finally {
                            googleInProgress = false
                        }
                    }
                },
                onCreateInvite = viewModel::createInvite,
                onJoinRoom = viewModel::joinRoom,
                onRetry = viewModel::retry,
                onDismissError = viewModel::clearError,
            )
        }
        composable<FilterRoute> {
            val viewModel: FilterViewModel = hiltViewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            fun openSession(sessionId: String) {
                navController.navigate(SwipeRoute(sessionId)) {
                    // A loaded active round would immediately reopen if an old filter entry stayed
                    // underneath it. Replace the entry so system Back exits the current flow cleanly.
                    popUpTo<FilterRoute> { inclusive = true }
                    launchSingleTop = true
                }
            }
            LaunchedEffect(state.readySessionId) { state.readySessionId?.let(::openSession) }
            CategoryFilterScreen(
                state = state,
                onCategory = viewModel::selectCategory,
                onBudget = viewModel::selectBudget,
                onMood = viewModel::selectMood,
                onStart = viewModel::startSession,
                onResume = { state.previousSessionId?.let(::openSession) },
                onRetry = viewModel::retry,
                onDismissError = viewModel::clearError,
            )
        }
        composable<SwipeRoute> { entry ->
            val route = entry.toRoute<SwipeRoute>()
            val viewModel: SwipeViewModel = hiltViewModel()
            val state by viewModel.uiState.collectAsStateWithLifecycle()
            val replacementId = state.room?.activeSessionId
            LaunchedEffect(state.isSuperseded, replacementId) {
                if (state.isSuperseded && replacementId != null && replacementId != route.sessionId) {
                    navController.navigate(SwipeRoute(replacementId)) {
                        popUpTo<SwipeRoute> { inclusive = true }
                        launchSingleTop = true
                    }
                }
            }
            SwipeDeckScreen(
                state = state,
                onVote = viewModel::vote,
                onVeto = viewModel::veto,
                onSpin = viewModel::spin,
                onNewSession = {
                    state.session?.let { session ->
                        navController.navigate(FilterRoute(session.roomId, session.sessionId)) {
                            popUpTo<SwipeRoute> { inclusive = true }
                            launchSingleTop = true
                        }
                    }
                },
                onRetry = viewModel::retry,
                onDismissError = viewModel::clearError,
            )
        }
    }
}
