package com.wepick.app.data.remote

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.google.firebase.firestore.Transaction
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.SwipeSessionRepository
import com.wepick.app.domain.repository.DeckRepository
import java.security.SecureRandom
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseSwipeSessionRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val profiles: FirebaseProfileStore,
    private val deck: DeckRepository,
) : SwipeSessionRepository {
    private val random = SecureRandom()
    override fun observeSession(sessionId: String): Flow<SwipeSession?> {
        requireDocumentId(sessionId)
        return firestore.collection("sessions").document(sessionId).observeDocument { it.toSession() }
    }

    override fun observeVotes(sessionId: String): Flow<List<VoteState>> {
        requireDocumentId(sessionId)
        return firestore.collection("sessions").document(sessionId).collection("swipes")
            .observeDocuments { it.toVoteState() }
    }

    override suspend fun createSession(roomId: String, filter: SessionFilter): String = firebaseOperation {
        requireDocumentId(roomId)
        val uid = profiles.requireUserId()
        val roomRef = firestore.collection("couple_rooms").document(roomId)
        val sessionRef = firestore.collection("sessions").document()
        val filterId = "${filter.category.name}_${filter.budget.name}_${filter.mood.name}"
        val filterRef = firestore.collection("deck_filters").document(filterId)
        try {
            firestore.runTransaction { tx ->
                val roomSnapshot = tx.get(roomRef)
                if (!roomSnapshot.exists()) throw WePickException("This room is no longer available.")
                val room = roomSnapshot.toRoom()
                requireMember(room, uid)
                if (room.activeSessionId != null) {
                    val previous = tx.get(firestore.collection("sessions").document(room.activeSessionId))
                    if (!previous.exists()) throw WePickException("The current round is incomplete. Please retry.")
                    val active = previous.toSession()
                    if (active.status == SessionStatus.ACTIVE) {
                        val progress = completedDeck(active.itemIds, readSwipes(tx, active))
                        if (!progress.bothFinished || progress.candidateIds.isNotEmpty()) return@runTransaction active.sessionId
                    }
                }
                val filterSnapshot = tx.get(filterRef)
                val itemIds = (filterSnapshot.get("itemIds") as? List<*>)?.map { item ->
                    (item as? String)?.also(::requireDocumentId)
                        ?: throw WePickException("The shared catalogue needs updating. Please retry later.")
                } ?: throw WePickException("The shared catalogue is not ready. Please retry later.")
                if (itemIds.size !in 1..5 || itemIds.distinct().size != itemIds.size ||
                    itemIds != deck.itemsFor(filter).map { it.id }) {
                    throw WePickException("Your catalogue differs from this room. Update WePick before starting a round.")
                }
                // The read-only filter document is authoritative. Rules require this exact
                // catalogue order and every initialized swipe in the same atomic operation.
                tx.set(sessionRef, mapOf(
                    "sessionId" to sessionRef.id, "roomId" to roomId,
                    "category" to filter.category.name, "budgetFilter" to filter.budget.name,
                    "moodTag" to filter.mood.name, "status" to SessionStatus.ACTIVE.name,
                    "matchedItemId" to null, "itemIds" to itemIds, "matchSource" to null,
                    "matchRevision" to 0L, "createdAt" to FieldValue.serverTimestamp(),
                ))
                itemIds.forEach { itemId ->
                    tx.set(sessionRef.collection("swipes").document(itemId), mapOf(
                        "itemId" to itemId, "user1Vote" to null, "user2Vote" to null, "vetoedBy" to null,
                    ))
                }
                tx.update(roomRef, "activeSessionId", sessionRef.id)
                sessionRef.id
            }.await()
        } catch (failure: FirebaseFirestoreException) {
            if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
            val currentRoom = roomRef.get(Source.SERVER).await().toRoom()
            requireMember(currentRoom, uid)
            val currentId = currentRoom.activeSessionId ?: throw failure
            val current = firestore.collection("sessions").document(currentId).get(Source.SERVER).await().toSession()
            // A competing create can win before the stale transaction gets its retry. Reuse
            // that round instead of replacing an ACTIVE session or hiding a genuine denial.
            if (current.roomId == roomId && current.status == SessionStatus.ACTIVE) currentId else throw failure
        }
    }

    override suspend fun castVote(sessionId: String, itemId: String, vote: Vote): Unit = firebaseOperation {
        requireDocumentId(sessionId)
        requireDocumentId(itemId)
        val uid = auth.currentUser?.uid ?: throw WePickException("Please sign in before swiping.")
        val sessionRef = firestore.collection("sessions").document(sessionId)
        val swipeRef = sessionRef.collection("swipes").document(itemId)

        var raceRetries = 0
        while (true) {
            try {
                commitVote(sessionRef, swipeRef, sessionId, itemId, uid, vote)
                return@firebaseOperation
            } catch (failure: FirebaseFirestoreException) {
                if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED || raceRetries >= 2) {
                    throw failure
                }
                // Rules can evaluate the newly committed partner LIKE before Firestore rejects our
                // stale transaction precondition. In that narrow race, the original write omitted
                // the newly necessary match transition. Re-read server state before attempting a
                // fresh transaction; a genuine authorization denial is never blindly retried.
                when (recoverVoteRace(sessionRef, swipeRef, sessionId, itemId, uid, vote)) {
                    VoteRaceResolution.ALREADY_COMMITTED -> return@firebaseOperation
                    VoteRaceResolution.RETRY -> raceRetries++
                    VoteRaceResolution.REJECT -> throw failure
                }
            }
        }
    }

    private suspend fun commitVote(
        sessionRef: DocumentReference,
        swipeRef: DocumentReference,
        sessionId: String,
        itemId: String,
        uid: String,
        vote: Vote,
    ) {
        firestore.runTransaction { transaction ->
            // Firestore may retry this block. It has no local UI side effects, random values or token writes.
            val sessionSnapshot = transaction.get(sessionRef)
            if (!sessionSnapshot.exists()) throw WePickException("This session has ended. Start a new one.")
            val session = sessionSnapshot.toSession()
            val roomSnapshot = transaction.get(firestore.collection("couple_rooms").document(session.roomId))
            val swipeSnapshot = transaction.get(swipeRef)
            // Every read occurs before the first write so optimistic concurrency can retry safely.
            if (!roomSnapshot.exists() || !swipeSnapshot.exists()) {
                throw WePickException("This session is incomplete. Return to your room and try again.")
            }
            val room = roomSnapshot.toRoom()
            val swipe = swipeSnapshot.toVoteState()
            if (!room.contains(uid) || !room.isPaired) {
                throw WePickException("Pair with your partner before swiping.")
            }
            if (room.activeSessionId != sessionId || itemId !in session.itemIds) {
                throw WePickException("Your partner has started a different session. Return to your room.")
            }
            val isUser1 = uid == room.user1Id
            val previousVote = swipe.voteFor(isUser1)
            // A retry after a lost acknowledgement must not create another match or change a vote.
            if (previousVote == vote) return@runTransaction Unit
            if (previousVote != null) throw WePickException("You have already voted on this card.")
            if (session.status != SessionStatus.ACTIVE) {
                throw WePickException("You already have a match. Decide on it before swiping again.")
            }
            if (swipe.vetoedBy != null) throw WePickException("This item was vetoed. Move to the next card.")

            val partnerVote = swipe.voteFor(!isUser1)
            transaction.update(swipeRef, if (isUser1) "user1Vote" else "user2Vote", vote.name)
            if (vote == Vote.LIKE && partnerVote == Vote.LIKE) {
                // The vote and authoritative match commit atomically. Concurrent likes on different
                // cards contend on sessionRef, so only one item can win this match revision.
                transaction.update(
                    sessionRef,
                    mapOf(
                        "status" to SessionStatus.MATCHED.name,
                        "matchedItemId" to itemId,
                        "matchSource" to MatchSource.MUTUAL.name,
                        "matchRevision" to session.matchRevision + 1,
                    ),
                )
            }
            Unit
        }.await()
    }

    private suspend fun recoverVoteRace(
        sessionRef: DocumentReference,
        swipeRef: DocumentReference,
        sessionId: String,
        itemId: String,
        uid: String,
        vote: Vote,
    ): VoteRaceResolution {
        val sessionSnapshot = sessionRef.get(Source.SERVER).await()
        if (!sessionSnapshot.exists()) return VoteRaceResolution.REJECT
        val session = sessionSnapshot.toSession()
        val roomSnapshot = firestore.collection("couple_rooms").document(session.roomId).get(Source.SERVER).await()
        val swipeSnapshot = swipeRef.get(Source.SERVER).await()
        if (!roomSnapshot.exists() || !swipeSnapshot.exists()) return VoteRaceResolution.REJECT
        return resolveVoteRace(session, roomSnapshot.toRoom(), swipeSnapshot.toVoteState(), sessionId, itemId, uid, vote)
    }

    override suspend fun vetoMatch(sessionId: String, expectedRevision: Long): Unit = firebaseOperation {
        requireDocumentId(sessionId)
        if (expectedRevision < 1) throw WePickException("This match is out of date. Please refresh the session.")
        val uid = profiles.requireUserId()
        val now = profiles.serverNow(uid)
        val sessionRef = firestore.collection("sessions").document(sessionId)
        try {
            firestore.runTransaction { tx ->
                val snapshot = tx.get(sessionRef)
                if (!snapshot.exists()) throw WePickException("This session has ended.")
                val session = snapshot.toSession()
                val room = tx.get(firestore.collection("couple_rooms").document(session.roomId)).toRoom()
                requireMember(room, uid)
                requireCurrent(room, session)
                if (session.matchRevision != expectedRevision || session.status != SessionStatus.MATCHED) {
                    return@runTransaction Unit
                }
                val itemId = session.matchedItemId ?: throw WePickException("This match is no longer available.")
                val userRef = firestore.collection("users").document(uid)
                val swipeRef = sessionRef.collection("swipes").document(itemId)
                val userSnapshot = tx.get(userRef)
                val user = userSnapshot.requireUser()
                val swipe = tx.get(swipeRef).toVoteState()
                if (swipe.vetoedBy != null) throw WePickException("This card was already vetoed.")
                val balance = weeklyTokenBalance(user, now.toDate().time)
                if (balance.available <= 0) throw WePickException("You have used both veto tokens for this week.")
                tx.update(userRef, mapOf(
                    "vetoTokensRemaining" to balance.available - 1,
                    "lastTokenResetTimestamp" to if (balance.resetDue) FieldValue.serverTimestamp()
                        else userSnapshot.getTimestamp("lastTokenResetTimestamp"),
                ))
                tx.update(swipeRef, "vetoedBy", uid)
                tx.update(sessionRef, mapOf(
                    "status" to SessionStatus.ACTIVE.name, "matchedItemId" to null,
                    "matchSource" to null, "matchRevision" to session.matchRevision + 1,
                ))
                Unit
            }.await()
        } catch (failure: FirebaseFirestoreException) {
            if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
            val current = readCurrentSession(sessionId, uid)
            // Racing vetoes and lost acknowledgements must never debit a second token.
            if (current.matchRevision == expectedRevision && current.status == SessionStatus.MATCHED) throw failure
        }
    }

    override suspend fun spinTieBreaker(sessionId: String): String? = firebaseOperation {
        requireDocumentId(sessionId)
        val uid = profiles.requireUserId()
        val sessionRef = firestore.collection("sessions").document(sessionId)
        try {
            firestore.runTransaction { tx ->
                val snapshot = tx.get(sessionRef)
                if (!snapshot.exists()) throw WePickException("This session has ended.")
                val session = snapshot.toSession()
                val room = tx.get(firestore.collection("couple_rooms").document(session.roomId)).toRoom()
                requireMember(room, uid)
                requireCurrent(room, session)
                if (session.status == SessionStatus.MATCHED) return@runTransaction session.matchedItemId
                val progress = completedDeck(session.itemIds, readSwipes(tx, session))
                if (!progress.bothFinished) throw WePickException("Both partners must finish the deck before spinning.")
                if (progress.candidateIds.isEmpty()) return@runTransaction null
                // One committed choice is shared by both devices. Rules validate eligibility;
                // without a compute backend they cannot prove a modified client chose uniformly.
                val winner = progress.candidateIds[random.nextInt(progress.candidateIds.size)]
                tx.update(sessionRef, mapOf(
                    "status" to SessionStatus.MATCHED.name, "matchedItemId" to winner,
                    "matchSource" to MatchSource.TIE_BREAKER.name, "matchRevision" to session.matchRevision + 1,
                ))
                winner
            }.await()
        } catch (failure: FirebaseFirestoreException) {
            if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) throw failure
            val current = readCurrentSession(sessionId, uid)
            if (current.status == SessionStatus.MATCHED) current.matchedItemId else throw failure
        }
    }

    private fun readSwipes(tx: Transaction, session: SwipeSession): List<VoteState> = session.itemIds.map { id ->
        val snapshot = tx.get(firestore.collection("sessions").document(session.sessionId).collection("swipes").document(id))
        if (!snapshot.exists()) throw WePickException("This round is incomplete. Please retry.")
        snapshot.toVoteState()
    }

    private suspend fun readCurrentSession(sessionId: String, uid: String): SwipeSession {
        val snapshot = firestore.collection("sessions").document(sessionId).get(Source.SERVER).await()
        if (!snapshot.exists()) throw WePickException("This session has ended.")
        val session = snapshot.toSession()
        val room = firestore.collection("couple_rooms").document(session.roomId).get(Source.SERVER).await().toRoom()
        requireMember(room, uid)
        requireCurrent(room, session)
        return session
    }

    private fun requireMember(room: CoupleRoom, uid: String) {
        if (!room.contains(uid) || !room.isPaired) throw WePickException("Pair with your partner before starting a round.")
    }

    private fun requireCurrent(room: CoupleRoom, session: SwipeSession) {
        if (room.activeSessionId != session.sessionId) {
            throw WePickException("Your partner started a different session. Return to your room.")
        }
    }
}
