package com.wepick.app.data.remote

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Source
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.SwipeSessionRepository
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.tasks.await

@Singleton
class FirebaseSwipeSessionRepository @Inject constructor(
    private val firestore: FirebaseFirestore,
    private val auth: FirebaseAuth,
    private val api: FirebaseCallableApi,
) : SwipeSessionRepository {
    override fun observeSession(sessionId: String): Flow<SwipeSession?> {
        requireDocumentId(sessionId)
        return firestore.collection("sessions").document(sessionId).observeDocument { it.toSession() }
    }

    override fun observeVotes(sessionId: String): Flow<List<VoteState>> {
        requireDocumentId(sessionId)
        return firestore.collection("sessions").document(sessionId).collection("swipes")
            .observeDocuments { it.toVoteState() }
    }

    override suspend fun createSession(roomId: String, filter: SessionFilter): String {
        requireDocumentId(roomId)
        return api.call(
            "createSession",
            mapOf(
                "roomId" to roomId,
                "category" to filter.category.name,
                "budgetFilter" to filter.budget.name,
                "moodTag" to filter.mood.name,
            ),
        ).requiredId("sessionId")
    }

    override suspend fun castVote(sessionId: String, itemId: String, vote: Vote): Unit = firebaseOperation {
        requireDocumentId(sessionId)
        requireDocumentId(itemId)
        val uid = auth.currentUser?.uid ?: throw WePickException("Please sign in before swiping.")
        val sessionRef = firestore.collection("sessions").document(sessionId)
        val swipeRef = sessionRef.collection("swipes").document(itemId)

        var raceRetries = 0
        while (true) {
            try {
                commitVote(sessionRef, swipeRef, sessionId, itemId, uid, vote)
                return@firebaseOperation
            } catch (failure: FirebaseFirestoreException) {
                if (failure.code != FirebaseFirestoreException.Code.PERMISSION_DENIED || raceRetries >= 2) {
                    throw failure
                }
                // Rules can evaluate the newly committed partner LIKE before Firestore rejects our
                // stale transaction precondition. In that narrow race, the original write omitted
                // the newly necessary match transition. Re-read server state before attempting a
                // fresh transaction; a genuine authorization denial is never blindly retried.
                when (recoverVoteRace(sessionRef, swipeRef, sessionId, itemId, uid, vote)) {
                    VoteRaceResolution.ALREADY_COMMITTED -> return@firebaseOperation
                    VoteRaceResolution.RETRY -> raceRetries++
                    VoteRaceResolution.REJECT -> throw failure
                }
            }
        }
    }

    private suspend fun commitVote(
        sessionRef: DocumentReference,
        swipeRef: DocumentReference,
        sessionId: String,
        itemId: String,
        uid: String,
        vote: Vote,
    ) {
        firestore.runTransaction { transaction ->
            // Firestore may retry this block. It has no local UI side effects, random values or token writes.
            val sessionSnapshot = transaction.get(sessionRef)
            if (!sessionSnapshot.exists()) throw WePickException("This session has ended. Start a new one.")
            val session = sessionSnapshot.toSession()
            val roomSnapshot = transaction.get(firestore.collection("couple_rooms").document(session.roomId))
            val swipeSnapshot = transaction.get(swipeRef)
            // Every read occurs before the first write so optimistic concurrency can retry safely.
            if (!roomSnapshot.exists() || !swipeSnapshot.exists()) {
                throw WePickException("This session is incomplete. Return to your room and try again.")
            }
            val room = roomSnapshot.toRoom()
            val swipe = swipeSnapshot.toVoteState()
            if (!room.contains(uid) || !room.isPaired) {
                throw WePickException("Pair with your partner before swiping.")
            }
            if (room.activeSessionId != sessionId || itemId !in session.itemIds) {
                throw WePickException("Your partner has started a different session. Return to your room.")
            }
            val isUser1 = uid == room.user1Id
            val previousVote = swipe.voteFor(isUser1)
            // A retry after a lost acknowledgement must not create another match or change a vote.
            if (previousVote == vote) return@runTransaction Unit
            if (previousVote != null) throw WePickException("You have already voted on this card.")
            if (session.status != SessionStatus.ACTIVE) {
                throw WePickException("You already have a match. Decide on it before swiping again.")
            }
            if (swipe.vetoedBy != null) throw WePickException("This item was vetoed. Move to the next card.")

            val partnerVote = swipe.voteFor(!isUser1)
            transaction.update(swipeRef, if (isUser1) "user1Vote" else "user2Vote", vote.name)
            if (vote == Vote.LIKE && partnerVote == Vote.LIKE) {
                // The vote and authoritative match commit atomically. Concurrent likes on different
                // cards contend on sessionRef, so only one item can win this match revision.
                transaction.update(
                    sessionRef,
                    mapOf(
                        "status" to SessionStatus.MATCHED.name,
                        "matchedItemId" to itemId,
                        "matchSource" to MatchSource.MUTUAL.name,
                        "matchRevision" to session.matchRevision + 1,
                    ),
                )
            }
            Unit
        }.await()
    }

    private suspend fun recoverVoteRace(
        sessionRef: DocumentReference,
        swipeRef: DocumentReference,
        sessionId: String,
        itemId: String,
        uid: String,
        vote: Vote,
    ): VoteRaceResolution {
        val sessionSnapshot = sessionRef.get(Source.SERVER).await()
        if (!sessionSnapshot.exists()) return VoteRaceResolution.REJECT
        val session = sessionSnapshot.toSession()
        val roomSnapshot = firestore.collection("couple_rooms").document(session.roomId).get(Source.SERVER).await()
        val swipeSnapshot = swipeRef.get(Source.SERVER).await()
        if (!roomSnapshot.exists() || !swipeSnapshot.exists()) return VoteRaceResolution.REJECT
        return resolveVoteRace(session, roomSnapshot.toRoom(), swipeSnapshot.toVoteState(), sessionId, itemId, uid, vote)
    }

    override suspend fun vetoMatch(sessionId: String, expectedRevision: Long) {
        requireDocumentId(sessionId)
        if (expectedRevision < 0) throw WePickException("This match is out of date. Please refresh the session.")
        api.call("vetoMatch", mapOf("sessionId" to sessionId, "expectedRevision" to expectedRevision))
    }

    override suspend fun spinTieBreaker(sessionId: String): String? {
        requireDocumentId(sessionId)
        val result = api.call("spinTieBreaker", mapOf("sessionId" to sessionId))
        if (!result.containsKey("itemId")) throw WePickException("WePick returned an incomplete result. Please retry.")
        val winner = result["itemId"] ?: return null
        return (winner as? String)?.also(::requireDocumentId)
            ?: throw WePickException("WePick returned an unreadable result. Please retry.")
    }
}
