package com.wepick.app.presentation.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = Color(0xFFB8325D), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E2), onPrimaryContainer = Color(0xFF4A0020),
    secondary = Color(0xFF6750A4), secondaryContainer = Color(0xFFEADDFF),
    tertiary = Color(0xFF146C54), tertiaryContainer = Color(0xFFAAF2D5),
    background = Color(0xFFFFF8F9), surface = Color(0xFFFFF8F9),
    surfaceContainer = Color(0xFFF9ECF0), surfaceContainerHigh = Color(0xFFF3E6EA),
    onBackground = Color(0xFF25191E), onSurface = Color(0xFF25191E),
)
private val DarkColors = darkColorScheme(
    primary = Color(0xFFFFB1C6), onPrimary = Color(0xFF650A30),
    primaryContainer = Color(0xFF8F1A46), onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = Color(0xFFD0BCFF), secondaryContainer = Color(0xFF4F378B),
    tertiary = Color(0xFF8DD5B9), tertiaryContainer = Color(0xFF00513D),
    background = Color(0xFF191116), surface = Color(0xFF191116),
    surfaceContainer = Color(0xFF261C22), surfaceContainerHigh = Color(0xFF31272D),
    onBackground = Color(0xFFF1DEE5), onSurface = Color(0xFFF1DEE5),
)

@Composable
fun WePickTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    val baseline = Typography()
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = baseline.copy(
            headlineLarge = baseline.headlineLarge.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.SansSerif),
            headlineMedium = baseline.headlineMedium.copy(fontWeight = FontWeight.Bold),
            titleLarge = baseline.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        ),
        shapes = Shapes(
            small = RoundedCornerShape(12.dp), medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(36.dp),
        ),
        content = content,
    )
}
