package com.wepick.app.data.remote

import com.google.android.gms.tasks.TaskCompletionSource
import com.wepick.app.domain.model.WePickException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class InFlightFirebaseTaskTest {
    @Test fun `a deadline retry awaits the original identity task instead of starting another`() = runTest {
        val request = InFlightFirebaseTask<String>()
        val sdk = TaskCompletionSource<String>()
        var started = 0
        val failure = runCatching {
            withFirebaseDeadline(100) { request.awaitOrStart { started++; sdk.task } }
        }.exceptionOrNull()
        assertTrue(failure is WePickException)
        assertEquals(1, started)

        launch { delay(20); sdk.setResult("original-uid") }
        val uid = withFirebaseDeadline(100) { request.awaitOrStart { started++; sdk.task } }
        assertEquals("original-uid", uid)
        assertEquals(1, started)
    }

    @Test fun `leaving the screen does not abandon a still-running identity task`() = runTest {
        val request = InFlightFirebaseTask<String>()
        val sdk = TaskCompletionSource<String>()
        var started = 0
        val screen = launch { request.awaitOrStart { started++; sdk.task } }
        runCurrent()
        screen.cancel()
        runCurrent()

        sdk.setResult("same-uid")
        assertEquals("same-uid", request.awaitOrStart { started++; sdk.task })
        assertEquals(1, started)
    }

    @Test fun `a completed failed SDK task allows a deliberate new request`() = runTest {
        val request = InFlightFirebaseTask<String>()
        val failed = TaskCompletionSource<String>()
        val sdkFailure = IllegalStateException("Connection refused")
        failed.setException(sdkFailure)
        val observed = runCatching { request.awaitOrStart { failed.task } }.exceptionOrNull()
        assertSame(sdkFailure, observed)

        val next = TaskCompletionSource<String>()
        next.setResult("new-uid")
        assertEquals("new-uid", request.awaitOrStart { next.task })
    }

    @Test fun `a different auth action waits for the earlier SDK mutation to settle`() = runTest {
        val request = InFlightFirebaseTask<String>()
        val sdk = TaskCompletionSource<String>()
        runCatching { withFirebaseDeadline(100) { request.awaitOrStart { sdk.task } } }

        var laterActionStarted = false
        val nextAction = async {
            request.awaitPending()
            laterActionStarted = true
        }
        runCurrent()
        assertFalse(laterActionStarted)
        sdk.setResult("settled-uid")
        nextAction.await()
        assertTrue(laterActionStarted)
    }
}
