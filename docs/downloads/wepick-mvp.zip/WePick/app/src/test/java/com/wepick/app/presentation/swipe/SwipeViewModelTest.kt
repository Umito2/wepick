package com.wepick.app.presentation.swipe

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModelStore
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.domain.repository.DeckRepository
import com.wepick.app.domain.repository.SwipeSessionRepository
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class SwipeViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var store: ViewModelStore
    private lateinit var sessions: FakeSessions
    private lateinit var couples: FakeCouples
    private lateinit var viewModel: SwipeViewModel

    @Before fun setUp() {
        Dispatchers.setMain(dispatcher)
        store = ViewModelStore()
        sessions = FakeSessions()
        couples = FakeCouples()
        viewModel = SwipeViewModel(SavedStateHandle(mapOf("sessionId" to "session")), FakeAuth(), couples, sessions, FakeDeck())
        store.put("swipe", viewModel)
    }

    @After fun tearDown() {
        store.clear()
        Dispatchers.resetMain()
    }

    @Test fun `rapid taps result in one in-flight vote`() = runTest(dispatcher) {
        runCurrent()
        val pending = CompletableDeferred<Unit>()
        sessions.onVote = { pending.await() }
        viewModel.vote(Vote.LIKE)
        viewModel.vote(Vote.PASS)
        runCurrent()
        assertEquals(listOf("a" to Vote.LIKE), sessions.castVotes)
        assertTrue(viewModel.uiState.value.isBusy)
        // The card stays until an acknowledged snapshot removes it.
        assertEquals("a", viewModel.uiState.value.queue.first().id)
        pending.complete(Unit)
        runCurrent()
        assertFalse(viewModel.uiState.value.isBusy)
    }

    @Test fun `failed write preserves card and exposes actionable error`() = runTest(dispatcher) {
        runCurrent()
        sessions.onVote = { throw WePickException("Go online to save this vote.") }
        viewModel.vote(Vote.LIKE)
        runCurrent()
        assertEquals("a", viewModel.uiState.value.queue.first().id)
        assertEquals("Go online to save this vote.", viewModel.uiState.value.error)
        assertTrue(viewModel.uiState.value.canVote)
    }

    @Test fun `restored votes rebuild queue and wait for the slower partner`() = runTest(dispatcher) {
        sessions.votes.value = listOf(VoteState("a", Vote.PASS, null), VoteState("b", Vote.LIKE, Vote.PASS))
        runCurrent()
        assertTrue(viewModel.uiState.value.queue.isEmpty())
        assertEquals(2, viewModel.uiState.value.myCompletedCount)
        assertEquals(1, viewModel.uiState.value.partnerCompletedCount)
        assertFalse(viewModel.uiState.value.canSpin)
        viewModel.spin()
        runCurrent()
        assertEquals(0, sessions.spins)

        sessions.votes.value = listOf(VoteState("a", Vote.PASS, Vote.PASS), VoteState("b", Vote.LIKE, Vote.PASS))
        runCurrent()
        assertTrue(viewModel.uiState.value.canSpin)
        viewModel.spin()
        runCurrent()
        assertEquals(1, sessions.spins)
    }

    @Test fun `veto sends the visible match revision and leaves outcome to snapshots`() = runTest(dispatcher) {
        sessions.session.value = initialSession.copy(status = SessionStatus.MATCHED, matchedItemId = "a", matchSource = MatchSource.MUTUAL, matchRevision = 7)
        sessions.votes.value = listOf(VoteState("a", Vote.LIKE, Vote.LIKE), VoteState("b"))
        runCurrent()
        assertEquals("a", viewModel.uiState.value.matchedItem?.id)
        viewModel.veto()
        runCurrent()
        assertEquals(listOf(7L), sessions.vetoRevisions)
        assertEquals(SessionStatus.MATCHED, viewModel.uiState.value.session?.status)
    }

    @Test fun `replaced round blocks stale swipe and veto actions`() = runTest(dispatcher) {
        runCurrent()
        couples.room.value = initialRoom.copy(activeSessionId = "replacement")
        runCurrent()
        assertTrue(viewModel.uiState.value.isSuperseded)
        assertFalse(viewModel.uiState.value.canVote)
        viewModel.vote(Vote.LIKE)
        viewModel.veto()
        runCurrent()
        assertTrue(sessions.castVotes.isEmpty())
        assertTrue(sessions.vetoRevisions.isEmpty())
    }

    @Test fun `unknown catalogue entry requests app update instead of spinning forever`() = runTest(dispatcher) {
        sessions.session.value = initialSession.copy(itemIds = listOf("future-item"))
        sessions.votes.value = listOf(VoteState("future-item"))
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertFalse(viewModel.uiState.value.canSpin)
        assertTrue(viewModel.uiState.value.error.orEmpty().contains("Update WePick"))
    }

    private class FakeAuth : AuthRepository {
        override val userId = "me"
        override fun observeAuth() = flowOf(userId)
        override suspend fun signInAnonymously(name: String) = Unit
        override suspend fun signInWithGoogle(idToken: String) = Unit
        override suspend fun signOut() = Unit
    }

    private class FakeCouples : CoupleRepository {
        val room = MutableStateFlow<CoupleRoom?>(initialRoom)
        override fun observeUser(uid: String): Flow<User?> = flowOf(User(uid, if (uid == "me") "Alex" else "Sam", coupleRoomId = "room"))
        override fun observeRoom(roomId: String) = room
        override suspend fun createInvite() = initialRoom
        override suspend fun joinRoom(code: String) = initialRoom
        override suspend fun refreshTokens() = Unit
    }

    private class FakeSessions : SwipeSessionRepository {
        val session = MutableStateFlow<SwipeSession?>(initialSession)
        val votes = MutableStateFlow(listOf(VoteState("a"), VoteState("b")))
        val castVotes = mutableListOf<Pair<String, Vote>>()
        val vetoRevisions = mutableListOf<Long>()
        var spins = 0
        var onVote: suspend () -> Unit = {}
        override fun observeSession(sessionId: String) = session
        override fun observeVotes(sessionId: String) = votes
        override suspend fun createSession(roomId: String, filter: SessionFilter) = "session"
        override suspend fun castVote(sessionId: String, itemId: String, vote: Vote) { castVotes += itemId to vote; onVote() }
        override suspend fun vetoMatch(sessionId: String, expectedRevision: Long) { vetoRevisions += expectedRevision }
        override suspend fun spinTieBreaker(sessionId: String): String? { spins++; return "b" }
    }

    private class FakeDeck : DeckRepository {
        private val items = listOf("a", "b").map { DeckItem(it, it, Category.FOOD, BudgetTier.LOW, setOf(Mood.CHILL), "An idea", "🍜") }
        override fun allItems() = items
        override fun itemsFor(filter: SessionFilter) = items.filter(filter::accepts)
        override fun find(id: String) = items.find { it.id == id }
    }

    companion object {
        private val initialRoom = CoupleRoom("room", "ABC123", "me", "partner", "session", 0)
        private val initialSession = SwipeSession("session", "room", Category.FOOD, BudgetTier.LOW, Mood.CHILL, itemIds = listOf("a", "b"))
    }
}
