package com.wepick.app.data.remote

import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.MatchSource
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionStatus
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import org.junit.Assert.assertEquals
import org.junit.Test

class VoteConflictRecoveryTest {
    private val session = SwipeSession("session", "room", Category.FOOD, BudgetTier.LOW, Mood.COZY, itemIds = listOf("item"))
    private val room = CoupleRoom("room", "ABC123", "alex", "sam", "session", 0)

    @Test fun `a concurrent partner like permits a fresh match transaction for either member`() {
        assertEquals(VoteRaceResolution.RETRY, resolve(VoteState("item", null, Vote.LIKE)))
        assertEquals(VoteRaceResolution.RETRY, resolve(VoteState("item", Vote.LIKE, null), uid = "sam"))
    }

    @Test fun `a lost acknowledgement of the same committed vote is idempotent`() {
        val matched = session.copy(status = SessionStatus.MATCHED, matchedItemId = "item", matchSource = MatchSource.MUTUAL, matchRevision = 1)
        assertEquals(VoteRaceResolution.ALREADY_COMMITTED, resolve(VoteState("item", Vote.LIKE, Vote.LIKE), current = matched))
    }

    @Test fun `unrelated denials cannot trigger conflict retries`() {
        assertEquals(VoteRaceResolution.REJECT, resolve(VoteState("item")))
        assertEquals(VoteRaceResolution.REJECT, resolve(VoteState("item", null, Vote.PASS)))
        assertEquals(VoteRaceResolution.REJECT, resolve(VoteState("item", null, Vote.LIKE), vote = Vote.PASS))
        assertEquals(VoteRaceResolution.REJECT, resolve(VoteState("item", Vote.PASS, Vote.LIKE)))
    }

    @Test fun `vetoed matched superseded and unauthorized states never retry`() {
        val ready = VoteState("item", null, Vote.LIKE)
        assertEquals(VoteRaceResolution.REJECT, resolve(ready.copy(vetoedBy = "sam")))
        assertEquals(VoteRaceResolution.REJECT, resolve(ready, current = session.copy(status = SessionStatus.MATCHED)))
        assertEquals(VoteRaceResolution.REJECT, resolve(ready, currentRoom = room.copy(activeSessionId = "new-round")))
        assertEquals(VoteRaceResolution.REJECT, resolve(ready, uid = "outsider"))
        assertEquals(VoteRaceResolution.REJECT, resolve(ready, currentRoom = room.copy(user2Id = null)))
        assertEquals(VoteRaceResolution.REJECT, resolve(ready.copy(itemId = "injected")))
    }

    private fun resolve(
        swipe: VoteState,
        uid: String = "alex",
        vote: Vote = Vote.LIKE,
        current: SwipeSession = session,
        currentRoom: CoupleRoom = room,
    ) = resolveVoteRace(current, currentRoom, swipe, "session", "item", uid, vote)
}
