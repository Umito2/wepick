package com.wepick.app.domain

import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.usecase.CalculateSwipeProgress
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class CalculateSwipeProgressTest {
    private val calculator = CalculateSwipeProgress()
    private val room = CoupleRoom("room", "ABC123", "alex", "sam", "session", 1)
    private val session = SwipeSession(
        sessionId = "session", roomId = "room", category = Category.FOOD,
        budgetFilter = BudgetTier.HIGH, moodTag = Mood.COZY,
        itemIds = listOf("one", "two", "three"),
    )

    @Test fun `restored deck uses persisted own votes and preserves shared order`() {
        val progress = calculator(session, room, "sam", listOf(
            VoteState("one", Vote.LIKE, null),
            VoteState("two", Vote.PASS, Vote.PASS),
            VoteState("three", null, null),
        ))
        assertEquals(listOf("one", "three"), progress.remainingItemIds)
        assertEquals(1, progress.ownVotedCount)
        assertEquals(2, progress.partnerVotedCount)
        assertFalse(progress.bothFinished)
    }

    @Test fun `one finished partner cannot spin before the other`() {
        val progress = calculator(session, room, "alex", listOf(
            VoteState("one", Vote.LIKE, Vote.PASS),
            VoteState("two", Vote.PASS, null),
            VoteState("three", Vote.PASS, Vote.LIKE),
        ))
        assertTrue(progress.remainingItemIds.isEmpty())
        assertFalse(progress.bothFinished)
    }

    @Test fun `veto removes candidate from restored deck and union on both devices`() {
        val votes = listOf(
            VoteState("one", Vote.LIKE, Vote.LIKE, "alex"),
            VoteState("two", Vote.LIKE, Vote.PASS),
            VoteState("three", Vote.PASS, Vote.LIKE),
        )
        val alex = calculator(session, room, "alex", votes)
        val sam = calculator(session, room, "sam", votes)
        assertTrue(alex.bothFinished)
        assertTrue(sam.bothFinished)
        assertEquals(listOf("two", "three"), alex.tieBreakerCandidateIds)
        assertEquals(alex.tieBreakerCandidateIds, sam.tieBreakerCandidateIds)
        assertEquals(2, alex.totalItemCount)
    }

    @Test fun `empty or incomplete listeners cannot claim the deck is finished`() {
        assertFalse(calculator(session, room, "alex", emptyList()).bothFinished)
        val progress = calculator(session, room, "alex", listOf(
            VoteState("one", Vote.PASS, Vote.PASS),
            VoteState("two", Vote.PASS, Vote.PASS),
        ))
        assertFalse(progress.bothFinished)
        assertEquals(listOf("three"), progress.remainingItemIds)
    }

    @Test fun `all passes produce a completed deck with an empty union`() {
        val progress = calculator(session, room, "alex", session.itemIds.map {
            VoteState(it, Vote.PASS, Vote.PASS)
        })
        assertTrue(progress.bothFinished)
        assertTrue(progress.tieBreakerCandidateIds.isEmpty())
    }

    @Test fun `unknown vote documents cannot enter the shared candidate pool`() {
        val votes = session.itemIds.map { VoteState(it, Vote.PASS, Vote.PASS) } +
            VoteState("injected", Vote.LIKE, Vote.LIKE)
        assertTrue(calculator(session, room, "alex", votes).tieBreakerCandidateIds.isEmpty())
    }

    @Test(expected = IllegalArgumentException::class)
    fun `unrelated account cannot project another couples votes`() {
        calculator(session, room, "intruder", emptyList())
    }
}
