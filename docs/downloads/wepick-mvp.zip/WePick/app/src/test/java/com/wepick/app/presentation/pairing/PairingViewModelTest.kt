package com.wepick.app.presentation.pairing

import androidx.lifecycle.ViewModelStore
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PairingViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var store: ViewModelStore
    private lateinit var couples: FakeCouples
    private lateinit var viewModel: PairingViewModel

    @Before fun setUp() {
        Dispatchers.setMain(dispatcher)
        store = ViewModelStore()
        couples = FakeCouples()
        viewModel = PairingViewModel(FakeAuth(), couples)
        store.put("pairing", viewModel)
    }

    @After fun tearDown() { store.clear(); Dispatchers.resetMain() }

    @Test fun `revoked old invite does not stop observing the newly joined room`() = runTest(dispatcher) {
        runCurrent()
        assertEquals("old-room", viewModel.uiState.value.room?.roomId)

        // Firestore may report the denied old room before the transaction's user snapshot.
        couples.oldRoom.value = Result.failure(WePickException("Room access changed."))
        runCurrent()
        assertEquals("Room access changed.", viewModel.uiState.value.error)

        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertEquals("partner", viewModel.uiState.value.room?.user1Id)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `new room arrival preserves a newer unrelated action error`() = runTest(dispatcher) {
        runCurrent()
        couples.oldRoom.value = Result.failure(WePickException("Room access changed."))
        runCurrent()
        viewModel.reportError("Choose a different Google account.")

        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertEquals("Choose a different Google account.", viewModel.uiState.value.error)
    }

    @Test fun `cancelled old listener cannot erase a newer room`() = runTest(dispatcher) {
        runCurrent()
        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        couples.oldRoom.value = Result.failure(WePickException("Stale listener failure."))
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertNull(viewModel.uiState.value.error)
    }

    private class FakeAuth : AuthRepository {
        override val userId = "me"
        override fun observeAuth() = flowOf(userId)
        override suspend fun signInAnonymously(name: String) = Unit
        override suspend fun signInWithGoogle(idToken: String) = Unit
        override suspend fun signOut() = Unit
    }

    private class FakeCouples : CoupleRepository {
        val user = MutableStateFlow<User?>(User("me", "Alex", coupleRoomId = "old-room"))
        val oldRoom = MutableStateFlow<Result<CoupleRoom?>>(Result.success(CoupleRoom("old-room", "ABC123", "me", createdAt = 0)))
        val newRoom = CoupleRoom("new-room", "XYZ123", "partner", "me", createdAt = 0)
        override fun observeUser(uid: String) = user
        override fun observeRoom(roomId: String) = if (roomId == "old-room") oldRoom.map { it.getOrThrow() } else flowOf(newRoom)
        override suspend fun createInvite() = checkNotNull(oldRoom.value.getOrThrow())
        override suspend fun joinRoom(code: String) = newRoom
        override suspend fun refreshTokens() = Unit
    }
}
