package com.wepick.app.presentation.pairing

import androidx.lifecycle.ViewModelStore
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.AuthRepository
import com.wepick.app.domain.repository.CoupleRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.advanceTimeBy
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class PairingViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var store: ViewModelStore
    private lateinit var couples: FakeCouples
    private lateinit var auth: FakeAuth
    private lateinit var viewModel: PairingViewModel

    @Before fun setUp() {
        Dispatchers.setMain(dispatcher)
        store = ViewModelStore()
        couples = FakeCouples()
        auth = FakeAuth()
        viewModel = PairingViewModel(auth, couples)
        store.put("pairing", viewModel)
    }

    @After fun tearDown() { store.clear(); Dispatchers.resetMain() }

    @Test fun `revoked old invite does not stop observing the newly joined room`() = runTest(dispatcher) {
        runCurrent()
        assertEquals("old-room", viewModel.uiState.value.room?.roomId)

        // Firestore may report the denied old room before the transaction's user snapshot.
        couples.oldRoom.value = Result.failure(WePickException("Room access changed."))
        runCurrent()
        assertEquals("Room access changed.", viewModel.uiState.value.error)

        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertEquals("partner", viewModel.uiState.value.room?.user1Id)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `new room arrival preserves a newer unrelated action error`() = runTest(dispatcher) {
        runCurrent()
        couples.oldRoom.value = Result.failure(WePickException("Room access changed."))
        runCurrent()
        viewModel.reportError("Choose a different Google account.")

        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertEquals("Choose a different Google account.", viewModel.uiState.value.error)
    }

    @Test fun `cancelled old listener cannot erase a newer room`() = runTest(dispatcher) {
        runCurrent()
        couples.user.value = couples.user.value?.copy(coupleRoomId = "new-room", partnerId = "partner")
        runCurrent()
        couples.oldRoom.value = Result.failure(WePickException("Stale listener failure."))
        runCurrent()
        assertEquals("new-room", viewModel.uiState.value.room?.roomId)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `auth that never emits stops the initial spinner without cancelling observation`() = runTest(dispatcher) {
        var cancellations = 0
        auth.events = flow { try { awaitCancellation() } finally { cancellations++ } }
        runCurrent()
        assertTrue(viewModel.uiState.value.isLoading)
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
        assertEquals(0, cancellations)
    }

    @Test fun `profile that never emits also has a bounded initial spinner`() = runTest(dispatcher) {
        couples.userEvents = flow { awaitCancellation() }
        runCurrent()
        assertTrue(viewModel.uiState.value.isAuthenticated)
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
        assertNull(viewModel.uiState.value.user)
    }

    @Test fun `null cached profile followed by late data recovers without retry`() = runTest(dispatcher) {
        couples.user.value = null
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        couples.user.value = User("me", "Alex")
        runCurrent()
        assertEquals("Alex", viewModel.uiState.value.user?.name)
        assertFalse(viewModel.uiState.value.isLoading)
        assertNull(viewModel.uiState.value.error)
        assertEquals(1, auth.observations)
    }

    @Test fun `late auth emission clears only its watchdog error`() = runTest(dispatcher) {
        val events = MutableSharedFlow<String?>(extraBufferCapacity = 1)
        auth.events = events
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        assertEquals(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
        events.emit(null)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertFalse(viewModel.uiState.value.isAuthenticated)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `a newer error with identical text survives a late successful snapshot`() = runTest(dispatcher) {
        val events = MutableSharedFlow<String?>(extraBufferCapacity = 1)
        auth.events = events
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        viewModel.reportError(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE)
        events.emit(null)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
    }

    @Test fun `healthy invite waiting remains live beyond all loading deadlines`() = runTest(dispatcher) {
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals("old-room", viewModel.uiState.value.room?.roomId)
        advanceTimeBy(PairingViewModel.ACTION_TIMEOUT_MILLIS * 2)
        runCurrent()
        assertNull(viewModel.uiState.value.error)
        couples.oldRoom.value = Result.success(checkNotNull(couples.oldRoom.value.getOrThrow()).copy(user2Id = "partner"))
        runCurrent()
        assertEquals("partner", viewModel.uiState.value.room?.user2Id)
    }

    @Test fun `auth failure immediately exits loading and retry establishes a fresh observation`() = runTest(dispatcher) {
        auth.events = flow { throw WePickException("Start the local Firebase backend, then retry.") }
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals("Start the local Firebase backend, then retry.", viewModel.uiState.value.error)
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        assertEquals("Start the local Firebase backend, then retry.", viewModel.uiState.value.error)
        auth.events = flowOf(null)
        viewModel.retry()
        assertTrue(viewModel.uiState.value.isLoading)
        assertNull(viewModel.uiState.value.error)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertNull(viewModel.uiState.value.error)
        assertEquals(2, auth.observations)
    }

    @Test fun `retry cancels the previous watchdog and starts a full new deadline`() = runTest(dispatcher) {
        var cancellations = 0
        auth.events = flow { try { awaitCancellation() } finally { cancellations++ } }
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS / 2)
        viewModel.retry()
        runCurrent()
        assertEquals(1, cancellations)
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS / 2)
        runCurrent()
        assertTrue(viewModel.uiState.value.isLoading)
        assertNull(viewModel.uiState.value.error)
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS / 2)
        runCurrent()
        assertFalse(viewModel.uiState.value.isLoading)
        assertEquals(PairingViewModel.INITIAL_LOAD_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
    }

    @Test fun `clearing the viewmodel cancels initial observation and watchdog`() = runTest(dispatcher) {
        var cancellations = 0
        auth.events = flow { try { awaitCancellation() } finally { cancellations++ } }
        runCurrent()
        store.clear()
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS * 2)
        runCurrent()
        assertEquals(1, cancellations)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `dismissed watchdog error is not resurrected by time passing`() = runTest(dispatcher) {
        auth.events = flow { awaitCancellation() }
        runCurrent()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS)
        runCurrent()
        viewModel.clearError()
        advanceTimeBy(PairingViewModel.INITIAL_LOAD_TIMEOUT_MILLIS * 2)
        runCurrent()
        assertNull(viewModel.uiState.value.error)
        assertFalse(viewModel.uiState.value.isLoading)
    }

    @Test fun `an action that never returns releases busy state at the fallback deadline`() = runTest(dispatcher) {
        auth.events = flowOf(null)
        auth.signInAction = { awaitCancellation() }
        runCurrent()
        viewModel.signInAnonymously("Alex")
        runCurrent()
        assertTrue(viewModel.uiState.value.isBusy)
        advanceTimeBy(PairingViewModel.ACTION_TIMEOUT_MILLIS)
        runCurrent()
        assertFalse(viewModel.uiState.value.isBusy)
        assertEquals(PairingViewModel.ACTION_TIMEOUT_MESSAGE, viewModel.uiState.value.error)
    }

    @Test fun `earlier data deadline message wins over the action fallback`() = runTest(dispatcher) {
        auth.events = flowOf(null)
        auth.signInAction = { delay(8_000); throw WePickException("The local Firebase backend isn't reachable.") }
        runCurrent()
        viewModel.signInAnonymously("Alex")
        runCurrent()
        advanceTimeBy(8_000)
        runCurrent()
        assertFalse(viewModel.uiState.value.isBusy)
        assertEquals("The local Firebase backend isn't reachable.", viewModel.uiState.value.error)
        advanceTimeBy(PairingViewModel.ACTION_TIMEOUT_MILLIS)
        runCurrent()
        assertEquals("The local Firebase backend isn't reachable.", viewModel.uiState.value.error)
    }

    @Test fun `retry cancels an old action without unlocking a newer action`() = runTest(dispatcher) {
        auth.events = flowOf(null)
        auth.signInAction = { awaitCancellation() }
        runCurrent()
        viewModel.signInAnonymously("Alex")
        runCurrent()
        viewModel.retry()
        val secondAction = CompletableDeferred<Unit>()
        auth.signInAction = { secondAction.await() }
        viewModel.signInAnonymously("Alex")
        runCurrent()
        assertTrue(viewModel.uiState.value.isBusy)
        assertNull(viewModel.uiState.value.error)
        secondAction.complete(Unit)
        runCurrent()
        assertFalse(viewModel.uiState.value.isBusy)
        assertNull(viewModel.uiState.value.error)
    }

    @Test fun `external cancellation is not shown as a network error`() = runTest(dispatcher) {
        auth.events = flowOf(null)
        auth.signInAction = { throw CancellationException("Owner cancelled") }
        runCurrent()
        viewModel.signInAnonymously("Alex")
        runCurrent()
        assertFalse(viewModel.uiState.value.isBusy)
        assertNull(viewModel.uiState.value.error)
    }

    private class FakeAuth : AuthRepository {
        override val userId = "me"
        var observations = 0
        var events: Flow<String?> = flowOf(userId)
        var signInAction: suspend () -> Unit = {}
        override fun observeAuth(): Flow<String?> = flow { observations++; emitAll(events) }
        override suspend fun signInAnonymously(name: String) = signInAction()
        override suspend fun signInWithGoogle(idToken: String) = signInAction()
        override suspend fun signOut() = Unit
    }

    private class FakeCouples : CoupleRepository {
        val user = MutableStateFlow<User?>(User("me", "Alex", coupleRoomId = "old-room"))
        var userEvents: Flow<User?>? = null
        val oldRoom = MutableStateFlow<Result<CoupleRoom?>>(Result.success(CoupleRoom("old-room", "ABC123", "me", createdAt = 0)))
        val newRoom = CoupleRoom("new-room", "XYZ123", "partner", "me", createdAt = 0)
        override fun observeUser(uid: String) = userEvents ?: user
        override fun observeRoom(roomId: String) = if (roomId == "old-room") oldRoom.map { it.getOrThrow() } else flowOf(newRoom)
        override suspend fun createInvite() = checkNotNull(oldRoom.value.getOrThrow())
        override suspend fun joinRoom(code: String) = newRoom
        override suspend fun refreshTokens() = Unit
    }
}
