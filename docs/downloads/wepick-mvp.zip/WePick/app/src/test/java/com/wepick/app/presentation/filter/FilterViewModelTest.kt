package com.wepick.app.presentation.filter

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModelStore
import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.CoupleRoom
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionFilter
import com.wepick.app.domain.model.SwipeSession
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException
import com.wepick.app.domain.repository.CoupleRepository
import com.wepick.app.domain.repository.DeckRepository
import com.wepick.app.domain.repository.SwipeSessionRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.test.StandardTestDispatcher
import kotlinx.coroutines.test.resetMain
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.test.setMain
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class FilterViewModelTest {
    private val dispatcher = StandardTestDispatcher()
    private lateinit var store: ViewModelStore
    private lateinit var couples: FakeCouples
    private lateinit var viewModel: FilterViewModel

    @Before fun setUp() {
        Dispatchers.setMain(dispatcher)
        store = ViewModelStore()
        couples = FakeCouples()
        viewModel = FilterViewModel(SavedStateHandle(mapOf("roomId" to "room")), couples, FakeSessions(), FakeDeck())
        store.put("filters", viewModel)
    }

    @After fun tearDown() { store.clear(); Dispatchers.resetMain() }

    @Test fun `room listener failure clears pending navigation`() = runTest(dispatcher) {
        runCurrent()
        assertEquals("session", viewModel.uiState.value.readySessionId)
        couples.room.value = Result.failure(WePickException("Connection interrupted."))
        runCurrent()
        assertNull(viewModel.uiState.value.readySessionId)
        assertEquals("Connection interrupted.", viewModel.uiState.value.error)
    }

    @Test fun `retry invalidates navigation before replacement listeners emit`() = runTest(dispatcher) {
        runCurrent()
        assertEquals("session", viewModel.uiState.value.readySessionId)
        viewModel.retry()
        // No runCurrent: stale navigation must disappear synchronously.
        assertNull(viewModel.uiState.value.readySessionId)
        assertTrue(viewModel.uiState.value.isLoading)
        runCurrent()
        assertEquals("session", viewModel.uiState.value.readySessionId)
    }

    private class FakeCouples : CoupleRepository {
        private val initialRoom = CoupleRoom("room", "ABC123", "me", "partner", "session", 0)
        val room = MutableStateFlow<Result<CoupleRoom?>>(Result.success(initialRoom))
        override fun observeUser(uid: String) = flowOf<com.wepick.app.domain.model.User?>(null)
        override fun observeRoom(roomId: String) = room.map { it.getOrThrow() }
        override suspend fun createInvite() = initialRoom
        override suspend fun joinRoom(code: String) = initialRoom
        override suspend fun refreshTokens() = Unit
    }

    private class FakeSessions : SwipeSessionRepository {
        override fun observeSession(sessionId: String) = flowOf(SwipeSession("session", "room", Category.FOOD, BudgetTier.LOW, Mood.CHILL, itemIds = listOf("a")))
        override fun observeVotes(sessionId: String) = flowOf(listOf(VoteState("a")))
        override suspend fun createSession(roomId: String, filter: SessionFilter) = "session"
        override suspend fun castVote(sessionId: String, itemId: String, vote: Vote) = Unit
        override suspend fun vetoMatch(sessionId: String, expectedRevision: Long) = Unit
        override suspend fun spinTieBreaker(sessionId: String): String? = null
    }

    private class FakeDeck : DeckRepository {
        private val items = listOf(DeckItem("a", "A café date", Category.FOOD, BudgetTier.LOW, setOf(Mood.CHILL), "An idea", "☕"))
        override fun allItems() = items
        override fun itemsFor(filter: SessionFilter) = items.filter(filter::accepts)
        override fun find(id: String) = items.find { it.id == id }
    }
}
