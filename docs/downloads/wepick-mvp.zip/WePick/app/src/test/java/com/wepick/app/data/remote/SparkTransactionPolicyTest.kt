package com.wepick.app.data.remote

import com.wepick.app.domain.model.User
import com.wepick.app.domain.model.Vote
import com.wepick.app.domain.model.VoteState
import com.wepick.app.domain.model.WePickException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SparkTransactionPolicyTest {
    private val start = 1_700_000_000_000L
    private fun user(tokens: Int) = User("alice", "Alice", vetoTokensRemaining = tokens, lastTokenResetTimestamp = start)

    @Test fun `weekly tokens stay spent until the exact rolling seven day boundary`() {
        assertEquals(WeeklyTokenBalance(0, false), weeklyTokenBalance(user(0), start + TOKEN_WINDOW_MILLIS - 1))
        assertEquals(WeeklyTokenBalance(2, true), weeklyTokenBalance(user(0), start + TOKEN_WINDOW_MILLIS))
    }

    @Test fun `a timestamp probe older than a competing reset never grants another refill`() {
        val justReset = user(1).copy(lastTokenResetTimestamp = start + TOKEN_WINDOW_MILLIS + 1)
        assertEquals(WeeklyTokenBalance(1, false), weeklyTokenBalance(justReset, start + TOKEN_WINDOW_MILLIS))
    }

    @Test fun `multiple elapsed weeks grant two tokens without accumulating a stockpile`() {
        assertEquals(WeeklyTokenBalance(2, true), weeklyTokenBalance(user(1), start + TOKEN_WINDOW_MILLIS * 8))
    }

    @Test fun `concurrent weekly refresh is acknowledged only after both balances were refreshed`() {
        val old = user(0).copy(partnerId = "bob", coupleRoomId = "room")
        val now = start + TOKEN_WINDOW_MILLIS
        val own = old.copy(vetoTokensRemaining = 2, lastTokenResetTimestamp = now + 1)
        val partner = User("bob", "Bob", "alice", "room", 2, now + 1)
        assertTrue(canAcknowledgeTokenRefresh(old, own, partner, true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, own, partner.copy(lastTokenResetTimestamp = start), true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, old, partner, true, now))
    }

    @Test fun `refresh acknowledgement rejects changed or nonreciprocal identities`() {
        val old = user(0).copy(partnerId = "bob", coupleRoomId = "room")
        val now = start + TOKEN_WINDOW_MILLIS
        val own = old.copy(vetoTokensRemaining = 2, lastTokenResetTimestamp = now + 1)
        val partner = User("bob", "Bob", "alice", "room", 2, now + 1)
        assertFalse(canAcknowledgeTokenRefresh(old, own.copy(uid = "outsider"), partner, true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, own.copy(partnerId = "other"), partner, true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, own, partner.copy(partnerId = "other"), true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, own, partner.copy(coupleRoomId = "other"), true, now))
        assertFalse(canAcknowledgeTokenRefresh(old, own, null, true, now))
    }

    @Test fun `own-only refresh acknowledgement does not require a partner read`() {
        val old = user(0).copy(partnerId = "bob", coupleRoomId = "room")
        val now = start + TOKEN_WINDOW_MILLIS
        val own = old.copy(vetoTokensRemaining = 2, lastTokenResetTimestamp = now + 1)
        assertTrue(canAcknowledgeTokenRefresh(old, own, null, false, now))
        assertFalse(canAcknowledgeTokenRefresh(old, old, null, false, now))
    }

    @Test fun `a legal spend after a competing refill does not require another token grant`() {
        val old = user(0)
        val now = start + TOKEN_WINDOW_MILLIS
        val refreshedAndSpent = old.copy(vetoTokensRemaining = 0, lastTokenResetTimestamp = now + 1)
        assertTrue(canAcknowledgeTokenRefresh(old, refreshedAndSpent, null, true, now))
    }

    @Test fun `first and final allowed invite charges stay within the eight attempt quota`() {
        assertEquals(JoinAttemptDecision(1, true), nextJoinAttempt(null, null, start))
        assertEquals(JoinAttemptDecision(8, false), nextJoinAttempt(7, start, start + JOIN_WINDOW_MILLIS - 1))
    }

    @Test fun `a full invite quota rejects before its deadline and restarts at the boundary`() {
        val failure = runCatching { nextJoinAttempt(8, start, start + JOIN_WINDOW_MILLIS - 1) }.exceptionOrNull()
        assertTrue(failure is WePickException)
        assertEquals(JoinAttemptDecision(1, true), nextJoinAttempt(8, start, start + JOIN_WINDOW_MILLIS))
    }

    @Test fun `an older trusted probe cannot bypass a quota whose window just advanced`() {
        val failure = runCatching { nextJoinAttempt(8, start + 1, start) }.exceptionOrNull()
        assertTrue(failure is WePickException)
    }

    @Test fun `missing documents and a slower partner prevent tie breaker completion`() {
        assertFalse(completedDeck(listOf("a", "b"), listOf(VoteState("a", Vote.LIKE, Vote.PASS))).bothFinished)
        assertFalse(completedDeck(listOf("a"), listOf(VoteState("a", Vote.LIKE, null))).bothFinished)
        assertFalse(completedDeck(emptyList(), emptyList()).bothFinished)
    }

    @Test fun `a completed union includes either partners likes once and excludes vetoes`() {
        val progress = completedDeck(listOf("a", "b", "c", "d"), listOf(
            VoteState("a", Vote.LIKE, Vote.PASS),
            VoteState("b", Vote.PASS, Vote.LIKE),
            VoteState("c", Vote.LIKE, Vote.LIKE, vetoedBy = "alice"),
            VoteState("d", Vote.PASS, Vote.PASS),
        ))
        assertTrue(progress.bothFinished)
        assertEquals(listOf("a", "b"), progress.candidateIds)
    }

    @Test fun `a fully vetoed or fully passed deck completes with no eligible winner`() {
        val vetoed = completedDeck(listOf("a"), listOf(VoteState("a", null, null, vetoedBy = "bob")))
        val passed = completedDeck(listOf("a"), listOf(VoteState("a", Vote.PASS, Vote.PASS)))
        assertTrue(vetoed.bothFinished)
        assertTrue(passed.bothFinished)
        assertTrue(vetoed.candidateIds.isEmpty())
        assertTrue(passed.candidateIds.isEmpty())
    }

    @Test fun `unrelated swipe documents cannot expand the authoritative candidate union`() {
        val progress = completedDeck(listOf("a"), listOf(
            VoteState("a", Vote.PASS, Vote.PASS),
            VoteState("forged", Vote.LIKE, Vote.LIKE),
        ))
        assertTrue(progress.bothFinished)
        assertTrue(progress.candidateIds.isEmpty())
    }
}
