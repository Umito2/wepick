package com.wepick.app.data.remote

import com.google.firebase.firestore.FirebaseFirestoreException
import com.wepick.app.domain.model.WePickException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.test.currentTime
import kotlinx.coroutines.test.runCurrent
import kotlinx.coroutines.test.runTest
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

@OptIn(ExperimentalCoroutinesApi::class)
class FirebaseDeadlineTest {
    @Test fun `an operation that never completes becomes an actionable error at its deadline`() = runTest {
        var childCancelled = false
        val failure = runCatching {
            withFirebaseDeadline<Unit>(100, "Preview backend unavailable. Retry after starting it.") {
                try { awaitCancellation() } finally { childCancelled = true }
            }
        }.exceptionOrNull()

        assertTrue(failure is WePickException)
        assertEquals("Preview backend unavailable. Retry after starting it.", failure?.message)
        assertEquals(100L, currentTime)
        assertTrue(childCancelled)
    }

    @Test fun `a successful value returns before the deadline`() = runTest {
        val value = withFirebaseDeadline(100) { delay(20); "ready" }
        assertEquals("ready", value)
        assertEquals(20L, currentTime)
    }

    @Test fun `a successful null result is not confused with a timeout`() = runTest {
        assertNull(withFirebaseDeadline<String?>(100) { null })
    }

    @Test fun `a successful Unit operation remains successful`() = runTest {
        assertEquals(Unit, withFirebaseDeadline(100) { Unit })
    }

    @Test fun `parent cancellation remains cancellation rather than a connection error`() = runTest {
        val cancellation = CancellationException("Screen left")
        var observed: Throwable? = null
        val operation = launch {
            try {
                withFirebaseDeadline<Unit>(1_000) { awaitCancellation() }
            } catch (failure: Throwable) {
                observed = failure
                throw failure
            }
        }
        runCurrent()
        operation.cancel(cancellation)
        runCurrent()
        assertTrue(operation.isCancelled)
        // Coroutine stack-trace recovery may copy the exception; cancellation semantics matter.
        assertTrue(observed is CancellationException)
        assertEquals(cancellation.message, observed?.message)
        assertEquals(0L, currentTime)
    }

    @Test fun `an earlier parent deadline is not reclassified as this operation timeout`() = runTest {
        val failure = runCatching {
            withTimeout(30) {
                withFirebaseDeadline<Unit>(100) { awaitCancellation() }
            }
        }.exceptionOrNull()
        assertTrue(failure is TimeoutCancellationException)
        assertEquals(30L, currentTime)
    }

    @Test fun `a nested timeout also remains cancellation from the nested operation`() = runTest {
        val failure = runCatching {
            withFirebaseDeadline<Unit>(100) {
                withTimeout(30) { awaitCancellation() }
            }
        }.exceptionOrNull()
        assertTrue(failure is TimeoutCancellationException)
        assertEquals(30L, currentTime)
    }

    @Test fun `SDK failures pass through the deadline helper unchanged`() = runTest {
        val sdkFailure = FirebaseFirestoreException("Denied", FirebaseFirestoreException.Code.PERMISSION_DENIED)
        val failure = runCatching {
            withFirebaseDeadline<Unit>(100) { throw sdkFailure }
        }.exceptionOrNull()
        assertSame(sdkFailure, failure)
    }

    @Test fun `the repository wrapper retains normal SDK error mapping`() = runTest {
        val sdkFailure = FirebaseFirestoreException("Denied", FirebaseFirestoreException.Code.PERMISSION_DENIED)
        val failure = runCatching { firebaseOperation<Unit> { throw sdkFailure } }.exceptionOrNull()
        assertTrue(failure is WePickException)
        assertSame(sdkFailure, failure?.cause)
        assertEquals("This session is no longer available to your account. Return to your room.", failure?.message)
    }
}
