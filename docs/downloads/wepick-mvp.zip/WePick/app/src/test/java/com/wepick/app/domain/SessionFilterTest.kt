package com.wepick.app.domain

import com.wepick.app.domain.model.BudgetTier
import com.wepick.app.domain.model.Category
import com.wepick.app.domain.model.DeckItem
import com.wepick.app.domain.model.Mood
import com.wepick.app.domain.model.SessionFilter
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionFilterTest {
    private val cozyFood = DeckItem("soup", "Soup", Category.FOOD, BudgetTier.LOW, setOf(Mood.COZY), "Warm soup", "🍲")

    @Test fun `budget is a maximum and category and mood remain strict`() {
        assertTrue(SessionFilter(Category.FOOD, BudgetTier.HIGH, Mood.COZY).accepts(cozyFood))
        assertTrue(SessionFilter(Category.FOOD, BudgetTier.LOW, Mood.COZY).accepts(cozyFood))
        assertFalse(SessionFilter(Category.FOOD, BudgetTier.LOW, Mood.COZY).accepts(cozyFood.copy(priceTier = BudgetTier.HIGH)))
        assertFalse(SessionFilter(Category.MOVIES, BudgetTier.HIGH, Mood.COZY).accepts(cozyFood))
        assertFalse(SessionFilter(Category.FOOD, BudgetTier.HIGH, Mood.ENERGETIC).accepts(cozyFood))
    }
}
