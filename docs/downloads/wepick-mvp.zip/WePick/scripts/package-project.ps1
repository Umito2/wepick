$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem
$projectRoot = [System.IO.Path]::GetFullPath((Split-Path -Parent $PSScriptRoot))
$archivePath = Join-Path $projectRoot 'wepick-mvp.zip'
$excludedDirectories = @('.git', '.gradle', '.kotlin', '.tools', '.idea', '.firebase', '.npm-cache', 'node_modules', 'build', 'lib', 'coverage', 'sites')
$excludedFiles = @('local.properties', 'google-services.json', 'signing.properties', '.firebaserc', 'wepick-mvp.zip')

function Get-SourceFiles([string]$directory) {
    foreach ($entry in Get-ChildItem -LiteralPath $directory -Force) {
        if ($entry.PSIsContainer) {
            if ($entry.Name -notin $excludedDirectories -and -not ($entry.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) {
                Get-SourceFiles $entry.FullName
            }
        } elseif ($entry.Name -notin $excludedFiles -and $entry.Extension -notin @('.log', '.jks', '.keystore', '.iml')) {
            $entry
        }
    }
}

$stream = [System.IO.File]::Open($archivePath, [System.IO.FileMode]::Create)
$archive = New-Object System.IO.Compression.ZipArchive($stream, [System.IO.Compression.ZipArchiveMode]::Create)
try {
    $count = 0
    foreach ($file in Get-SourceFiles $projectRoot) {
        $relative = $file.FullName.Substring($projectRoot.Length + 1).Replace('\', '/')
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($archive, $file.FullName, "WePick/$relative", [System.IO.Compression.CompressionLevel]::Optimal) | Out-Null
        $count++
    }
} finally {
    $archive.Dispose()
    $stream.Dispose()
}
Write-Output "Packaged $count source files into $archivePath"
