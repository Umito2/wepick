param([switch]$SkipAndroid)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$projectRoot = Split-Path -Parent $PSScriptRoot
$toolRoot = Join-Path $projectRoot '.tools'
New-Item -ItemType Directory -Path $toolRoot -Force | Out-Null

function Get-RemoteText([string]$url) {
    $response = Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 $url
    if ($response.Content -is [byte[]]) { return [System.Text.Encoding]::UTF8.GetString($response.Content).Trim() }
    return $response.Content.Trim()
}

if (-not (Test-Path -LiteralPath (Join-Path $toolRoot 'jdk'))) {
    $jdkAssets = Invoke-RestMethod -TimeoutSec 60 'https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse'
    $jdkPackage = $jdkAssets[0].binary.package
    $jdkZip = Join-Path $toolRoot 'jdk.zip'
    Write-Output 'Downloading Eclipse Temurin JDK 21...'
    Invoke-WebRequest -UseBasicParsing -TimeoutSec 600 $jdkPackage.link -OutFile $jdkZip
    if ((Get-FileHash -LiteralPath $jdkZip -Algorithm SHA256).Hash.ToLowerInvariant() -ne $jdkPackage.checksum) {
        throw 'JDK checksum mismatch'
    }
    & tar.exe -xf $jdkZip -C $toolRoot
    if ($LASTEXITCODE -ne 0) { throw 'JDK extraction failed' }
    $jdkDirectory = Get-ChildItem -LiteralPath $toolRoot -Directory | Where-Object Name -Like 'jdk-*' | Select-Object -First 1
    Rename-Item -LiteralPath $jdkDirectory.FullName -NewName 'jdk'
}
$env:JAVA_HOME = Join-Path $toolRoot 'jdk'
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"
Write-Output "JDK ready: $env:JAVA_HOME"

$wrapperRoot = Join-Path $projectRoot 'gradle/wrapper'
New-Item -ItemType Directory -Path $wrapperRoot -Force | Out-Null
$gradleBase = 'https://raw.githubusercontent.com/gradle/gradle/v8.13.0'
foreach ($entry in @(@('gradlew','gradlew'), @('gradlew.bat','gradlew.bat'), @('gradle/wrapper/gradle-wrapper.jar','gradle/wrapper/gradle-wrapper.jar'))) {
    $destination = Join-Path $projectRoot $entry[1]
    if (-not (Test-Path -LiteralPath $destination)) {
        Invoke-WebRequest -UseBasicParsing -TimeoutSec 60 "$gradleBase/$($entry[0])" -OutFile $destination
    }
}
$wrapperHash = Get-RemoteText 'https://services.gradle.org/distributions/gradle-8.13-wrapper.jar.sha256'
if ((Get-FileHash -LiteralPath (Join-Path $wrapperRoot 'gradle-wrapper.jar') -Algorithm SHA256).Hash.ToLowerInvariant() -ne $wrapperHash) {
    throw 'Gradle wrapper checksum mismatch'
}
$distributionHash = Get-RemoteText 'https://services.gradle.org/distributions/gradle-8.13-bin.zip.sha256'
@"
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.13-bin.zip
distributionSha256Sum=$distributionHash
networkTimeout=120000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
"@ | Set-Content -LiteralPath (Join-Path $wrapperRoot 'gradle-wrapper.properties') -Encoding ASCII

if ($SkipAndroid) { exit 0 }
$sdkRoot = Join-Path $toolRoot 'android-sdk'
$sdkManager = Join-Path $sdkRoot 'cmdline-tools/latest/bin/sdkmanager.bat'
if (-not (Test-Path -LiteralPath $sdkManager)) {
    Write-Output 'Downloading Android command-line tools...'
    [xml]$repository = Get-RemoteText 'https://dl.google.com/android/repository/repository2-1.xml'
    $package = $repository.SelectNodes('//*[local-name()="remotePackage"]') | Where-Object { $_.path -eq 'cmdline-tools;latest' } | Select-Object -First 1
    $archive = $package.archives.archive | Where-Object { $_.'host-os' -eq 'windows' } | Select-Object -First 1
    $sdkZip = Join-Path $toolRoot 'commandline-tools.zip'
    Invoke-WebRequest -UseBasicParsing -TimeoutSec 600 "https://dl.google.com/android/repository/$($archive.complete.url)" -OutFile $sdkZip
    $checksum = [string]$archive.complete.checksum
    if ((Get-FileHash -LiteralPath $sdkZip -Algorithm SHA1).Hash.ToLowerInvariant() -ne $checksum) {
        throw 'Android command-line tools checksum mismatch'
    }
    $commandRoot = Join-Path $sdkRoot 'cmdline-tools'
    New-Item -ItemType Directory -Path $commandRoot -Force | Out-Null
    & tar.exe -xf $sdkZip -C $commandRoot
    if ($LASTEXITCODE -ne 0) { throw 'Android tools extraction failed' }
    Rename-Item -LiteralPath (Join-Path $commandRoot 'cmdline-tools') -NewName 'latest'
}
$env:ANDROID_HOME = $sdkRoot
# Accept SDK component licenses for this local build toolchain.
1..50 | ForEach-Object { 'y' } | & $sdkManager "--sdk_root=$sdkRoot" --licenses | Out-Null
& $sdkManager "--sdk_root=$sdkRoot" 'platforms;android-36' 'build-tools;36.0.0' 'platform-tools'
if ($LASTEXITCODE -ne 0) { throw 'Android SDK installation failed' }
$sdkProperty = $sdkRoot.Replace('\','/').Replace(':','\:')
"sdk.dir=$sdkProperty" | Set-Content -LiteralPath (Join-Path $projectRoot 'local.properties') -Encoding ASCII
Write-Output 'Toolchain ready. Set JAVA_HOME to .tools/jdk and GRADLE_USER_HOME to .tools/gradle-cache before building.'
