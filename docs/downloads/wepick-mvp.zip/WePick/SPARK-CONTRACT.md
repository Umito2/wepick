# WePick Spark transaction contract

This replaces the callable-function wire contract in CONTRACT.md. Firebase Authentication and Cloud Firestore are the runtime backend; Cloud Functions and billing are not required. Existing user, room, session and swipe fields remain unchanged, including session `createdAt` and `matchRevision`.

## Trusted catalogue and time

Administrators seed `deck_filters/{CATEGORY_BUDGET_MOOD}` with `{itemIds: [String]}` from `catalog/deck.json`. Clients may get these documents but cannot list or write them. Each filter contains 1–5 IDs in catalogue order. Sessions must preserve this exact list. All swipe documents are initialized atomically with session creation and the room's activeSessionId change.

`request_times/{uid}` contains only `{now: serverTimestamp()}`. Only that user can get/create/update it; no lists/deletes. A server read after the write provides a trusted time hint for Kotlin branching. Rules independently enforce `request.time` for all creation, reset and quota decisions, so the hint cannot grant permissions.

## Profiles and weekly tokens

Own profile creation requires exactly the existing schema, unpaired/null room, two tokens, and lastTokenResetTimestamp equal to request.time. Own name edits preserve all other fields. A due weekly reset (seven rolling days) changes only tokens to two and reset timestamp to request.time; either partner may refresh an existing reciprocal partner's balance. A veto debit uses the current balance, or one token remaining with a new server timestamp when the week is due. Token debits require the same atomic session/swipe veto transition. No arbitrary profile deletion is allowed.

## Private invite pairing

`invite_codes/{code}` remains `{roomId, consumed, createdAt}`. Code IDs contain six uppercase letters/digits. No client list or delete is allowed. Codes are unique by create-only writes. createInvite uses a blind set of the generated invite document in a transaction with room creation and own profile linkage; it does not read a missing reservation. A denied collision may be retried only a bounded number of times after confirming the own profile remains unpaired.

`join_attempts/{uid}` contains exactly `{count, windowStart, lastCode}`. Own writes start a window at count 1 / request.time, increment within a window up to eight, or reset after 15 minutes. lastCode must be a valid six-character code. Own reads only; no deletes/lists. Invite gets require either the current charged lastCode in an active window, or ownership of the invite's room. This limits code changes, not repeated reads of one code; anonymous account creation can bypass a per-account quota.

A pending room may be read through that charged, unconsumed invitation; joined rooms are member-only. The join transaction reads only the joining user's profile, its own optional abandoned pending room, the charged invite and target room. It must not read the host profile before pairing. It blind-updates the host's partnerId while atomically updating the joiner's partnerId/coupleRoomId, room.user2Id and invite.consumed. Rules validate reciprocal getAfter links. If switching from an own unused invitation, delete the old empty room and consume its invite atomically. Already-paired own-room/code retries return the existing room without rejoining.

## Sessions, votes, veto and tie breaker

Room members may create a round only once both partners joined. Reuse an unfinished ACTIVE round; replacement is allowed when MATCHED, or when all nonvetoed cards have both votes and the remaining likes union is empty. Validate this old-session condition in the room update rule and validate the new catalogue/list/swipes in the session creation rule to remain within Firestore's access-call limits.

The native castVote transaction stays: immutable first vote only, own field only, current active room/session only. A second LIKE must atomically publish the mutual match and increment matchRevision. Veto changes only matched swipe.vetoedBy to the caller, debits only that caller, and resumes ACTIVE/null match/source with revision +1. expectedRevision remains the client retry/idempotence guard; stale revisions perform no writes.

Tie breaking requires both users to finish every nonvetoed card. A client chooses an item randomly from the union of LIKE votes, excluding vetoed cards, then atomically publishes MATCHED/TIE_BREAKER with revision +1. Rules independently validate eligibility and exhaustion. Concurrent/retried calls return the committed match; an empty union yields null without writes. Without a trusted compute backend, rules cannot prove that a modified client sampled uniformly. No AI or LLM is involved.

## Security limits

No client may list users, rooms, sessions, invite codes, quotas or catalogue configurations. Only member swipe collection reads are allowed. Rules keep each operation within ten document accesses and each transaction within twenty; emulator tests must cover the largest five-card creation and exhaustion paths as well as profile, vote, token, catalogue and pairing forgeries.
