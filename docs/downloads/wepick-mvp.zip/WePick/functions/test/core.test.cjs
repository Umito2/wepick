const assert = require("node:assert/strict");
const { readFileSync } = require("node:fs");
const { join } = require("node:path");
const test = require("node:test");
// Node 22.18+ can execute this dependency-free domain suite directly from TypeScript.
const { WEEK_MS, filterDeck, shuffle, tieBreakerState, tokenBalance } = require("../src/logic.ts");

test("weekly resets are anchored, capped at two, and insensitive to a backward clock", () => {
  assert.deepEqual(tokenBalance(0, 1000, 1000 + WEEK_MS - 1), { tokens: 0, resetMs: 1000 });
  assert.deepEqual(tokenBalance(0, 1000, 1000 + WEEK_MS), { tokens: 2, resetMs: 1000 + WEEK_MS });
  assert.deepEqual(tokenBalance(1, 1000, 1100 + WEEK_MS * 5), { tokens: 2, resetMs: 1000 + WEEK_MS * 5 });
  assert.deepEqual(tokenBalance(1, 1000, 900), { tokens: 1, resetMs: 1000 });
});

test("tie breaker waits for both partners, ignores vetoes, and uses an unweighted union", () => {
  const swipes = [
    { itemId: "a", user1Vote: "LIKE", user2Vote: "PASS", vetoedBy: null },
    { itemId: "b", user1Vote: "PASS", user2Vote: "LIKE", vetoedBy: null },
    { itemId: "c", user1Vote: "LIKE", user2Vote: "LIKE", vetoedBy: "partner" },
    { itemId: "d", user1Vote: "PASS", user2Vote: null, vetoedBy: null },
  ];
  assert.deepEqual(tieBreakerState(swipes), { completed: false, candidates: ["a", "b"] });
  swipes[3].user2Vote = "PASS";
  assert.deepEqual(tieBreakerState(swipes), { completed: true, candidates: ["a", "b"] });
  assert.deepEqual(tieBreakerState([{ itemId: "e", user1Vote: "PASS", user2Vote: "PASS", vetoedBy: null }]), { completed: true, candidates: [] });
});

test("catalogue has 20 unique cards, five per category, with a low-budget choice for every mood", () => {
  const items = JSON.parse(readFileSync(join(__dirname, "../../catalog/deck.json"), "utf8"));
  assert.equal(items.length, 20);
  assert.equal(new Set(items.map((item) => item.id)).size, 20);
  for (const category of ["FOOD", "OUTINGS", "MOVIES", "ACTIVITIES"]) {
    assert.equal(items.filter((item) => item.category === category).length, 5);
    for (const mood of ["CHILL", "ENERGETIC", "COZY"]) {
      const low = filterDeck(items, category, "LOW", mood);
      assert.ok(low.length > 0, `${category}/${mood} must have a low-budget card`);
      assert.ok(filterDeck(items, category, "HIGH", mood).length >= low.length);
    }
  }
});

test("shuffle preserves the original and every unique candidate", () => {
  const original = ["a", "b", "c", "d"];
  const shuffled = shuffle(original, () => 0);
  assert.deepEqual(original, ["a", "b", "c", "d"]);
  assert.deepEqual([...shuffled].sort(), original);
  assert.notDeepEqual(shuffled, original);
});
