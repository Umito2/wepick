import { randomInt } from "node:crypto";
import {
  DocumentSnapshot, Firestore, Timestamp, Transaction, collection, doc,
  getDocFromServer, runTransaction, serverTimestamp, setDoc,
} from "firebase/firestore";

/** Transaction client only: no emulator setup, credentials, or application initialization. */
export interface Client { uid: string; db: Firestore }
export type Vote = "LIKE" | "PASS";
export interface SessionFilter {
  category: "FOOD" | "OUTINGS" | "MOVIES" | "ACTIVITIES";
  budgetFilter: "LOW" | "MEDIUM" | "HIGH";
  moodTag: "CHILL" | "ENERGETIC" | "COZY";
}
interface Profile {
  uid: string; name: string; partnerId: string | null; coupleRoomId: string | null;
  vetoTokensRemaining: number; lastTokenResetTimestamp: Timestamp;
}
interface Room {
  roomId: string; inviteCode: string; user1Id: string; user2Id: string | null;
  activeSessionId: string | null; createdAt: Timestamp;
}
interface Session extends SessionFilter {
  sessionId: string; roomId: string; itemIds: string[]; status: "ACTIVE" | "MATCHED";
  matchedItemId: string | null; matchSource: "MUTUAL" | "TIE_BREAKER" | null;
  matchRevision: number; createdAt: Timestamp;
}
interface Swipe { itemId: string; user1Vote: Vote | null; user2Vote: Vote | null; vetoedBy: string | null }
export const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const JOIN_WINDOW_MS = 15 * 60 * 1000;
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function fail(code: string, message: string): never { throw Object.assign(new Error(message), { code }); }
function data<T>(snapshot: DocumentSnapshot, label: string): T {
  if (!snapshot.exists()) fail("not-found", `${label} is unavailable.`);
  return snapshot.data() as T;
}
function codeOf(error: unknown): string | undefined { return (error as { code?: string })?.code; }
function member(room: Room, uid: string): void {
  if (![room.user1Id, room.user2Id].includes(uid)) fail("permission-denied", "Room membership is required.");
}
function active(room: Room, session: Session): void {
  if (room.activeSessionId !== session.sessionId) fail("failed-precondition", "A newer round is active.");
}
function due(profile: Profile, now: Timestamp): boolean {
  return now.toMillis() - profile.lastTokenResetTimestamp.toMillis() >= WEEK_MS;
}
function progress(swipes: Swipe[]): { completed: boolean; candidates: string[] } {
  const remaining = swipes.filter((swipe) => swipe.vetoedBy === null);
  return {
    completed: remaining.every((swipe) => swipe.user1Vote !== null && swipe.user2Vote !== null),
    candidates: remaining.filter((swipe) => swipe.user1Vote === "LIKE" || swipe.user2Vote === "LIKE").map((swipe) => swipe.itemId),
  };
}
async function swipes(tx: Transaction, user: Client, session: Session): Promise<Swipe[]> {
  return Promise.all(session.itemIds.map(async (id) => data<Swipe>(await tx.get(doc(user.db, "sessions", session.sessionId, "swipes", id)), "Swipe")));
}
async function serverTime(user: Client): Promise<Timestamp> {
  const ref = doc(user.db, "request_times", user.uid);
  await setDoc(ref, { now: serverTimestamp() });
  const now = (await getDocFromServer(ref)).get("now");
  if (!(now instanceof Timestamp)) fail("failed-precondition", "The server timestamp is unavailable.");
  return now;
}

export async function ensureUser(user: Client, name = "Partner"): Promise<void> {
  const trimmed = name.trim();
  if (!trimmed || trimmed.length > 40) fail("invalid-argument", "Name must contain 1–40 characters.");
  await runTransaction(user.db, async (tx) => {
    const ref = doc(user.db, "users", user.uid);
    const snapshot = await tx.get(ref);
    if (!snapshot.exists()) {
      tx.set(ref, { uid: user.uid, name: trimmed, partnerId: null, coupleRoomId: null, vetoTokensRemaining: 2, lastTokenResetTimestamp: serverTimestamp() });
    } else if (snapshot.get("name") !== trimmed) {
      tx.update(ref, { name: trimmed });
    }
  });
}

/** An optional generator lets emulator tests force a collision without weakening the rules. */
export async function createInvite(user: Client, codeFactory: () => string = () => Array.from({ length: 6 }, () => CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]).join("")): Promise<{ roomId: string; inviteCode: string }> {
  for (let attempt = 0; attempt < 8; attempt++) {
    const code = codeFactory();
    if (!/^[A-Z0-9]{6}$/.test(code)) fail("invalid-argument", "Invalid invite code.");
    const roomRef = doc(collection(user.db, "couple_rooms"));
    try {
      return await runTransaction(user.db, async (tx) => {
        const profileRef = doc(user.db, "users", user.uid);
        const profile = data<Profile>(await tx.get(profileRef), "Profile");
        if (profile.coupleRoomId) {
          const room = data<Room>(await tx.get(doc(user.db, "couple_rooms", profile.coupleRoomId)), "Room");
          member(room, user.uid);
          return { roomId: room.roomId, inviteCode: room.inviteCode };
        }
        tx.set(roomRef, { roomId: roomRef.id, inviteCode: code, user1Id: user.uid, user2Id: null, activeSessionId: null, createdAt: serverTimestamp() });
        // A reservation is a blind create-only write; missing-code reads are deliberately private.
        tx.set(doc(user.db, "invite_codes", code), { roomId: roomRef.id, consumed: false, createdAt: serverTimestamp() });
        tx.update(profileRef, { coupleRoomId: roomRef.id });
        return { roomId: roomRef.id, inviteCode: code };
      });
    } catch (error) {
      if (codeOf(error) !== "permission-denied" || attempt === 7) throw error;
      const profile = data<Profile>(await getDocFromServer(doc(user.db, "users", user.uid)), "Profile");
      if (profile.coupleRoomId) {
        const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", profile.coupleRoomId)), "Room");
        member(room, user.uid);
        return { roomId: room.roomId, inviteCode: room.inviteCode };
      }
    }
  }
  return fail("resource-exhausted", "Could not allocate an invite code.");
}

export async function joinRoom(user: Client, rawCode: string): Promise<string> {
  const code = rawCode.trim().toUpperCase();
  if (!/^[A-Z0-9]{6}$/.test(code)) fail("invalid-argument", "Enter a six-character code.");
  const own = data<Profile>(await getDocFromServer(doc(user.db, "users", user.uid)), "Profile");
  if (own.coupleRoomId && own.partnerId) {
    const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", own.coupleRoomId)), "Room");
    if (room.inviteCode === code) return room.roomId;
    fail("failed-precondition", "Already paired with a partner.");
  }
  const now = await serverTime(user);
  await runTransaction(user.db, async (tx) => {
    const ref = doc(user.db, "join_attempts", user.uid);
    const snapshot = await tx.get(ref);
    const reset = !snapshot.exists() || now.toMillis() - (snapshot.get("windowStart") as Timestamp).toMillis() >= JOIN_WINDOW_MS;
    const count = reset ? 0 : Number(snapshot.get("count"));
    if (count >= 8) fail("resource-exhausted", "Try another invite after fifteen minutes.");
    tx.set(ref, { count: count + 1, windowStart: reset ? serverTimestamp() : snapshot.get("windowStart"), lastCode: code });
  });
  return runTransaction(user.db, async (tx) => {
    const ownRef = doc(user.db, "users", user.uid);
    const profile = data<Profile>(await tx.get(ownRef), "Profile");
    const inviteRef = doc(user.db, "invite_codes", code);
    const invite = data<{ roomId: string; consumed: boolean }>(await tx.get(inviteRef), "Invite");
    const roomRef = doc(user.db, "couple_rooms", invite.roomId);
    const room = data<Room>(await tx.get(roomRef), "Room");
    if (room.user2Id === user.uid && profile.coupleRoomId === room.roomId) return room.roomId;
    if (room.user1Id === user.uid || room.user2Id !== null || invite.consumed || profile.partnerId !== null) fail("failed-precondition", "Invite is unavailable.");
    let abandoned: Room | undefined;
    if (profile.coupleRoomId) {
      abandoned = data<Room>(await tx.get(doc(user.db, "couple_rooms", profile.coupleRoomId)), "Old room");
      if (abandoned.user1Id !== user.uid || abandoned.user2Id !== null || abandoned.activeSessionId !== null) fail("failed-precondition", "Already paired with a partner.");
    }
    tx.update(roomRef, { user2Id: user.uid });
    tx.update(ownRef, { partnerId: room.user1Id, coupleRoomId: room.roomId });
    // Host profile is unreadable before pairing. Rules validate this restricted blind update.
    tx.update(doc(user.db, "users", room.user1Id), { partnerId: user.uid });
    tx.update(inviteRef, { consumed: true });
    if (abandoned) {
      tx.delete(doc(user.db, "couple_rooms", abandoned.roomId));
      tx.update(doc(user.db, "invite_codes", abandoned.inviteCode), { consumed: true });
    }
    return room.roomId;
  });
}

export async function refreshTokens(user: Client): Promise<void> {
  const now = await serverTime(user);
  let attemptedPartnerId: string | null | undefined;
  let attemptedRoomId: string | null | undefined;
  try {
    await runTransaction(user.db, async (tx) => {
      const own = await tx.get(doc(user.db, "users", user.uid));
      const profile = data<Profile>(own, "Profile");
      attemptedPartnerId = profile.partnerId;
      attemptedRoomId = profile.coupleRoomId;
      const snapshots = [own];
      if (profile.partnerId) snapshots.push(await tx.get(doc(user.db, "users", profile.partnerId)));
      for (const snapshot of snapshots) {
        if (due(data<Profile>(snapshot, "Profile"), now)) tx.update(snapshot.ref, { vetoTokensRemaining: 2, lastTokenResetTimestamp: serverTimestamp() });
      }
    });
  } catch (error) {
    if (codeOf(error) !== "permission-denied" || attemptedPartnerId === undefined) throw error;
    // Another reset can make stale rule evaluation fail before the SDK retries its precondition.
    // Acknowledge only fresh, reciprocal profiles for which no requested refill remains due.
    const own = data<Profile>(await getDocFromServer(doc(user.db, "users", user.uid)), "Profile");
    if (own.uid !== user.uid || own.partnerId !== attemptedPartnerId || own.coupleRoomId !== attemptedRoomId || due(own, now)) throw error;
    if (own.partnerId) {
      const partner = data<Profile>(await getDocFromServer(doc(user.db, "users", own.partnerId)), "Partner");
      if (partner.uid !== own.partnerId || partner.partnerId !== user.uid || !own.coupleRoomId || partner.coupleRoomId !== own.coupleRoomId || due(partner, now)) throw error;
    }
  }
}

export async function createSession(user: Client, roomId: string, filter: SessionFilter = { category: "FOOD", budgetFilter: "HIGH", moodTag: "CHILL" }): Promise<string> {
  const sessionRef = doc(collection(user.db, "sessions"));
  try {
    return await runTransaction(user.db, async (tx) => {
      const roomRef = doc(user.db, "couple_rooms", roomId);
      const room = data<Room>(await tx.get(roomRef), "Room");
      member(room, user.uid);
      if (!room.user2Id) fail("failed-precondition", "Wait for your partner.");
      if (room.activeSessionId) {
        const current = data<Session>(await tx.get(doc(user.db, "sessions", room.activeSessionId)), "Round");
        if (current.status === "ACTIVE") {
          const state = progress(await swipes(tx, user, current));
          if (!state.completed || state.candidates.length > 0) return current.sessionId;
        }
      }
      const filterId = `${filter.category}_${filter.budgetFilter}_${filter.moodTag}`;
      const itemIds = data<{ itemIds: string[] }>(await tx.get(doc(user.db, "deck_filters", filterId)), "Catalogue filter").itemIds;
      if (!itemIds.length || itemIds.length > 5) fail("failed-precondition", "Catalogue filter is unavailable.");
      tx.set(sessionRef, { sessionId: sessionRef.id, roomId, ...filter, status: "ACTIVE", matchedItemId: null, itemIds, matchSource: null, matchRevision: 0, createdAt: serverTimestamp() });
      for (const itemId of itemIds) tx.set(doc(user.db, "sessions", sessionRef.id, "swipes", itemId), { itemId, user1Vote: null, user2Vote: null, vetoedBy: null });
      tx.update(roomRef, { activeSessionId: sessionRef.id });
      return sessionRef.id;
    });
  } catch (error) {
    if (codeOf(error) !== "permission-denied") throw error;
    const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", roomId)), "Room");
    member(room, user.uid);
    if (!room.activeSessionId || room.activeSessionId === sessionRef.id) throw error;
    const current = data<Session>(await getDocFromServer(doc(user.db, "sessions", room.activeSessionId)), "Round");
    if (current.status !== "ACTIVE" || current.roomId !== roomId) throw error;
    return current.sessionId;
  }
}

/** Same narrow simultaneous-first-LIKE recovery as the Android repository. */
export async function castVote(user: Client, sessionId: string, itemId: string, value: Vote, beforeFirstCommit?: () => Promise<void>): Promise<void> {
  let firstRead = true;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      await runTransaction(user.db, async (tx) => {
        const sessionRef = doc(user.db, "sessions", sessionId);
        const session = data<Session>(await tx.get(sessionRef), "Round");
        const room = data<Room>(await tx.get(doc(user.db, "couple_rooms", session.roomId)), "Room");
        const swipeRef = doc(user.db, "sessions", sessionId, "swipes", itemId);
        const swipe = data<Swipe>(await tx.get(swipeRef), "Swipe");
        member(room, user.uid); active(room, session);
        const own = room.user1Id === user.uid ? "user1Vote" : "user2Vote";
        const peer = own === "user1Vote" ? "user2Vote" : "user1Vote";
        if (swipe[own] === value) return;
        if (session.status !== "ACTIVE" || swipe[own] !== null || swipe.vetoedBy !== null) fail("failed-precondition", "Vote is no longer available.");
        if (firstRead) { firstRead = false; await beforeFirstCommit?.(); }
        tx.update(swipeRef, { [own]: value });
        if (value === "LIKE" && swipe[peer] === "LIKE") tx.update(sessionRef, { status: "MATCHED", matchedItemId: itemId, matchSource: "MUTUAL", matchRevision: session.matchRevision + 1 });
      });
      return;
    } catch (error) {
      if (codeOf(error) !== "permission-denied" || value !== "LIKE" || attempt === 2) throw error;
      const session = data<Session>(await getDocFromServer(doc(user.db, "sessions", sessionId)), "Round");
      const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", session.roomId)), "Room");
      const swipe = data<Swipe>(await getDocFromServer(doc(user.db, "sessions", sessionId, "swipes", itemId)), "Swipe");
      member(room, user.uid); active(room, session);
      const own = room.user1Id === user.uid ? "user1Vote" : "user2Vote";
      const peer = own === "user1Vote" ? "user2Vote" : "user1Vote";
      if (swipe[own] === value) return;
      if (session.status !== "ACTIVE" || swipe.vetoedBy !== null || swipe[own] !== null || swipe[peer] !== "LIKE") throw error;
    }
  }
}
export const vote = castVote;

export async function vetoMatch(user: Client, sessionId: string, expectedRevision: number): Promise<void> {
  const now = await serverTime(user);
  try {
    await runTransaction(user.db, async (tx) => {
      const ref = doc(user.db, "sessions", sessionId);
      const session = data<Session>(await tx.get(ref), "Round");
      const room = data<Room>(await tx.get(doc(user.db, "couple_rooms", session.roomId)), "Room");
      member(room, user.uid); active(room, session);
      if (session.status !== "MATCHED" || session.matchRevision !== expectedRevision || !session.matchedItemId) return;
      const profileRef = doc(user.db, "users", user.uid);
      const profile = data<Profile>(await tx.get(profileRef), "Profile");
      const swipeRef = doc(user.db, "sessions", sessionId, "swipes", session.matchedItemId);
      const swipe = data<Swipe>(await tx.get(swipeRef), "Swipe");
      if (swipe.vetoedBy !== null) fail("failed-precondition", "This card was already vetoed.");
      const reset = due(profile, now);
      const balance = reset ? 2 : profile.vetoTokensRemaining;
      if (!balance) fail("resource-exhausted", "No veto tokens remain this week.");
      tx.update(profileRef, { vetoTokensRemaining: balance - 1, ...(reset ? { lastTokenResetTimestamp: serverTimestamp() } : {}) });
      tx.update(swipeRef, { vetoedBy: user.uid });
      tx.update(ref, { status: "ACTIVE", matchedItemId: null, matchSource: null, matchRevision: session.matchRevision + 1 });
    });
  } catch (error) {
    if (codeOf(error) !== "permission-denied") throw error;
    const session = data<Session>(await getDocFromServer(doc(user.db, "sessions", sessionId)), "Round");
    const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", session.roomId)), "Room");
    member(room, user.uid); active(room, session);
    if (session.matchRevision === expectedRevision) throw error;
  }
}

export async function spinTieBreaker(user: Client, sessionId: string): Promise<string | null> {
  try {
    return await runTransaction(user.db, async (tx) => {
      const ref = doc(user.db, "sessions", sessionId);
      const session = data<Session>(await tx.get(ref), "Round");
      const room = data<Room>(await tx.get(doc(user.db, "couple_rooms", session.roomId)), "Room");
      member(room, user.uid); active(room, session);
      if (session.status === "MATCHED") return session.matchedItemId;
      const state = progress(await swipes(tx, user, session));
      if (!state.completed) fail("failed-precondition", "Both partners must finish the deck.");
      if (!state.candidates.length) return null;
      // This runs on the client. Rules prove eligibility, not uniform random sampling.
      const itemId = state.candidates[randomInt(state.candidates.length)];
      tx.update(ref, { status: "MATCHED", matchedItemId: itemId, matchSource: "TIE_BREAKER", matchRevision: session.matchRevision + 1 });
      return itemId;
    });
  } catch (error) {
    if (codeOf(error) !== "permission-denied") throw error;
    const session = data<Session>(await getDocFromServer(doc(user.db, "sessions", sessionId)), "Round");
    const room = data<Room>(await getDocFromServer(doc(user.db, "couple_rooms", session.roomId)), "Room");
    member(room, user.uid); active(room, session);
    if (session.status !== "MATCHED") throw error;
    return session.matchedItemId;
  }
}
