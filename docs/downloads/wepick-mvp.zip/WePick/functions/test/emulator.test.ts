import assert from "node:assert/strict";
import { after, test } from "node:test";
import { initializeApp as initializeAdminApp } from "firebase-admin/app";
import { Timestamp, getFirestore as getAdminFirestore } from "firebase-admin/firestore";
import { FirebaseApp, deleteApp, initializeApp } from "firebase/app";
import { connectAuthEmulator, getAuth, signInAnonymously } from "firebase/auth";
import { Firestore, connectFirestoreEmulator, doc, getDoc, getDocFromServer, getDocs, collection, getFirestore, onSnapshot, runTransaction, setDoc, updateDoc } from "firebase/firestore";
import { Functions, connectFunctionsEmulator, getFunctions, httpsCallable } from "firebase/functions";
import { assertFails } from "@firebase/rules-unit-testing";
import { WEEK_MS } from "../src/logic";

// Run only with `npm run test:emulator`; never point these tests at a live Firebase project.
if (!process.env.FIRESTORE_EMULATOR_HOST || !process.env.FIREBASE_AUTH_EMULATOR_HOST) {
  throw new Error("The integration suite requires Firestore and Auth emulators.");
}
const projectId = "demo-wepick";
const admin = getAdminFirestore(initializeAdminApp({ projectId }));
const apps: FirebaseApp[] = [];
interface Client { uid: string; db: Firestore; functions: Functions }

async function client(name: string): Promise<Client> {
  const app = initializeApp({ projectId, apiKey: "emulator-only-key", authDomain: `${projectId}.firebaseapp.com` }, `${name}-${Date.now()}-${apps.length}`);
  apps.push(app);
  const auth = getAuth(app);
  connectAuthEmulator(auth, "http://127.0.0.1:9099", { disableWarnings: true });
  const db = getFirestore(app);
  connectFirestoreEmulator(db, "127.0.0.1", 8080);
  const functions = getFunctions(app, "us-central1");
  connectFunctionsEmulator(functions, "127.0.0.1", 5001);
  const result = await signInAnonymously(auth);
  const user = { uid: result.user.uid, db, functions };
  await invoke(user, "ensureUser", { name });
  return user;
}
async function invoke<T = Record<string, unknown>>(user: Client, name: string, data: Record<string, unknown> = {}): Promise<T> {
  return (await httpsCallable<Record<string, unknown>, T>(user.functions, name)(data)).data;
}
async function pair() {
  const [a, b] = await Promise.all([client("Alex"), client("Sam")]);
  const { roomId } = await invoke<{ roomId: string }>(a, "createInvite");
  const code = (await getDoc(doc(a.db, "couple_rooms", roomId))).get("inviteCode") as string;
  await invoke(b, "joinRoom", { code });
  return { a, b, roomId };
}
async function start(a: Client, roomId: string) {
  const { sessionId } = await invoke<{ sessionId: string }>(a, "createSession", { roomId, category: "FOOD", budgetFilter: "HIGH", moodTag: "CHILL" });
  const itemIds = (await getDoc(doc(a.db, "sessions", sessionId))).get("itemIds") as string[];
  return { sessionId, itemIds };
}
/** Matches Android's transaction; Firestore rules validate the same invariants independently. */
async function vote(user: Client, sessionId: string, itemId: string, value: "LIKE" | "PASS", beforeFirstCommit?: () => Promise<void>) {
  let firstRead = true;
  const transact = () => runTransaction(user.db, async (tx) => {
    const sessionRef = doc(user.db, "sessions", sessionId);
    const session = await tx.get(sessionRef);
    const room = await tx.get(doc(user.db, "couple_rooms", session.get("roomId") as string));
    const swipeRef = doc(user.db, "sessions", sessionId, "swipes", itemId);
    const swipe = await tx.get(swipeRef);
    if (session.get("status") !== "ACTIVE") return;
    const own = room.get("user1Id") === user.uid ? "user1Vote" : "user2Vote";
    const other = own === "user1Vote" ? "user2Vote" : "user1Vote";
    if (swipe.get(own) !== null) return;
    if (firstRead) {
      firstRead = false;
      await beforeFirstCommit?.();
    }
    tx.update(swipeRef, { [own]: value });
    if (value === "LIKE" && swipe.get(other) === "LIKE") {
      tx.update(sessionRef, { status: "MATCHED", matchedItemId: itemId, matchSource: "MUTUAL", matchRevision: Number(session.get("matchRevision")) + 1 });
    }
  });
  for (let attempt = 0; ; attempt++) {
    try {
      await transact();
      return;
    } catch (error) {
      if ((error as { code?: string }).code !== "permission-denied" || value !== "LIKE" || attempt >= 2) throw error;
      // Rules may observe a competing first LIKE before the stale-read precondition is checked.
      // Retry only the proven legal second-LIKE race, never a general authorization failure.
      const session = await getDocFromServer(doc(user.db, "sessions", sessionId));
      const room = await getDocFromServer(doc(user.db, "couple_rooms", session.get("roomId") as string));
      const swipe = await getDocFromServer(doc(user.db, "sessions", sessionId, "swipes", itemId));
      const own = room.get("user1Id") === user.uid ? "user1Vote" : "user2Vote";
      const other = own === "user1Vote" ? "user2Vote" : "user1Vote";
      const canRetry = [room.get("user1Id"), room.get("user2Id")].includes(user.uid)
        && room.get("activeSessionId") === sessionId && session.get("status") === "ACTIVE"
        && swipe.get("vetoedBy") === null && swipe.get(own) === null && swipe.get(other) === "LIKE";
      if (!canRetry) throw error;
    }
  }
}
function nextMatch(user: Client, sessionId: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const timeout = setTimeout(() => { unsubscribe(); reject(new Error("Match listener timed out")); }, 15000);
    const unsubscribe = onSnapshot(doc(user.db, "sessions", sessionId), (snapshot) => {
      if (snapshot.get("status") === "MATCHED") {
        clearTimeout(timeout);
        unsubscribe();
        resolve(snapshot.get("matchedItemId") as string);
      }
    }, (error) => { clearTimeout(timeout); reject(error); });
  });
}

after(async () => {
  await Promise.all(apps.map((app) => deleteApp(app)));
  await admin.terminate();
});

test("invite guessing is bounded by an atomic per-account quota", { timeout: 90000 }, async () => {
  const user = await client("Invite attempts");
  // Zero is excluded from generated invite codes, so this well-formed code is never allocated.
  for (let attempt = 0; attempt < 8; attempt++) {
    await assert.rejects(invoke(user, "joinRoom", { code: "000000" }), { code: "functions/not-found" });
  }
  await assert.rejects(invoke(user, "joinRoom", { code: "000000" }), { code: "functions/resource-exhausted" });
});

test("a person sharing an unused invite can instead join their partner without leaving an orphan room", { timeout: 90000 }, async () => {
  const [a, b] = await Promise.all([client("Host A"), client("Host B")]);
  const first = await invoke<{ roomId: string }>(a, "createInvite");
  const abandoned = await invoke<{ roomId: string }>(b, "createInvite");
  const code = (await getDoc(doc(a.db, "couple_rooms", first.roomId))).get("inviteCode") as string;
  const abandonedCode = (await getDoc(doc(b.db, "couple_rooms", abandoned.roomId))).get("inviteCode") as string;
  await invoke(b, "joinRoom", { code });
  assert.equal((await getDoc(doc(b.db, "users", b.uid))).get("coupleRoomId"), first.roomId);
  assert.equal((await admin.doc(`couple_rooms/${abandoned.roomId}`).get()).exists, false);
  assert.equal((await admin.doc(`invite_codes/${abandonedCode}`).get()).get("consumed"), true);
});

test("pairing is atomic, unique, idempotent, and cannot be hijacked by a second joiner", { timeout: 90000 }, async () => {
  const [a, b, c] = await Promise.all([client("Host"), client("Partner B"), client("Partner C")]);
  const first = await invoke<{ roomId: string }>(a, "createInvite");
  const again = await invoke<{ roomId: string }>(a, "createInvite");
  assert.equal(first.roomId, again.roomId);
  const code = (await getDoc(doc(a.db, "couple_rooms", first.roomId))).get("inviteCode") as string;
  assert.match(code, /^[A-Z0-9]{6}$/);
  const joins = await Promise.allSettled([invoke(b, "joinRoom", { code }), invoke(c, "joinRoom", { code })]);
  assert.equal(joins.filter((result) => result.status === "fulfilled").length, 1);
  const room = await getDoc(doc(a.db, "couple_rooms", first.roomId));
  const winner = room.get("user2Id") === b.uid ? b : c;
  const loser = winner === b ? c : b;
  assert.equal((await getDoc(doc(a.db, "users", a.uid))).get("partnerId"), winner.uid);
  assert.equal((await getDoc(doc(winner.db, "users", winner.uid))).get("partnerId"), a.uid);
  assert.equal((await invoke<{ roomId: string }>(winner, "joinRoom", { code })).roomId, first.roomId);
  await assertFails(getDoc(doc(loser.db, "couple_rooms", first.roomId)));
  await assertFails(getDoc(doc(a.db, "invite_codes", code)));
  await assertFails(getDocs(collection(a.db, "couple_rooms")));
});

test("simultaneous right swipes publish one match to both listeners; racing vetoes spend exactly one token", { timeout: 90000 }, async () => {
  const { a, b, roomId } = await pair();
  const { sessionId, itemIds } = await start(a, roomId);
  const aMatch = nextMatch(a, sessionId);
  const bMatch = nextMatch(b, sessionId);
  // Attach rejection handlers immediately even if a vote itself fails first.
  void aMatch.catch(() => undefined);
  void bMatch.catch(() => undefined);
  // Force both first transactions to read null votes before either can commit.
  // This deterministically exercises the stale second-LIKE security-rule race.
  let reads = 0;
  let releaseReads!: () => void;
  const bothHaveRead = new Promise<void>((resolve) => { releaseReads = resolve; });
  const firstReadBarrier = async () => { if (++reads === 2) releaseReads(); await bothHaveRead; };
  await Promise.all([vote(a, sessionId, itemIds[0], "LIKE", firstReadBarrier), vote(b, sessionId, itemIds[0], "LIKE", firstReadBarrier)]);
  assert.deepEqual(await Promise.all([aMatch, bMatch]), [itemIds[0], itemIds[0]]);
  assert.equal((await getDoc(doc(a.db, "sessions", sessionId))).get("matchRevision"), 1);
  await Promise.all([invoke(a, "vetoMatch", { sessionId, expectedRevision: 1 }), invoke(b, "vetoMatch", { sessionId, expectedRevision: 1 })]);
  const session = await getDoc(doc(a.db, "sessions", sessionId));
  assert.equal(session.get("status"), "ACTIVE");
  assert.equal(session.get("matchRevision"), 2);
  const tokenSum = Number((await getDoc(doc(a.db, "users", a.uid))).get("vetoTokensRemaining")) + Number((await getDoc(doc(a.db, "users", b.uid))).get("vetoTokensRemaining"));
  assert.equal(tokenSum, 3);
  await invoke(a, "vetoMatch", { sessionId, expectedRevision: 1 });
  assert.equal(Number((await getDoc(doc(a.db, "users", a.uid))).get("vetoTokensRemaining")) + Number((await getDoc(doc(a.db, "users", b.uid))).get("vetoTokensRemaining")), 3);
});

test("rules reject partner votes, vote rewrites, forged matches, profile edits and outsider reads", { timeout: 90000 }, async () => {
  const { a, b, roomId } = await pair();
  const outsider = await client("Outsider");
  const { sessionId, itemIds } = await start(a, roomId);
  const swipeA = doc(a.db, "sessions", sessionId, "swipes", itemIds[0]);
  await assertFails(updateDoc(swipeA, { user2Vote: "LIKE" }));
  await assertFails(updateDoc(doc(a.db, "users", a.uid), { vetoTokensRemaining: 99 }));
  await assertFails(setDoc(doc(a.db, "sessions", sessionId, "swipes", "invented-card"), { itemId: "invented-card", user1Vote: "LIKE", user2Vote: null, vetoedBy: null }));
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { status: "MATCHED", matchedItemId: itemIds[0], matchSource: "MUTUAL", matchRevision: 1 }));
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { itemIds: [itemIds[0]] }));
  await assertFails(getDoc(doc(outsider.db, "sessions", sessionId)));
  await assert.rejects(invoke(outsider, "spinTieBreaker", { sessionId }), { code: "functions/permission-denied" });
  await vote(a, sessionId, itemIds[0], "LIKE");
  await assertFails(updateDoc(swipeA, { user1Vote: "PASS" }));
  // A bare second LIKE is forbidden: the match must be part of the transaction.
  await assertFails(updateDoc(doc(b.db, "sessions", sessionId, "swipes", itemIds[0]), { user2Vote: "LIKE" }));
  await vote(b, sessionId, itemIds[0], "LIKE");
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId, "swipes", itemIds[1]), { user1Vote: "PASS" }));
});

test("tie breaker waits for the slower partner, chooses from the union once, and excludes vetoes", { timeout: 90000 }, async () => {
  const { a, b, roomId } = await pair();
  const { sessionId, itemIds } = await start(a, roomId);
  assert.ok(itemIds.length >= 3);
  for (let index = 0; index < itemIds.length; index++) await vote(a, sessionId, itemIds[index], index === 0 ? "LIKE" : "PASS");
  await assert.rejects(invoke(a, "spinTieBreaker", { sessionId }), { code: "functions/failed-precondition" });
  for (let index = 0; index < itemIds.length; index++) await vote(b, sessionId, itemIds[index], index === 1 ? "LIKE" : "PASS");
  const [first, second] = await Promise.all([
    invoke<{ itemId: string }>(a, "spinTieBreaker", { sessionId }),
    invoke<{ itemId: string }>(b, "spinTieBreaker", { sessionId }),
  ]);
  assert.equal(first.itemId, second.itemId);
  assert.ok([itemIds[0], itemIds[1]].includes(first.itemId));
  await invoke(a, "vetoMatch", { sessionId, expectedRevision: 1 });
  const remaining = await invoke<{ itemId: string }>(b, "spinTieBreaker", { sessionId });
  assert.notEqual(remaining.itemId, first.itemId);
  assert.ok([itemIds[0], itemIds[1]].includes(remaining.itemId));
  assert.equal((await getDoc(doc(a.db, "sessions", sessionId))).get("matchRevision"), 3);
});

test("empty unions return no result and can start a new round; stale sessions cannot mutate", { timeout: 90000 }, async () => {
  const { a, b, roomId } = await pair();
  const first = await start(a, roomId);
  for (const itemId of first.itemIds) await Promise.all([vote(a, first.sessionId, itemId, "PASS"), vote(b, first.sessionId, itemId, "PASS")]);
  assert.equal((await invoke<{ itemId: null }>(a, "spinTieBreaker", { sessionId: first.sessionId })).itemId, null);
  const next = await start(a, roomId);
  assert.notEqual(next.sessionId, first.sessionId);
  await assert.rejects(invoke(a, "spinTieBreaker", { sessionId: first.sessionId }), { code: "functions/failed-precondition" });
});

test("token reset uses server time and resets both displayed balances; exhausted tokens cannot veto", { timeout: 90000 }, async () => {
  const { a, b, roomId } = await pair();
  const old = Timestamp.fromMillis(Date.now() - WEEK_MS - 60000);
  await Promise.all([admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old }), admin.doc(`users/${b.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old })]);
  await invoke(a, "refreshTokens");
  assert.equal((await getDoc(doc(a.db, "users", a.uid))).get("vetoTokensRemaining"), 2);
  assert.equal((await getDoc(doc(a.db, "users", b.uid))).get("vetoTokensRemaining"), 2);
  const { sessionId, itemIds } = await start(a, roomId);
  await vote(a, sessionId, itemIds[0], "LIKE");
  await vote(b, sessionId, itemIds[0], "LIKE");
  await admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: Timestamp.now() });
  await assert.rejects(invoke(a, "vetoMatch", { sessionId, expectedRevision: 1 }), { code: "functions/resource-exhausted" });
  assert.equal((await getDoc(doc(a.db, "sessions", sessionId))).get("status"), "MATCHED");
});
