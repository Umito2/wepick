import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { after, before, test } from "node:test";
import { assertFails } from "@firebase/rules-unit-testing";
import { initializeApp as initializeAdminApp } from "firebase-admin/app";
import { Timestamp as AdminTimestamp, getFirestore as getAdminFirestore } from "firebase-admin/firestore";
import { FirebaseApp, deleteApp, initializeApp } from "firebase/app";
import { connectAuthEmulator, inMemoryPersistence, initializeAuth, signInAnonymously } from "firebase/auth";
import {
  Timestamp, collection, connectFirestoreEmulator, deleteDoc, doc, getDocFromServer,
  getDocsFromServer, getFirestore, onSnapshot, serverTimestamp, setDoc, setLogLevel, terminate, updateDoc, writeBatch,
} from "firebase/firestore";
import {
  Client, SessionFilter, WEEK_MS, createInvite, createSession, ensureUser, joinRoom,
  refreshTokens, spinTieBreaker, vetoMatch, vote,
} from "./spark-client";

// These tests use administrator seeding to exercise hostile writes. Never run against a real project.
const firestoreHost = process.env.FIRESTORE_EMULATOR_HOST || "";
const authHost = process.env.FIREBASE_AUTH_EMULATOR_HOST || "";
if (![firestoreHost, authHost].every((host) => /^(127\.0\.0\.1|localhost):\d+$/.test(host))) {
  throw new Error("Spark tests require local Auth and Firestore emulators; no live endpoint is accepted.");
}
const projectId = "demo-wepick";
setLogLevel("silent"); // Expected rule denials are asserted below; avoid dumping SDK request diagnostics.
const admin = getAdminFirestore(initializeAdminApp({ projectId }, "spark-emulator-tests"));
const apps: FirebaseApp[] = [];
const filters = JSON.parse(readFileSync(resolve(__dirname, "../../../catalog/deck-filters.json"), "utf8")) as Record<string, { itemIds: string[] }>;
const options = { timeout: 90000 };

before(async () => {
  assert.equal(Object.keys(filters).length, 36);
  const batch = admin.batch();
  for (const [id, filter] of Object.entries(filters)) batch.set(admin.doc(`deck_filters/${id}`), filter);
  await batch.commit();
});
after(async () => {
  await Promise.all(apps.map(async (app) => { await terminate(getFirestore(app)); await deleteApp(app); }));
  await admin.terminate();
});

async function client(name: string): Promise<Client> {
  const app = initializeApp({ projectId, apiKey: "emulator-only-key", authDomain: `${projectId}.firebaseapp.com` }, `spark-${Date.now()}-${apps.length}`);
  apps.push(app);
  const auth = initializeAuth(app, { persistence: inMemoryPersistence });
  connectAuthEmulator(auth, `http://${authHost}`, { disableWarnings: true });
  const db = getFirestore(app);
  const [host, port] = firestoreHost.split(":");
  connectFirestoreEmulator(db, host, Number(port));
  const user = { uid: (await signInAnonymously(auth)).user.uid, db };
  await ensureUser(user, name);
  return user;
}
async function pair() {
  const [a, b] = await Promise.all([client("Alex"), client("Sam")]);
  const { roomId, inviteCode } = await createInvite(a);
  assert.equal(await joinRoom(b, inviteCode), roomId);
  return { a, b, roomId };
}
async function start(a: Client, roomId: string, filter?: SessionFilter) {
  const sessionId = await createSession(a, roomId, filter);
  const itemIds = (await read(a, "sessions", sessionId)).get("itemIds") as string[];
  return { sessionId, itemIds };
}
async function read(user: Client, ...parts: [string, ...string[]]) { return getDocFromServer(doc(user.db, ...parts)); }
async function settled<T>(values: Promise<T>[]): Promise<T[]> {
  const results = await Promise.allSettled(values);
  const failed = results.find((result) => result.status === "rejected");
  if (failed?.status === "rejected") throw failed.reason;
  return results.map((result) => (result as PromiseFulfilledResult<T>).value);
}
function nextMatch(user: Client, sessionId: string): Promise<string> {
  const result = new Promise<string>((resolveMatch, reject) => {
    const timer = setTimeout(() => { unsubscribe(); reject(new Error("Match listener timed out")); }, 15000);
    const unsubscribe = onSnapshot(doc(user.db, "sessions", sessionId), (snapshot) => {
      if (snapshot.get("status") === "MATCHED") { clearTimeout(timer); unsubscribe(); resolveMatch(snapshot.get("matchedItemId") as string); }
    }, (error) => { clearTimeout(timer); unsubscribe(); reject(error); });
  });
  void result.catch(() => undefined);
  return result;
}

test("own profile creation and name edits preserve identity, pairing and token privileges", options, async () => {
  const a = await client("Alex");
  const ownRef = doc(a.db, "users", a.uid);
  const before = await read(a, "users", a.uid);
  assert.equal(before.get("uid"), a.uid);
  assert.equal(before.get("vetoTokensRemaining"), 2);
  assert.ok(before.get("lastTokenResetTimestamp") instanceof Timestamp);
  await ensureUser(a, "Alex updated");
  assert.equal((await read(a, "users", a.uid)).get("name"), "Alex updated");
  await assertFails(updateDoc(ownRef, { vetoTokensRemaining: 99 }));
  await assertFails(updateDoc(ownRef, { lastTokenResetTimestamp: Timestamp.fromMillis(0) }));
  await assertFails(updateDoc(ownRef, { partnerId: "invented-partner" }));
  await assertFails(updateDoc(ownRef, { extra: true }));
  await assertFails(deleteDoc(ownRef));
  await assertFails(setDoc(doc(a.db, "users", "someone-else"), { ...before.data(), uid: "someone-else", lastTokenResetTimestamp: serverTimestamp() }));
});

test("invite reads require charged exact codes; eight recorded attempts, server-time resets and list denial", options, async () => {
  const a = await client("Code probe");
  let phase = "uncharged missing-code denial";
  try {
    await assertFails(read(a, "invite_codes", "000000"));
    for (let index = 0; index < 8; index++) {
      phase = `recorded missing-code attempt ${index + 1}`;
      await assert.rejects(joinRoom(a, "000000"), { code: "not-found" });
    }
    phase = "read own quota after eight attempts";
    assert.equal((await read(a, "join_attempts", a.uid)).get("count"), 8);
    phase = "repeat charged missing-code standalone read";
    assert.equal((await read(a, "invite_codes", "000000")).exists(), false); // Explicit repeated-code limitation.
    phase = "different uncharged code denial";
    await assertFails(read(a, "invite_codes", "000001"));
    phase = "ninth attempt quota rejection";
    await assert.rejects(joinRoom(a, "000001"), { code: "resource-exhausted" });
    phase = "forged early quota reset denial";
    await assertFails(updateDoc(doc(a.db, "join_attempts", a.uid), { count: 1, windowStart: serverTimestamp(), lastCode: "000001" }));
    phase = "forged request time denial";
    await assertFails(setDoc(doc(a.db, "request_times", a.uid), { now: Timestamp.fromMillis(Date.now() + WEEK_MS) }));
    for (const name of ["users", "couple_rooms", "sessions", "invite_codes", "join_attempts", "deck_filters", "request_times"]) {
      phase = `${name} collection listing denial`;
      await assertFails(getDocsFromServer(collection(a.db, name)));
    }
    phase = "admin-only expiry setup";
    await admin.doc(`join_attempts/${a.uid}`).update({ windowStart: AdminTimestamp.fromMillis(Date.now() - 16 * 60 * 1000) });
    phase = "recorded missing-code attempt after window expiry";
    await assert.rejects(joinRoom(a, "000001"), { code: "not-found" });
    phase = "read reset quota count";
    assert.equal((await read(a, "join_attempts", a.uid)).get("count"), 1);
  } catch (error) { throw new Error(`Quota test phase: ${phase}`, { cause: error }); }
});

test("invite reservation collisions cannot overwrite another room and retry with a new code", options, async () => {
  const [a, b] = await Promise.all([client("Invite A"), client("Invite B")]);
  const first = await createInvite(a);
  let attempts = 0;
  const second = await createInvite(b, () => attempts++ === 0 ? first.inviteCode : "ZZ" + b.uid.replace(/[^A-Z0-9]/gi, "").toUpperCase().slice(0, 4));
  assert.notEqual(second.roomId, first.roomId);
  assert.notEqual(second.inviteCode, first.inviteCode);
  assert.equal((await read(a, "invite_codes", first.inviteCode)).get("roomId"), first.roomId);
  assert.deepEqual(await createInvite(a), first);
});

test("joining can abandon an unused own invite without leaving an accessible room", options, async () => {
  const [a, b] = await Promise.all([client("Host A"), client("Host B")]);
  const target = await createInvite(a);
  const abandoned = await createInvite(b);
  await assertFails(read(b, "users", a.uid));
  await joinRoom(b, target.inviteCode);
  assert.equal((await read(b, "users", b.uid)).get("coupleRoomId"), target.roomId);
  assert.equal((await admin.doc(`couple_rooms/${abandoned.roomId}`).get()).exists, false);
  assert.equal((await admin.doc(`invite_codes/${abandoned.inviteCode}`).get()).get("consumed"), true);
  assert.equal((await read(a, "users", a.uid)).get("partnerId"), b.uid);
});

test("concurrent joiners produce one reciprocal couple and cannot hijack the established room", options, async () => {
  const [a, b, c] = await Promise.all([client("Host"), client("Joiner B"), client("Joiner C")]);
  const invite = await createInvite(a);
  const joins = await Promise.allSettled([joinRoom(b, invite.inviteCode), joinRoom(c, invite.inviteCode)]);
  assert.equal(joins.filter((result) => result.status === "fulfilled").length, 1);
  const room = await read(a, "couple_rooms", invite.roomId);
  const winner = room.get("user2Id") === b.uid ? b : c;
  const loser = winner === b ? c : b;
  assert.equal((await read(a, "users", a.uid)).get("partnerId"), winner.uid);
  assert.equal((await read(winner, "users", winner.uid)).get("partnerId"), a.uid);
  assert.equal(await joinRoom(winner, invite.inviteCode), invite.roomId);
  await assertFails(read(loser, "couple_rooms", invite.roomId));
  await assertFails(updateDoc(doc(loser.db, "couple_rooms", invite.roomId), { user2Id: loser.uid }));
  await assertFails(updateDoc(doc(winner.db, "users", a.uid), { name: "Forged host" }));
});

test("concurrent session creation reuses one complete catalogue-validated round", options, async () => {
  const { a, b, roomId } = await pair();
  const [first, second] = await settled([createSession(a, roomId), createSession(b, roomId)]);
  assert.equal(first, second);
  const session = await read(a, "sessions", first);
  assert.deepEqual(session.get("itemIds"), filters.FOOD_HIGH_CHILL.itemIds);
  const votes = await getDocsFromServer(collection(a.db, "sessions", first, "swipes"));
  assert.equal(votes.size, filters.FOOD_HIGH_CHILL.itemIds.length);
  assert.ok(votes.docs.every((snapshot) => snapshot.get("user1Vote") === null && snapshot.get("user2Vote") === null && snapshot.get("vetoedBy") === null));
  await assertFails(setDoc(doc(a.db, "deck_filters", "FOOD_HIGH_CHILL"), { itemIds: ["made-up"] }));
  await assertFails(updateDoc(doc(a.db, "sessions", first), { itemIds: ["made-up"] }));
  const forged = doc(collection(a.db, "sessions"));
  const batch = writeBatch(a.db);
  batch.set(forged, { ...session.data(), sessionId: forged.id, itemIds: ["made-up"], createdAt: serverTimestamp() });
  batch.set(doc(a.db, "sessions", forged.id, "swipes", "made-up"), { itemId: "made-up", user1Vote: null, user2Vote: null, vetoedBy: null });
  batch.update(doc(a.db, "couple_rooms", roomId), { activeSessionId: forged.id });
  await assertFails(batch.commit());
});

test("simultaneous first likes converge on one match; racing and repeated vetoes debit once", options, async () => {
  const { a, b, roomId } = await pair();
  const { sessionId, itemIds } = await start(a, roomId);
  const matches = [nextMatch(a, sessionId), nextMatch(b, sessionId)];
  let arrivals = 0;
  let release!: () => void;
  let timer!: ReturnType<typeof setTimeout>;
  const barrier = new Promise<void>((resolveBarrier, reject) => {
    release = resolveBarrier;
    timer = setTimeout(() => reject(new Error("First-vote barrier timed out")), 15000);
  });
  void barrier.catch(() => undefined);
  const firstRead = async () => { if (++arrivals === 2) { clearTimeout(timer); release(); } await barrier; };
  try { await settled([vote(a, sessionId, itemIds[0], "LIKE", firstRead), vote(b, sessionId, itemIds[0], "LIKE", firstRead)]); }
  finally { clearTimeout(timer); }
  assert.deepEqual(await Promise.all(matches), [itemIds[0], itemIds[0]]);
  assert.equal((await read(a, "sessions", sessionId)).get("matchRevision"), 1);
  await settled([vetoMatch(a, sessionId, 1), vetoMatch(b, sessionId, 1)]);
  const balances = async () => Number((await read(a, "users", a.uid)).get("vetoTokensRemaining")) + Number((await read(b, "users", b.uid)).get("vetoTokensRemaining"));
  assert.equal(await balances(), 3);
  assert.equal((await read(a, "sessions", sessionId)).get("matchRevision"), 2);
  assert.equal((await read(a, "sessions", sessionId)).get("status"), "ACTIVE");
  await vetoMatch(a, sessionId, 1);
  assert.equal(await balances(), 3);
});

test("rules reject forged votes, bare matches, unauthorized reads and token-only debits", options, async () => {
  const { a, b, roomId } = await pair();
  const outsider = await client("Outsider");
  const { sessionId, itemIds } = await start(a, roomId);
  const swipe = doc(a.db, "sessions", sessionId, "swipes", itemIds[0]);
  await assertFails(updateDoc(swipe, { user2Vote: "LIKE" }));
  await assertFails(updateDoc(doc(a.db, "users", a.uid), { vetoTokensRemaining: 1 }));
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { status: "MATCHED", matchedItemId: itemIds[0], matchSource: "MUTUAL", matchRevision: 1 }));
  await assertFails(read(outsider, "sessions", sessionId));
  await assertFails(getDocsFromServer(collection(outsider.db, "sessions", sessionId, "swipes")));
  await vote(a, sessionId, itemIds[0], "LIKE");
  await assertFails(updateDoc(swipe, { user1Vote: "PASS" }));
  await assertFails(updateDoc(doc(b.db, "sessions", sessionId, "swipes", itemIds[0]), { user2Vote: "LIKE" }));
  await vote(b, sessionId, itemIds[0], "LIKE");
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId, "swipes", itemIds[1]), { user1Vote: "PASS" }));
  await assertFails(updateDoc(swipe, { vetoedBy: a.uid }));
});

test("tie breaker guards exhaustion, validates union eligibility, and stores one result under a race", options, async () => {
  const { a, b, roomId } = await pair();
  const { sessionId, itemIds } = await start(a, roomId);
  assert.ok(itemIds.length >= 3);
  for (let index = 0; index < itemIds.length; index++) await vote(a, sessionId, itemIds[index], index === 0 ? "LIKE" : "PASS");
  await assert.rejects(spinTieBreaker(a, sessionId), { code: "failed-precondition" });
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { status: "MATCHED", matchedItemId: itemIds[0], matchSource: "TIE_BREAKER", matchRevision: 1 }));
  for (let index = 0; index < itemIds.length; index++) await vote(b, sessionId, itemIds[index], index === 1 ? "LIKE" : "PASS");
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { status: "MATCHED", matchedItemId: itemIds[2], matchSource: "TIE_BREAKER", matchRevision: 1 }));
  const [first, second] = await settled([spinTieBreaker(a, sessionId), spinTieBreaker(b, sessionId)]);
  assert.equal(first, second);
  assert.ok(first && itemIds.slice(0, 2).includes(first));
  await vetoMatch(a, sessionId, 1);
  await assertFails(updateDoc(doc(a.db, "sessions", sessionId), { status: "MATCHED", matchedItemId: first, matchSource: "TIE_BREAKER", matchRevision: 3 }));
  const next = await spinTieBreaker(b, sessionId);
  assert.ok(next && itemIds.slice(0, 2).includes(next));
  assert.notEqual(next, first);
  assert.equal((await read(a, "sessions", sessionId)).get("matchRevision"), 3);
});

test("five-card exhaustion and replacement stay within rule document-access budgets", options, async () => {
  const key = "ACTIVITIES_HIGH_ENERGETIC";
  const ids = ["budget-card-1", "budget-card-2", "budget-card-3", "budget-card-4", "budget-card-5"];
  await admin.doc(`deck_filters/${key}`).set({ itemIds: ids });
  try {
    const { a, b, roomId } = await pair();
    const filter: SessionFilter = { category: "ACTIVITIES", budgetFilter: "HIGH", moodTag: "ENERGETIC" };
    const first = await start(a, roomId, filter);
    assert.deepEqual(first.itemIds, ids);
    for (const id of ids) await settled([vote(a, first.sessionId, id, "PASS"), vote(b, first.sessionId, id, "PASS")]);
    assert.equal(await spinTieBreaker(a, first.sessionId), null);
    const second = await start(a, roomId, filter);
    assert.notEqual(second.sessionId, first.sessionId);
    assert.deepEqual(second.itemIds, ids);
    await assert.rejects(spinTieBreaker(a, first.sessionId), { code: "failed-precondition" });
    await assertFails(updateDoc(doc(a.db, "sessions", first.sessionId), { status: "MATCHED", matchedItemId: ids[0], matchSource: "TIE_BREAKER", matchRevision: 1 }));
    for (let index = 0; index < ids.length; index++) {
      await vote(a, second.sessionId, ids[index], index === 0 ? "LIKE" : "PASS");
      await vote(b, second.sessionId, ids[index], "PASS");
    }
    assert.equal(await spinTieBreaker(a, second.sessionId), ids[0]);
    await vetoMatch(b, second.sessionId, 1);
    assert.equal(await spinTieBreaker(a, second.sessionId), null);
  } finally { await admin.doc(`deck_filters/${key}`).set(filters[key]); }
});

test("weekly reset refreshes both users; forged resets fail and due veto refills then spends once", options, async () => {
  const { a, b, roomId } = await pair();
  const old = AdminTimestamp.fromMillis(Date.now() - WEEK_MS - 60000);
  await settled([admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old }), admin.doc(`users/${b.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old })]);
  await refreshTokens(a);
  for (const uid of [a.uid, b.uid]) assert.equal((await read(a, "users", uid)).get("vetoTokensRemaining"), 2);
  await assertFails(updateDoc(doc(a.db, "users", a.uid), { vetoTokensRemaining: 2, lastTokenResetTimestamp: serverTimestamp() }));
  const { sessionId, itemIds } = await start(a, roomId);
  await vote(a, sessionId, itemIds[0], "LIKE");
  await vote(b, sessionId, itemIds[0], "LIKE");
  await admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: AdminTimestamp.now() });
  await assert.rejects(vetoMatch(a, sessionId, 1), { code: "resource-exhausted" });
  assert.equal((await read(a, "sessions", sessionId)).get("status"), "MATCHED");
  await admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old });
  await vetoMatch(a, sessionId, 1);
  assert.equal((await read(a, "users", a.uid)).get("vetoTokensRemaining"), 1);
  assert.equal((await read(a, "sessions", sessionId)).get("status"), "ACTIVE");
});

test("concurrent partner refreshes converge on two fresh balances without permission failures", options, async () => {
  const { a, b } = await pair();
  const old = AdminTimestamp.fromMillis(Date.now() - WEEK_MS - 60000);
  await settled([admin.doc(`users/${a.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old }), admin.doc(`users/${b.uid}`).update({ vetoTokensRemaining: 0, lastTokenResetTimestamp: old })]);
  const outcomes = await Promise.allSettled([refreshTokens(a), refreshTokens(b)]);
  assert.deepEqual(outcomes.map((outcome) => outcome.status), ["fulfilled", "fulfilled"]);
  for (const uid of [a.uid, b.uid]) {
    const profile = await read(a, "users", uid);
    assert.equal(profile.get("vetoTokensRemaining"), 2);
    assert.ok((profile.get("lastTokenResetTimestamp") as Timestamp).toMillis() > old.toMillis());
  }
});
