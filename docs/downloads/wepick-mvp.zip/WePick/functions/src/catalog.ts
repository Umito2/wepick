import { readFileSync } from "node:fs";
import { join } from "node:path";
import { DeckItem } from "./logic";

// The Android asset and server bundle are built from this one checked-in catalogue.
export const catalog = JSON.parse(readFileSync(join(__dirname, "../catalog/deck.json"), "utf8")) as DeckItem[];
if (catalog.length !== 20 || new Set(catalog.map((item) => item.id)).size !== 20) {
  throw new Error("The WePick catalogue must contain exactly 20 uniquely identified items.");
}
