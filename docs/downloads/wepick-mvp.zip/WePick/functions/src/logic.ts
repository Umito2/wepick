export const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
export const WEEKLY_TOKENS = 2;

export type Vote = "LIKE" | "PASS" | null;
export type Category = "FOOD" | "OUTINGS" | "MOVIES" | "ACTIVITIES";
export type Budget = "LOW" | "MEDIUM" | "HIGH";
export type Mood = "CHILL" | "ENERGETIC" | "COZY";

export interface DeckItem {
  id: string;
  title: string;
  category: Category;
  priceTier: Budget;
  vibeTags: Mood[];
  description: string;
  emoji: string;
}

export interface Swipe {
  itemId: string;
  user1Vote: Vote;
  user2Vote: Vote;
  vetoedBy: string | null;
}

/** Fixed seven-day periods anchored at account creation; unused tokens never accumulate. */
export function tokenBalance(tokens: number, lastResetMs: number, nowMs: number) {
  const elapsedWeeks = Math.max(0, Math.floor((nowMs - lastResetMs) / WEEK_MS));
  return elapsedWeeks > 0
    ? { tokens: WEEKLY_TOKENS, resetMs: lastResetMs + elapsedWeeks * WEEK_MS }
    : { tokens, resetMs: lastResetMs };
}

export function filterDeck(items: DeckItem[], category: Category, budget: Budget, mood: Mood) {
  const rank: Record<Budget, number> = { LOW: 0, MEDIUM: 1, HIGH: 2 };
  return items.filter((item) => item.category === category && rank[item.priceTier] <= rank[budget] && item.vibeTags.includes(mood));
}

export function tieBreakerState(swipes: Swipe[]) {
  const eligible = swipes.filter((swipe) => swipe.vetoedBy === null);
  const completed = eligible.every((swipe) => swipe.user1Vote !== null && swipe.user2Vote !== null);
  // An item liked by both partners is included once, with no weighting bias.
  const candidates = eligible.filter((swipe) => swipe.user1Vote === "LIKE" || swipe.user2Vote === "LIKE").map((swipe) => swipe.itemId);
  return { completed, candidates };
}

export function shuffle<T>(items: readonly T[], randomIndex: (max: number) => number): T[] {
  const result = [...items];
  for (let index = result.length - 1; index > 0; index--) {
    const target = randomIndex(index + 1);
    [result[index], result[target]] = [result[target], result[index]];
  }
  return result;
}
