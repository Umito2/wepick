import { randomInt } from "node:crypto";
import { initializeApp } from "firebase-admin/app";
import { DocumentSnapshot, Timestamp, Transaction, getFirestore } from "firebase-admin/firestore";
import { CallableRequest, HttpsError, onCall } from "firebase-functions/v2/https";
import { catalog } from "./catalog";
import { Budget, Category, Mood, Swipe, filterDeck, shuffle, tieBreakerState, tokenBalance } from "./logic";

initializeApp();
const db = getFirestore();
const options = {
  region: "us-central1",
  enforceAppCheck: process.env.FUNCTIONS_EMULATOR !== "true",
  maxInstances: 20,
  timeoutSeconds: 30,
  memory: "256MiB" as const,
};

interface User {
  uid: string;
  name: string;
  partnerId: string | null;
  coupleRoomId: string | null;
  vetoTokensRemaining: number;
  lastTokenResetTimestamp: Timestamp;
}
interface Room {
  roomId: string;
  inviteCode: string;
  user1Id: string;
  user2Id: string | null;
  activeSessionId: string | null;
  createdAt: Timestamp;
}
interface Session {
  sessionId: string;
  roomId: string;
  category: Category;
  budgetFilter: Budget;
  moodTag: Mood;
  status: "ACTIVE" | "MATCHED";
  matchedItemId: string | null;
  itemIds: string[];
  matchSource: "MUTUAL" | "TIE_BREAKER" | null;
  matchRevision: number;
}
type Payload = Record<string, unknown>;

function authenticated(request: CallableRequest<unknown>): string {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in before continuing.");
  return request.auth.uid;
}
function payload(value: unknown): Payload {
  if (value === undefined || value === null) return {};
  if (typeof value !== "object" || Array.isArray(value)) throw new HttpsError("invalid-argument", "Expected an object.");
  return value as Payload;
}
function identifier(value: unknown, label: string): string {
  if (typeof value !== "string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(value)) {
    throw new HttpsError("invalid-argument", `Invalid ${label}.`);
  }
  return value;
}
function choice<T extends string>(value: unknown, choices: readonly T[], label: string): T {
  if (typeof value !== "string" || !choices.includes(value as T)) throw new HttpsError("invalid-argument", `Invalid ${label}.`);
  return value as T;
}
function requireData<T>(snapshot: DocumentSnapshot, description: string): T {
  if (!snapshot.exists) throw new HttpsError("not-found", `${description} no longer exists.`);
  return snapshot.data() as T;
}
function requireMember(room: Room, uid: string) {
  if (uid !== room.user1Id && uid !== room.user2Id) throw new HttpsError("permission-denied", "This room belongs to another couple.");
}
function requireActiveRoom(room: Room, session: Session) {
  if (room.activeSessionId !== session.sessionId) throw new HttpsError("failed-precondition", "Your partner started a new round. Reopen the current round.");
}
function balance(user: User, now: Timestamp) {
  return tokenBalance(user.vetoTokensRemaining, user.lastTokenResetTimestamp.toMillis(), now.toMillis());
}
function resetIfDue(tx: Transaction, snapshot: DocumentSnapshot, now: Timestamp) {
  const user = requireData<User>(snapshot, "Profile");
  const result = balance(user, now);
  if (result.resetMs !== user.lastTokenResetTimestamp.toMillis()) {
    tx.update(snapshot.ref, {
      vetoTokensRemaining: result.tokens,
      lastTokenResetTimestamp: Timestamp.fromMillis(result.resetMs),
    });
  }
}

/** Profile creation and weekly resets use only the trusted server clock. */
export const ensureUser = onCall(options, async (request) => {
  const uid = authenticated(request);
  const input = payload(request.data);
  const submittedName = input.name;
  if (submittedName !== undefined && (typeof submittedName !== "string" || submittedName.trim().length < 1 || submittedName.trim().length > 40)) {
    throw new HttpsError("invalid-argument", "Your name must contain 1–40 characters.");
  }
  const name = typeof submittedName === "string" ? submittedName.trim() : undefined;
  const ref = db.doc(`users/${uid}`);
  await db.runTransaction(async (tx) => {
    const snapshot = await tx.get(ref);
    const now = Timestamp.now();
    if (!snapshot.exists) {
      const authName = typeof request.auth?.token.name === "string" ? request.auth.token.name.trim().slice(0, 40) : "";
      tx.create(ref, { uid, name: name ?? (authName || "Partner"), partnerId: null, coupleRoomId: null, vetoTokensRemaining: 2, lastTokenResetTimestamp: now });
    } else {
      resetIfDue(tx, snapshot, now);
      if (name !== undefined) tx.update(ref, { name });
    }
  });
  return { uid };
});

class InviteCollision extends Error {}
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
function newCode() {
  return Array.from({ length: 6 }, () => CODE_ALPHABET[randomInt(CODE_ALPHABET.length)]).join("");
}

/** The private invite document's ID is a uniqueness constraint; clients cannot enumerate codes. */
export const createInvite = onCall(options, async (request) => {
  const uid = authenticated(request);
  for (let attempt = 0; attempt < 8; attempt++) {
    const code = newCode();
    const roomRef = db.collection("couple_rooms").doc();
    const inviteRef = db.doc(`invite_codes/${code}`);
    try {
      const roomId = await db.runTransaction(async (tx) => {
        const userRef = db.doc(`users/${uid}`);
        const user = requireData<User>(await tx.get(userRef), "Profile");
        if (user.coupleRoomId) {
          const room = requireData<Room>(await tx.get(db.doc(`couple_rooms/${user.coupleRoomId}`)), "Room");
          requireMember(room, uid);
          return room.roomId;
        }
        const invite = await tx.get(inviteRef);
        if (invite.exists) throw new InviteCollision();
        const now = Timestamp.now();
        tx.create(roomRef, { roomId: roomRef.id, inviteCode: code, user1Id: uid, user2Id: null, activeSessionId: null, createdAt: now });
        tx.create(inviteRef, { roomId: roomRef.id, consumed: false, createdAt: now });
        tx.update(userRef, { coupleRoomId: roomRef.id });
        return roomRef.id;
      });
      return { roomId };
    } catch (error) {
      if (!(error instanceof InviteCollision)) throw error;
    }
  }
  throw new HttpsError("resource-exhausted", "Could not allocate an invite code. Please try again.");
});

/** App Check plus an atomic per-account quota makes guessing a private six-character code costly. */
async function consumeJoinAttempt(uid: string) {
  const ref = db.doc(`join_attempts/${uid}`);
  await db.runTransaction(async (tx) => {
    const snapshot = await tx.get(ref);
    const data = snapshot.data();
    const now = Timestamp.now();
    const elapsed = data?.windowStart instanceof Timestamp ? now.toMillis() - data.windowStart.toMillis() : Infinity;
    const count = elapsed >= 15 * 60 * 1000 ? 0 : Number(data?.count ?? 0);
    if (count >= 8) throw new HttpsError("resource-exhausted", "Too many invite attempts. Try again in 15 minutes.");
    tx.set(ref, { count: count + 1, windowStart: count === 0 ? now : data!.windowStart });
  });
}

export const joinRoom = onCall(options, async (request) => {
  const uid = authenticated(request);
  const rawCode = payload(request.data).code;
  if (typeof rawCode !== "string" || !/^[a-zA-Z0-9]{6}$/.test(rawCode.trim())) throw new HttpsError("invalid-argument", "Enter a six-character invite code.");
  const code = rawCode.trim().toUpperCase();
  await consumeJoinAttempt(uid);
  const roomId = await db.runTransaction(async (tx) => {
    const userRef = db.doc(`users/${uid}`);
    const inviteRef = db.doc(`invite_codes/${code}`);
    const [userSnapshot, inviteSnapshot] = await tx.getAll(userRef, inviteRef);
    const user = requireData<User>(userSnapshot, "Profile");
    if (!inviteSnapshot.exists) throw new HttpsError("not-found", "This invite is invalid or unavailable.");
    const targetRoomId = inviteSnapshot.get("roomId") as string;
    const roomRef = db.doc(`couple_rooms/${targetRoomId}`);
    const room = requireData<Room>(await tx.get(roomRef), "Room");
    if (room.user1Id === uid) throw new HttpsError("failed-precondition", "Share this code with your partner; it belongs to you.");
    if (room.user2Id === uid && user.coupleRoomId === room.roomId) return room.roomId;
    if (room.user2Id !== null || inviteSnapshot.get("consumed") === true) throw new HttpsError("failed-precondition", "This invite is already in use.");

    // A person may switch from sharing their own unused code to joining their partner's code.
    let abandonedRoom: Room | null = null;
    if (user.coupleRoomId) {
      abandonedRoom = requireData<Room>(await tx.get(db.doc(`couple_rooms/${user.coupleRoomId}`)), "Existing room");
      if (abandonedRoom.user1Id !== uid || abandonedRoom.user2Id !== null || abandonedRoom.activeSessionId !== null) {
        throw new HttpsError("failed-precondition", "You are already paired with a partner.");
      }
    }
    const hostRef = db.doc(`users/${room.user1Id}`);
    const host = requireData<User>(await tx.get(hostRef), "Partner profile");
    if (host.coupleRoomId !== room.roomId || host.partnerId !== null || user.partnerId !== null) throw new HttpsError("failed-precondition", "This invite is no longer available.");

    // All transaction reads above precede every write; concurrent joiners contend on this room.
    tx.update(roomRef, { user2Id: uid });
    tx.update(userRef, { partnerId: room.user1Id, coupleRoomId: room.roomId });
    tx.update(hostRef, { partnerId: uid });
    tx.update(inviteRef, { consumed: true });
    if (abandonedRoom) {
      tx.delete(db.doc(`couple_rooms/${abandonedRoom.roomId}`));
      tx.update(db.doc(`invite_codes/${abandonedRoom.inviteCode}`), { consumed: true });
    }
    return room.roomId;
  });
  return { roomId };
});

export const refreshTokens = onCall(options, async (request) => {
  const uid = authenticated(request);
  await db.runTransaction(async (tx) => {
    const ownSnapshot = await tx.get(db.doc(`users/${uid}`));
    const own = requireData<User>(ownSnapshot, "Profile");
    let partnerSnapshot: DocumentSnapshot | undefined;
    if (own.coupleRoomId) {
      const room = requireData<Room>(await tx.get(db.doc(`couple_rooms/${own.coupleRoomId}`)), "Room");
      requireMember(room, uid);
      const partnerId = uid === room.user1Id ? room.user2Id : room.user1Id;
      if (partnerId) partnerSnapshot = await tx.get(db.doc(`users/${partnerId}`));
    }
    const now = Timestamp.now();
    resetIfDue(tx, ownSnapshot, now);
    if (partnerSnapshot) resetIfDue(tx, partnerSnapshot, now);
  });
  return {};
});

async function readSwipes(tx: Transaction, session: Session): Promise<Swipe[]> {
  if (session.itemIds.length === 0) throw new HttpsError("failed-precondition", "This round has no cards.");
  const snapshots = await tx.getAll(...session.itemIds.map((id) => db.doc(`sessions/${session.sessionId}/swipes/${id}`)));
  return snapshots.map((snapshot) => requireData<Swipe>(snapshot, "Swipe"));
}

export const createSession = onCall(options, async (request) => {
  const uid = authenticated(request);
  const input = payload(request.data);
  const roomId = identifier(input.roomId, "room ID");
  const category = choice(input.category, ["FOOD", "OUTINGS", "MOVIES", "ACTIVITIES"] as const, "category");
  const budgetFilter = choice(input.budgetFilter, ["LOW", "MEDIUM", "HIGH"] as const, "budget");
  const moodTag = choice(input.moodTag, ["CHILL", "ENERGETIC", "COZY"] as const, "mood");
  const itemIds = shuffle(filterDeck(catalog, category, budgetFilter, moodTag).map((item) => item.id), randomInt);
  if (itemIds.length === 0) throw new HttpsError("failed-precondition", "There are no items for these filters.");
  const sessionRef = db.collection("sessions").doc();
  const sessionId = await db.runTransaction(async (tx) => {
    const roomRef = db.doc(`couple_rooms/${roomId}`);
    const room = requireData<Room>(await tx.get(roomRef), "Room");
    requireMember(room, uid);
    if (!room.user2Id) throw new HttpsError("failed-precondition", "Wait for your partner to join first.");
    if (room.activeSessionId) {
      const active = requireData<Session>(await tx.get(db.doc(`sessions/${room.activeSessionId}`)), "Current round");
      if (active.status === "ACTIVE") {
        const progress = tieBreakerState(await readSwipes(tx, active));
        // Preserve the shared round. A completely rejected/vetoed deck is allowed to restart.
        if (!progress.completed || progress.candidates.length > 0) return active.sessionId;
      }
    }
    const session: Session = { sessionId: sessionRef.id, roomId, category, budgetFilter, moodTag, status: "ACTIVE", matchedItemId: null, itemIds, matchSource: null, matchRevision: 0 };
    tx.create(sessionRef, { ...session, createdAt: Timestamp.now() });
    for (const itemId of itemIds) {
      tx.create(sessionRef.collection("swipes").doc(itemId), { itemId, user1Vote: null, user2Vote: null, vetoedBy: null });
    }
    tx.update(roomRef, { activeSessionId: sessionRef.id });
    return sessionRef.id;
  });
  return { sessionId };
});

export const vetoMatch = onCall(options, async (request) => {
  const uid = authenticated(request);
  const input = payload(request.data);
  const sessionId = identifier(input.sessionId, "session ID");
  const expectedRevision = input.expectedRevision;
  if (typeof expectedRevision !== "number" || !Number.isSafeInteger(expectedRevision) || expectedRevision < 1) throw new HttpsError("invalid-argument", "Invalid match revision.");
  await db.runTransaction(async (tx) => {
    const sessionRef = db.doc(`sessions/${sessionId}`);
    const session = requireData<Session>(await tx.get(sessionRef), "Round");
    const room = requireData<Room>(await tx.get(db.doc(`couple_rooms/${session.roomId}`)), "Room");
    requireMember(room, uid);
    requireActiveRoom(room, session);
    // Retried requests and two simultaneous vetoes do not debit twice or veto a later match.
    if (session.matchRevision !== expectedRevision || session.status !== "MATCHED" || !session.matchedItemId) return;
    const userRef = db.doc(`users/${uid}`);
    const swipeRef = sessionRef.collection("swipes").doc(session.matchedItemId);
    const [userSnapshot, swipeSnapshot] = await tx.getAll(userRef, swipeRef);
    const user = requireData<User>(userSnapshot, "Profile");
    const swipe = requireData<Swipe>(swipeSnapshot, "Matched card");
    if (swipe.vetoedBy !== null) throw new HttpsError("failed-precondition", "This card was already vetoed.");
    const current = balance(user, Timestamp.now());
    if (current.tokens <= 0) throw new HttpsError("resource-exhausted", "You have used both veto tokens for this week.");
    tx.update(userRef, { vetoTokensRemaining: current.tokens - 1, lastTokenResetTimestamp: Timestamp.fromMillis(current.resetMs) });
    tx.update(swipeRef, { vetoedBy: uid });
    tx.update(sessionRef, { status: "ACTIVE", matchedItemId: null, matchSource: null, matchRevision: session.matchRevision + 1 });
  });
  return {};
});

export const spinTieBreaker = onCall(options, async (request) => {
  const uid = authenticated(request);
  const sessionId = identifier(payload(request.data).sessionId, "session ID");
  const itemId = await db.runTransaction(async (tx) => {
    const sessionRef = db.doc(`sessions/${sessionId}`);
    const session = requireData<Session>(await tx.get(sessionRef), "Round");
    const room = requireData<Room>(await tx.get(db.doc(`couple_rooms/${session.roomId}`)), "Room");
    requireMember(room, uid);
    requireActiveRoom(room, session);
    if (session.status === "MATCHED") return session.matchedItemId;
    const swipes = await readSwipes(tx, session);
    const progress = tieBreakerState(swipes);
    if (!progress.completed) throw new HttpsError("failed-precondition", "Both partners must finish the deck before spinning.");
    if (progress.candidates.length === 0) return null;
    // A secure server RNG chooses once. Transaction conflicts retry; the committed result is shared.
    const chosen = progress.candidates[randomInt(progress.candidates.length)];
    tx.update(sessionRef, { status: "MATCHED", matchedItemId: chosen, matchSource: "TIE_BREAKER", matchRevision: session.matchRevision + 1 });
    return chosen;
  });
  return { itemId };
});
