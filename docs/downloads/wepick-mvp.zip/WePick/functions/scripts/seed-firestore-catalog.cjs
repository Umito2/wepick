﻿"use strict";
// Administrative bootstrap only. This is never bundled into the Android app.
// Uses ADC, or an explicitly selected local demo emulator. Never starts billing.
const fs = require("node:fs");
const path = require("node:path");
const { execFileSync } = require("node:child_process");
const { initializeApp, applicationDefault, deleteApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const args = process.argv.slice(2);
const projectIndex = args.indexOf("--project");
const projectId = projectIndex >= 0 ? args[projectIndex + 1] : undefined;
const emulator = args.includes("--emulator");
if (!projectId || !/^[a-z][a-z0-9-]{4,28}[a-z0-9]$/.test(projectId) || !args.includes("--confirm-write")) {
  console.error("Usage: node scripts/seed-firestore-catalog.cjs --project PROJECT_ID --confirm-write [--emulator]");
  process.exit(2);
}
if (emulator !== Boolean(process.env.FIRESTORE_EMULATOR_HOST) || (emulator && !projectId.startsWith("demo-")) || (!emulator && projectId.startsWith("demo-"))) {
  console.error("Project/emulator mismatch; no writes performed."); process.exit(2);
}
const filters = JSON.parse(fs.readFileSync(path.resolve(__dirname, "../../catalog/deck-filters.json"), "utf8"));
execFileSync(process.execPath, [path.join(__dirname, "generate-catalog-filters.cjs"), "--check"], { stdio: "inherit" });
if (Object.keys(filters).length !== 36 || Object.entries(filters).some(([id, value]) => !/^(FOOD|OUTINGS|MOVIES|ACTIVITIES)_(LOW|MEDIUM|HIGH)_(CHILL|ENERGETIC|COZY)$/.test(id) || !Array.isArray(value.itemIds) || value.itemIds.length < 1 || value.itemIds.length > 5)) throw new Error("Invalid generated catalogue.");
(async () => {
  const app = initializeApp({ projectId, ...(emulator ? {} : { credential: applicationDefault() }) });
  const db = getFirestore(app);
  try {
    const batch = db.batch();
    for (const [id, value] of Object.entries(filters)) batch.set(db.collection("deck_filters").doc(id), value);
    await batch.commit();
    console.log(JSON.stringify({ projectId, catalogueFiltersWritten: 36, emulator }));
  } catch { console.error("Catalogue bootstrap failed. Check project access and ADC; no credential details are printed."); process.exitCode = 1; }
  finally { await db.terminate(); await deleteApp(app); }
})();
