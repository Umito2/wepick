const fs = require("node:fs");
const path = require("node:path");
const destination = path.join(__dirname, "../lib/catalog");
fs.mkdirSync(destination, { recursive: true });
fs.copyFileSync(path.join(__dirname, "../../catalog/deck.json"), path.join(destination, "deck.json"));
