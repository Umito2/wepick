﻿"use strict";
const fs = require("node:fs");
const path = require("node:path");
const root = path.resolve(__dirname, "../..");
const catalog = JSON.parse(fs.readFileSync(path.join(root, "catalog/deck.json"), "utf8"));
const categories = ["FOOD", "OUTINGS", "MOVIES", "ACTIVITIES"];
const budgets = ["LOW", "MEDIUM", "HIGH"];
const moods = ["CHILL", "ENERGETIC", "COZY"];
if (catalog.length !== 20 || new Set(catalog.map((item) => item.id)).size !== 20) throw new Error("Expected exactly 20 unique catalogue IDs.");
const filters = {};
for (const category of categories) for (const budget of budgets) for (const mood of moods) {
  const itemIds = catalog.filter((item) => item.category === category && budgets.indexOf(item.priceTier) <= budgets.indexOf(budget) && item.vibeTags.includes(mood)).map((item) => item.id);
  if (itemIds.length < 1 || itemIds.length > 5) throw new Error(`Invalid filter size: ${category}/${budget}/${mood}`);
  filters[`${category}_${budget}_${mood}`] = { itemIds };
}
const target = path.join(root, "catalog/deck-filters.json");
const content = `${JSON.stringify(filters, null, 2)}\n`;
if (process.argv.includes("--check")) {
  if (fs.readFileSync(target, "utf8") !== content) throw new Error("Catalogue filters are stale. Run npm run catalog:generate.");
  console.log("All 36 trusted catalogue filters match the shared catalogue.");
} else {
  fs.writeFileSync(target, content);
  console.log("Generated 36 trusted catalogue filters.");
}
