const { spawn } = require("node:child_process");
const { join } = require("node:path");

// Pass only process/runtime settings needed by the disposable emulator project.
// Firebase's debug log can include child environments; unrelated account credentials stay out.
const allowed = new Set([
  "PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "COMSPEC", "TEMP", "TMP", "TMPDIR",
  "HOME", "USERPROFILE", "APPDATA", "LOCALAPPDATA", "HOMEDRIVE", "HOMEPATH",
  "JAVA_HOME", "CI", "LANG", "LC_ALL", "LC_CTYPE", "TERM", "NO_COLOR",
  "FIREBASE_EMULATORS_PATH", "NODE_EXTRA_CA_CERTS", "SSL_CERT_FILE", "SSL_CERT_DIR",
]);
const env = Object.fromEntries(Object.entries(process.env).filter(([key]) => allowed.has(key.toUpperCase())));
env.DEBUG = "";
env.FIREBASE_CLI_DISABLE_USAGE = "true";
const child = spawn(process.execPath, [
  require.resolve("firebase-tools/lib/bin/firebase.js"),
  "emulators:exec", "--config", "../firebase.json", "--project", "demo-wepick",
  "--only", "auth,firestore,functions",
  "node --test --test-concurrency=1 lib/test/emulator.test.js",
], { cwd: join(__dirname, ".."), env, stdio: "inherit" });
child.on("error", (error) => { console.error(error.message); process.exitCode = 1; });
child.on("exit", (code) => { process.exitCode = code ?? 1; });
