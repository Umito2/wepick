# WePick — The Zero-Argument Decision Engine

A native Android couples MVP: pair once, choose a mood and budget, swipe privately, and share the first mutual yes. Kotlin, Material 3 Compose, Hilt, StateFlow, Firebase Authentication, Cloud Firestore, and typed Navigation Compose routes.

## Read the implementation in the requested order

1. **Build configuration:** [`build.gradle.kts`](build.gradle.kts), [`app/build.gradle.kts`](app/build.gradle.kts), [`settings.gradle.kts`](settings.gradle.kts), and the checksum-pinned Gradle wrapper.
2. **Models and seed data:** [`domain/model`](app/src/main/java/com/wepick/app/domain/model), [`LocalDeckDataSource.kt`](app/src/main/java/com/wepick/app/data/local/LocalDeckDataSource.kt), and [`catalog/deck.json`](catalog/deck.json). The same catalogue is packaged in Android and the server to prevent divergent item IDs or filters.
3. **Repositories and transactions:** [`domain/repository`](app/src/main/java/com/wepick/app/domain/repository), [`FirebaseCoupleRepository.kt`](app/src/main/java/com/wepick/app/data/remote/FirebaseCoupleRepository.kt), [`FirebaseSwipeSessionRepository.kt`](app/src/main/java/com/wepick/app/data/remote/FirebaseSwipeSessionRepository.kt), [`functions/src/index.ts`](functions/src/index.ts), and [`firestore.rules`](firestore.rules).
4. **Swipe state:** [`SwipeViewModel.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeViewModel.kt), [`SwipeUiState.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeUiState.kt), and [`CalculateSwipeProgress.kt`](app/src/main/java/com/wepick/app/domain/usecase/CalculateSwipeProgress.kt).
5. **Complete screens:** [`PairingScreen.kt`](app/src/main/java/com/wepick/app/presentation/pairing/PairingScreen.kt), [`CategoryFilterScreen.kt`](app/src/main/java/com/wepick/app/presentation/filter/CategoryFilterScreen.kt), [`SwipeDeckScreen.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeDeckScreen.kt), and [`MatchCelebrationDialog.kt`](app/src/main/java/com/wepick/app/presentation/swipe/MatchCelebrationDialog.kt).

## Local development

Use Android Studio with Android SDK 36 and JDK 17 or 21. The Firebase emulators and the supplied CI use **JDK 21**. Use **Node 22.18+** for the backend; the deployed functions runtime is Node 22. Gradle, Kotlin, Compose and Firebase versions are pinned for repeatable builds.

From `functions/`:

```sh
npm ci
npm run build
npx firebase emulators:start --config ../firebase.json --project demo-wepick --only auth,firestore,functions
```

Keep the emulators running. From the project root:

```sh
# Linux/macOS only, after extracting the source ZIP:
chmod +x gradlew
./gradlew assembleEmulatorDebug
./gradlew installEmulatorDebug
```

On Windows use `gradlew.bat`. Choose the `emulatorDebug` variant in Android Studio. Open the app on **two different Android emulator instances** and use anonymous sign-in. Generate a code on one, then enter it on the other. Each instance must have its own Firebase Auth identity.

The Android emulator reaches the host at `10.0.2.2`. For physical devices on the same network, set `-Pwepick.emulatorHost=YOUR_HOST_IP` and bind the Firebase emulator ports to the appropriate interface. Only the emulator variant allows cleartext HTTP. Its Firebase project is always `demo-wepick`; it cannot silently use a production Firebase configuration. Google OAuth is intentionally unavailable in this variant.

An optional Windows helper, [`scripts/prepare-toolchain.ps1`](scripts/prepare-toolchain.ps1), downloads checksum-verified build tooling into ignored `.tools/` and accepts Android SDK component licenses. Android Studio's SDK manager is also sufficient. The helper does not deploy Firebase resources.

## Connect your Firebase project

1. Create a Firebase project and Cloud Firestore database. Register Android app **`com.wepick.app`**, and **`com.wepick.app.debug`** if you want a production-backend debug build. Download a `google-services.json` containing the appropriate clients to `app/google-services.json`; it is intentionally gitignored.
2. Enable **Anonymous** and **Google** authentication. Add your debug/release certificate SHA-1 and SHA-256 fingerprints. Enable Google sign-in before downloading the final config so it contains `default_web_client_id`, the **web** OAuth client ID required by Credential Manager.
3. Register **App Check / Play Integrity** for the release app. Production callable functions require App Check. For `productionDebug`, register the debug App Check token shown by Firebase in Logcat. Enable Firestore App Check enforcement in the Firebase console after validating your setup.
4. Use a Firebase plan that supports deploying second-generation Cloud Functions. In `functions/`, authenticate the Firebase CLI, then deploy to your selected project:

   ```sh
   npm ci
   npm run build
   npx firebase deploy --config ../firebase.json --project YOUR_PROJECT_ID --only functions,firestore
   ```

5. Build `productionDebug` for testing or `productionRelease` for distribution. Production builds fail with a clear message when the configuration is missing. Configure your own release signing key through Android Studio or your CI secret store; no signing credentials are committed.

Functions and Android both use `us-central1`. Change both together if deploying elsewhere. No Firebase project is provisioned or deployed by this repository's creation.

Google sign-in links an existing anonymous user to preserve their UID, pairing, votes, and tokens. A Google credential already belonging to another profile is rejected with a message instead of silently abandoning the current couple.

## Data and consistency

The requested four document paths are implemented:

| Path | Contents |
| --- | --- |
| `users/{uid}` | Name, partner/room IDs, weekly token balance, reset timestamp |
| `couple_rooms/{roomId}` | Six-character invite, two member IDs, active session, creation timestamp |
| `sessions/{sessionId}` | Category, budget, mood, ACTIVE/MATCHED state, matched item |
| `sessions/{sessionId}/swipes/{itemId}` | Each member's LIKE/PASS/null vote and optional veto owner |

Session documents additionally store immutable `itemIds`, `matchSource`, and `matchRevision`. These make deck order shared, distinguish roulette results from mutual matches, and prevent a retried veto from consuming tokens against a newer match. Firestore timestamps map to epoch milliseconds in domain models. Enum names are stored on the wire; `LOW / MEDIUM / HIGH` render as `$ / $$ / $$$`.

Two private server-only collections support pairing: `invite_codes` reserves unique codes and prevents enumeration, while `join_attempts` limits incorrect/attempted joins to eight per account per fifteen minutes. Joining updates the room and **both** profiles in one transaction. An unused invite can be abandoned when its owner joins their partner's code.

The Android swipe transaction reads the session, room and swipe before any writes. It saves only the current member's first vote. A second LIKE writes the vote and MATCHED session state atomically. Firestore rules independently enforce these invariants, including the active room pointer. Concurrent matches contend on the shared session document, so exactly one item wins that revision.

The repository also handles a reproduced simultaneous-first-LIKE race: rules can reject a stale transaction before the SDK retries its precondition. Fresh server reads must prove that the partner's concurrent LIKE caused the conflict before the app retries. This recovery is bounded to three total attempts; genuine authorization failures remain errors.

Privileged operations—pairing, starting rounds, refilling/spending tokens, and selecting roulette results—use authenticated server Firestore transactions. This is deliberate: a client must not be trusted to edit another user's profile, grant itself tokens, invent the deck, or choose a supposedly random shared result. Kotlin repositories contain the callable bridge and real-time listeners; the full server transaction bodies are included.

Both devices observe the persisted session and swipe documents through cancellable snapshot listeners. UI state is restored from votes, so rotation/process recreation cannot reset progress. Offline/failed votes remain retryable. Real-time means each connected device reacts when it receives the committed snapshot; exact simultaneous wall-clock animation cannot be guaranteed across networks.

## Product decisions

- **20 preloaded ideas:** five food delivery ideas, five cafe outings, five movie/cinema ideas, and five weekend activities. Illustrations use local emoji and gradients, so no external photo keys or image licenses are needed. These are editable suggestions, not live venue listings or availability claims.
- **Budget is a maximum:** `$$` includes `$` options. Mood is a strict match. Every category has inexpensive options for all three moods.
- **Veto allowance:** two tokens per user per rolling seven-day period, measured by server time. Refills are lazy, capped at two, and do not accumulate. A veto excludes that item for the remainder of the session and resumes the durable unvoted queue.
- **Tie-breaker:** both partners must finish all non-vetoed cards. A secure server RNG chooses once from the union of their likes. Both devices animate that stored winner. This implements the requested random fallback; it does not call an AI model.
- **Empty union:** show a fresh-round action instead of inventing a choice. Existing ACTIVE rounds are reused until they finish; either partner may start another round after a match, and the other device follows the room pointer.
- **Accessibility/theme:** light and dark Material 3 palettes, semantic labels, button alternatives to gestures, and font-aware layouts. Preview functions are included for visual review in Android Studio.

## Verification

```sh
# Android domain/ViewModel tests, lint, debug APK, and R8 release build
./gradlew testEmulatorDebugUnitTest lintEmulatorDebug assembleEmulatorDebug assembleEmulatorRelease

# Backend compilation and pure tests
cd functions
npm test

# Full auth + rules + callable integration on local emulators
npm run test:emulator

# Dependency-free core tests on Node 22.18+ / Node 24
npm run test:core
```

The emulator suite covers pairing races, listener convergence, simultaneous likes, veto retries/races, slower-partner exhaustion, shared roulette results, empty unions, server-time token resets, and denied attempts to forge partner votes, matches, profiles or membership. Android tests cover restored queues, missing snapshots, double taps, failed writes and superseded sessions. [CI](.github/workflows/verify.yml) runs Android build/lint/unit tests and Firebase emulator tests separately.

Validated locally on 2026-10-31:

| Check | Result |
| --- | --- |
| Android JVM tests | 23 passed, no failures or skipped tests |
| Android lint | Passed with zero errors and 20 advisory warnings; see the generated lint report for dependency-update, OAuth-resource, and backup-metadata notices |
| Emulator debug APK | Built and signed with a local debug key |
| Emulator release APK | R8/resource shrinking and unsigned release packaging passed |
| Backend strict TypeScript compilation | Passed |
| Backend core tests | 4 passed |
| Firebase emulator integration tests | 8 passed, including a deterministic simultaneous-first-LIKE regression |

The release APK uses the emulator backend and is unsigned. Production Firebase/OAuth/App Check configuration, a production signing key, and real-device smoke testing remain deployment-specific steps.

Release verification should also exercise two real devices, Google credential linking, App Check/Play Integrity, accessibility/font scaling, dark mode, connectivity loss, and process recreation against your configured Firebase project.

## References

- [Firebase Android setup and main-module dependencies](https://firebase.google.com/docs/android/setup)
- [Firestore transaction ordering, retries, and offline behavior](https://firebase.google.com/docs/firestore/manage-data/transactions)
- [Firebase Google authentication with Credential Manager](https://firebase.google.com/docs/auth/android/google-signin)
- [Type-safe Navigation Compose routes](https://developer.android.com/guide/navigation/design/type-safety)
- [Compose compiler Gradle plugin](https://developer.android.com/jetpack/androidx/releases/compose-kotlin)
