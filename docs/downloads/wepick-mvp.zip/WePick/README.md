# WePick — The Zero-Argument Decision Engine

A native Android couples MVP: pair once, choose a mood and budget, swipe privately, and share the first mutual yes. Kotlin, Material 3 Compose, Hilt, StateFlow, Firebase Authentication, Cloud Firestore, and typed Navigation Compose routes.

The **1.1.1 source targets Firebase's no-cost Spark plan**. Android writes through Firestore transactions validated by Security Rules; it does not call Cloud Functions. No billing account, payment card, or Blaze upgrade is needed. The previously published **1.0.2 emulator preview** is a separate developer archive and keeps its original local-backend requirements.

## Read the implementation in the requested order

1. **Build configuration:** [`build.gradle.kts`](build.gradle.kts), [`app/build.gradle.kts`](app/build.gradle.kts), [`settings.gradle.kts`](settings.gradle.kts), and the checksum-pinned Gradle wrapper.
2. **Models and seed data:** [`domain/model`](app/src/main/java/com/wepick/app/domain/model), [`LocalDeckDataSource.kt`](app/src/main/java/com/wepick/app/data/local/LocalDeckDataSource.kt), and [`catalog/deck.json`](catalog/deck.json). Android and the rules-validated catalogue configuration must use the same item IDs and filters.
3. **Repositories and transactions:** [`domain/repository`](app/src/main/java/com/wepick/app/domain/repository), [`FirebaseCoupleRepository.kt`](app/src/main/java/com/wepick/app/data/remote/FirebaseCoupleRepository.kt), [`FirebaseSwipeSessionRepository.kt`](app/src/main/java/com/wepick/app/data/remote/FirebaseSwipeSessionRepository.kt), and [`firestore.rules`](firestore.rules). [`SPARK-CONTRACT.md`](SPARK-CONTRACT.md) defines the authoritative Firestore write contract.
4. **Swipe state:** [`SwipeViewModel.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeViewModel.kt), [`SwipeUiState.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeUiState.kt), and [`CalculateSwipeProgress.kt`](app/src/main/java/com/wepick/app/domain/usecase/CalculateSwipeProgress.kt).
5. **Complete screens:** [`PairingScreen.kt`](app/src/main/java/com/wepick/app/presentation/pairing/PairingScreen.kt), [`CategoryFilterScreen.kt`](app/src/main/java/com/wepick/app/presentation/filter/CategoryFilterScreen.kt), [`SwipeDeckScreen.kt`](app/src/main/java/com/wepick/app/presentation/swipe/SwipeDeckScreen.kt), and [`MatchCelebrationDialog.kt`](app/src/main/java/com/wepick/app/presentation/swipe/MatchCelebrationDialog.kt).

## Local development

Use Android Studio with Android SDK 36 and JDK 17 or 21. The Firebase emulators and the supplied CI use **JDK 21**. Use **Node 22.18+** for Firebase tooling and tests. There is no deployed Node runtime in the Spark backend. Gradle, Kotlin, Compose and Firebase versions are pinned for repeatable builds.

From `functions/`:

```sh
npm ci
npm run build
npm run catalog:generate
npx firebase emulators:start --config ../firebase.json --project demo-wepick --only auth,firestore
```

Initialize the catalogue configuration with `node functions/scripts/seed-firestore-catalog.cjs --project demo-wepick --confirm-write --emulator` from another terminal at the project root, with `FIRESTORE_EMULATOR_HOST=127.0.0.1:8080` in that terminal's environment. Keep the Auth and Firestore emulators running. Then build Android from the project root:

```sh
# Linux/macOS only, after extracting the source ZIP:
chmod +x gradlew
./gradlew assembleEmulatorDebug
./gradlew installEmulatorDebug
```

On Windows use `gradlew.bat`. Choose the `emulatorDebug` variant in Android Studio. Open the app on **two different Android emulator instances** and use anonymous sign-in. Generate a code on one, then enter it on the other. Each instance must have its own Firebase Auth identity.

The Android emulator reaches the host at `10.0.2.2`. For physical devices on the same network, set `-Pwepick.emulatorHost=YOUR_HOST_IP` and bind the Firebase emulator ports to the appropriate interface. Only the emulator variant allows cleartext HTTP. Its Firebase project is always `demo-wepick`; it cannot silently use a production Firebase configuration. Google OAuth is intentionally unavailable in this variant.

**The older 1.0.2 preview APK needs a computer Android emulator and its original local Firebase Auth, Firestore, and Functions backend.** Installing that archive's APK on a real phone does not make its default `10.0.2.2` backend reachable. Follow its included `SETUP.txt`. A new build from this source uses the Spark backend described here; configure a reachable emulator host or build the production variant for phones.

### Connection recovery

The pairing screen stops its initial loading indicator after twelve seconds without a usable auth/profile/room state and offers a retry. Its real-time observation stays active, so a late valid snapshot can recover the screen. A healthy invite waiting for a partner continues listening normally.

One-shot Firebase operations have an eight-second deadline in the emulator build and a thirty-second deadline in production. Pairing actions also have a thirty-five-second UI fallback. Retry reconnects to the saved account and room state. These deadlines provide recovery controls; the configured Firebase backend must still be running and reachable.

**Try browser demo** remains available while connecting or signing in and opens the [public two-turn demo](https://umito2.github.io/wepick/#demo). It simulates both partners in one browser without Firebase setup. The emulator build also explains its backend requirements on the pairing screen.

An optional Windows helper, [`scripts/prepare-toolchain.ps1`](scripts/prepare-toolchain.ps1), downloads checksum-verified build tooling into ignored `.tools/` and accepts Android SDK component licenses. Android Studio's SDK manager is also sufficient. The helper does not deploy Firebase resources.

## Connect your Firebase project

1. Create a Firebase project on the **Spark plan**, without linking a Cloud Billing account, and create its default Cloud Firestore database. Register Android app **`com.wepick.app`**, and **`com.wepick.app.debug`** if you want a production-backend debug build. Download a `google-services.json` containing the appropriate clients to `app/google-services.json`; it is intentionally gitignored.
2. Enable **Anonymous** authentication using the checked-in `firebase.json`, which sets `auth.providers.anonymous` to `true`. From `functions/`, after `npm ci` and Firebase CLI login, deploy that provider configuration:

   ```sh
   npx firebase deploy --config ../firebase.json --project YOUR_PROJECT_ID --only auth
   ```

   The CLI supports deploying Authentication providers separately; see [Firebase's provider configuration guide](https://firebase.google.com/docs/auth/configure-providers-cli). **Google sign-in is optional.** To add it, enable the Google provider, register your debug/release certificate SHA-1 and SHA-256 fingerprints, and download an updated `google-services.json` containing `default_web_client_id`, the **web** OAuth client ID required by Credential Manager. The app shows the Google button only in a production build with a nonblank web client ID; Anonymous sign-in remains available without Google OAuth.
3. Register **App Check / Play Integrity** for the release app. For a private `productionDebug` test, register each phone installation's debug App Check token shown by Firebase in Logcat; keep these builds and tokens private. Public APK distribution uses a signed `productionRelease` build. For distribution outside Google Play, configure the App Check Play Integrity settings for that distribution method. Enable Firestore App Check enforcement in the Firebase console after validating your setup. See the [debug provider guidance](https://firebase.google.com/docs/app-check/android/debug-provider) and [Play Integrity configuration](https://firebase.google.com/docs/app-check/android/play-integrity-provider).
4. Generate and seed the immutable catalogue configuration from the project root. The seed tool requires Application Default Credentials authorized for your chosen project; Firebase CLI login and ADC are separate credentials. Never package administrator credentials with the app. See [`SPARK-CONTRACT.md`](SPARK-CONTRACT.md).

   ```sh
   npm --prefix functions run catalog:generate
   node functions/scripts/seed-firestore-catalog.cjs --project YOUR_PROJECT_ID --confirm-write
   ```

   Deploy the Firestore rules and indexes from `functions/`:

   ```sh
   npx firebase deploy --config ../firebase.json --project YOUR_PROJECT_ID --only firestore
   ```

5. Build `productionDebug` for testing or `productionRelease` for distribution. Production builds fail with a clear message when the configuration is missing. Configure your own release signing key through Android Studio or your CI secret store; no signing credentials are committed.

The current runtime needs only Firebase Authentication and Cloud Firestore. The `functions/` directory now contains local Firebase tooling and tests; it is not a Cloud Functions deployment target. No live Firebase deployment or physical-phone validation is implied by checking out or building this source.

When configured, Google sign-in links an existing anonymous user to preserve their UID, pairing, votes, and tokens. A Google credential already belonging to another profile is rejected with a message instead of silently abandoning the current couple.

### Staying within the no-cost plan

Spark requires no payment information. Keep the project on Spark without a linked billing account: linking one changes it to Blaze. This app has no paid AI API, Cloud Functions runtime, subscription, or automatic billing upgrade. See [Firebase's pricing-plan documentation](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans).

Firestore's free allowance includes one database per project, **1 GiB stored data**, **50,000 document reads/day**, **20,000 writes/day**, **20,000 deletes/day**, and **10 GiB outbound transfer/month**. Daily quotas reset around midnight Pacific time. Listeners, rule-dependent reads, repeated retries, and retained sessions use the project's shared allowance. Quota exhaustion can temporarily stop pairing or sync until the applicable allowance recovers; this is not unlimited hosting. Monitor the Firestore Usage tab and avoid paid features such as TTL deletion or backups. See the [Firestore quota reference](https://firebase.google.com/docs/firestore/quotas).

## Data and consistency

The requested four document paths are implemented:

| Path | Contents |
| --- | --- |
| `users/{uid}` | Name, partner/room IDs, weekly token balance, reset timestamp |
| `couple_rooms/{roomId}` | Six-character invite, two member IDs, active session, creation timestamp |
| `sessions/{sessionId}` | Category, budget, mood, ACTIVE/MATCHED state, matched item |
| `sessions/{sessionId}/swipes/{itemId}` | Each member's LIKE/PASS/null vote and optional veto owner |

Session documents additionally store immutable `itemIds`, `matchSource`, and `matchRevision`. These make deck order shared, distinguish roulette results from mutual matches, and prevent a retried veto from consuming tokens against a newer match. Firestore timestamps map to epoch milliseconds in domain models. Enum names remain `LOW / MEDIUM / HIGH` on the wire. Cards show illustrative budgets for two: `Up to EGP 300 / EGP 301–700 / Over EGP 700`; the maximum-budget filters show `Up to EGP 300 / Up to EGP 700 / Any budget`.

Two rules-protected collections support pairing. `invite_codes` reserves unique codes and denies collection listing. Before looking up a partner's exact code, a user records it in their own `join_attempts` document; rules permit up to eight such recorded attempts per fifteen-minute window, measured with `request.time`. Repeated reads of the most recently recorded code are still possible, and creating new anonymous accounts can bypass a per-account allowance. This limits code probing without claiming comprehensive abuse prevention. Joining updates the room and **both** profiles in one transaction. An unused invite can be abandoned when its owner joins their partner's code.

The Android swipe transaction reads the session, room and swipe before any writes. It saves only the current member's first vote. A second LIKE writes the vote and MATCHED session state atomically. Firestore rules independently enforce these invariants, including the active room pointer. Concurrent matches contend on the shared session document, so exactly one item wins that revision.

The repository also handles a reproduced simultaneous-first-LIKE race: rules can reject a stale transaction before the SDK retries its precondition. Fresh server reads must prove that the partner's concurrent LIKE caused the conflict before the app retries. This recovery is bounded to three total attempts; genuine authorization failures remain errors.

Pairing, starting rounds, refilling/spending tokens, and selecting roulette results use authenticated **client Firestore transactions**. Security Rules validate the complete transition, including permitted partner-profile updates, catalogue membership, token bounds, server-time reset eligibility, and shared match revisions. A modified client must still satisfy those rules. This removes the paid Functions deployment requirement; it also means the tie-breaker's randomness cannot be certified by a trusted application server.

Both devices observe the persisted session and swipe documents through cancellable snapshot listeners. UI state is restored from votes, so rotation/process recreation cannot reset progress. Offline/failed votes remain retryable. Real-time means each connected device reacts when it receives the committed snapshot; exact simultaneous wall-clock animation cannot be guaranteed across networks.

## Product decisions

- **20 preloaded ideas:** five food delivery ideas, five cafe outings, five movie/cinema ideas, and five weekend activities. Illustrations use local emoji and gradients, so no external photo keys or image licenses are needed. These are editable suggestions, not live venue listings or availability claims.
- **Egyptian budget guides for two:** filters are `Up to EGP 300`, `Up to EGP 700`, and `Any budget`. The middle option includes LOW and MEDIUM ideas; the last includes all tiers. These amounts are illustrative guides, not verified menu or venue quotes, and no currency conversion was performed. Confirm actual prices before choosing. Mood remains a strict match, and every category has LOW-tier ideas for all three moods.
- **Veto allowance:** two tokens per user per rolling seven-day period. Firestore rules check reset eligibility against server time. Refills are lazy, capped at two, and do not accumulate. A veto excludes that item for the remainder of the session and resumes the durable unvoted queue.
- **Tie-breaker:** both partners must finish all non-vetoed cards. The app randomly selects an eligible item from the union of their likes, and a transaction persists one shared winner. Rules reject ineligible or vetoed choices; they cannot prove a modified client's random selection was fair. Both devices animate the stored result. No AI model or paid API is called.
- **Empty union:** show a fresh-round action instead of inventing a choice. Existing ACTIVE rounds are reused until they finish; either partner may start another round after a match, and the other device follows the room pointer.
- **Accessibility/theme:** light and dark Material 3 palettes, semantic labels, button alternatives to gestures, and font-aware layouts. Preview functions are included for visual review in Android Studio.

## Verification

```sh
# Android domain/ViewModel tests, lint, debug APK, and R8 release build
./gradlew testEmulatorDebugUnitTest lintEmulatorDebug assembleEmulatorDebug assembleEmulatorRelease

# Backend compilation and pure tests
cd functions
npm test

# Spark client transactions and rules on local emulators
npm run test:emulator

# Dependency-free core tests on Node 22.18+ / Node 24
npm run test:core
```

The Spark emulator suite validates pairing races, listener convergence, simultaneous likes, veto retries/races, slower-partner exhaustion, shared roulette results, empty unions, concurrent server-time token resets, and denied attempts to forge partner votes, matches, profiles or membership. It also exercises five-card session creation and replacement within Firestore's rule-access limits. Android tests cover restored queues, missing snapshots, double taps, failed writes, superseded sessions, bounded initial loading, late-snapshot recovery, retry cancellation, and preservation of newer errors. [CI](.github/workflows/verify.yml) runs Android build/lint/unit tests and Firebase emulator tests separately.

Local verification on 2026-10-31:

| Check | Result |
| --- | --- |
| Android JVM tests | 64 passed, with zero failures, errors, or skipped tests; includes Spark refill-race and connection-recovery regressions |
| Production release lint | Passed with zero errors and two advisory warnings |
| Production release APK | Optimized, signed, and signature-verified `WePick-1.1.1.apk`; 3,468,772 bytes |
| Emulator archive | The previously published 1.0.2 debug preview is historical; its earlier unsigned emulator release build is not the current phone release |
| Spark tooling strict TypeScript compilation | Passed |
| Core tests | 4 passed |
| Spark Auth/Firestore emulator integration tests | 12 passed, including simultaneous-first-LIKE, concurrent token-refill, private-code, five-card rule-budget, and hostile-write regressions |
| Live Spark SDK smoke checks | Passed anonymous authentication, reciprocal pairing, weekly refill, five-card setup, denied forgeries, two real-time match listeners, veto retries, and shared tie breaking; both temporary users and all 14 test documents were removed |

The signed **1.1.1** APK has SHA-256 `e7573229e58fd949927dd52e59513ccecccf7a24d48d4bc598fd89ef7e803c59`. Firestore rules and 36 catalogue filters have been deployed to the configured Spark project with billing disabled. Live behavior was verified using two independent authenticated SDK clients. Installation, APK UI behavior, and Play Integrity attestation on physical phones have not yet been validated for this release. The published 1.0.2 developer archive remains an emulator build.

Release verification should also exercise two real devices, Google credential linking, App Check/Play Integrity, accessibility/font scaling, dark mode, connectivity loss, and process recreation against your configured Firebase project.

## References

- [Firebase Android setup and main-module dependencies](https://firebase.google.com/docs/android/setup)
- [Firebase Authentication provider configuration through the CLI](https://firebase.google.com/docs/auth/configure-providers-cli)
- [Firebase Spark pricing plan](https://firebase.google.com/docs/projects/billing/firebase-pricing-plans)
- [Firestore free quotas and limits](https://firebase.google.com/docs/firestore/quotas)
- [Firestore transaction ordering, retries, and offline behavior](https://firebase.google.com/docs/firestore/manage-data/transactions)
- [Firebase Google authentication with Credential Manager](https://firebase.google.com/docs/auth/android/google-signin)
- [Type-safe Navigation Compose routes](https://developer.android.com/guide/navigation/design/type-safety)
- [Compose compiler Gradle plugin](https://developer.android.com/jetpack/androidx/releases/compose-kotlin)
